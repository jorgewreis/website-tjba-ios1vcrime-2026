
package br.jus.cnj.intercomunicacao.servico;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConfirmarRecebimento;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarAlteracao;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarAssuntos;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarAvisosPendentes;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarClasses;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarCompetencias;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarDocumentosProcesso;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarLocalidades;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarProcesso;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarRemessas;
import br.jus.cnj.intercomunicacao.beans.RequisicaoConsultarTeorComunicacao;
import br.jus.cnj.intercomunicacao.beans.RequisicaoEntregarPeticao;
import br.jus.cnj.intercomunicacao.beans.RequisicaoEntregarPeticaoInicial;
import br.jus.cnj.intercomunicacao.beans.RequisicaoRemeterProcesso;
import br.jus.cnj.intercomunicacao.beans.RequisicaoResponderComunicacao;
import br.jus.cnj.intercomunicacao.beans.RespostaConfirmarRecebimento;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarAlteracao;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarAssuntos;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarAvisosPendentes;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarClasses;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarCompetencias;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarDocumentosProcesso;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarLocalidades;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarProcesso;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarRemessas;
import br.jus.cnj.intercomunicacao.beans.RespostaConsultarTeorComunicacao;
import br.jus.cnj.intercomunicacao.beans.RespostaEntregarPeticao;
import br.jus.cnj.intercomunicacao.beans.RespostaEntregarPeticaoInicial;
import br.jus.cnj.intercomunicacao.beans.RespostaRemeterProcesso;
import br.jus.cnj.intercomunicacao.beans.RespostaResponderComunicacao;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.jus.cnj.intercomunicacao.servico package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RequisicaoConsultarAvisosPendentes_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarAvisosPendentes");
    private final static QName _RequisicaoConsultarCompetencias_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarCompetencias");
    private final static QName _RequisicaoEntregarPeticao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoEntregarPeticao");
    private final static QName _RespostaConsultarCompetencias_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarCompetencias");
    private final static QName _RequisicaoRemeterProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoRemeterProcesso");
    private final static QName _RespostaConsultarProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarProcesso");
    private final static QName _RespostaEntregarPeticaoInicial_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaEntregarPeticaoInicial");
    private final static QName _RespostaResponderComunicacao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaResponderComunicacao");
    private final static QName _RequisicaoConsultarDocumentosProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarDocumentosProcesso");
    private final static QName _RequisicaoConsultarTeorComunicacao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarTeorComunicacao");
    private final static QName _RespostaConsultarAvisosPendentes_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarAvisosPendentes");
    private final static QName _RequisicaoConfirmarRecebimento_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConfirmarRecebimento");
    private final static QName _RequisicaoConsultarRemessas_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarRemessas");
    private final static QName _RespostaConsultarTeorComunicacao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarTeorComunicacao");
    private final static QName _RequisicaoEntregarPeticaoInicial_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoEntregarPeticaoInicial");
    private final static QName _RequisicaoConsultarClasses_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarClasses");
    private final static QName _RespostaConsultarAssuntos_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarAssuntos");
    private final static QName _RespostaConsultarClasses_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarClasses");
    private final static QName _RespostaEntregarPeticao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaEntregarPeticao");
    private final static QName _RespostaRemeterProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaRemeterProcesso");
    private final static QName _RequisicaoConsultarProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarProcesso");
    private final static QName _RespostaConsultarAlteracao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarAlteracao");
    private final static QName _RespostaConfirmarRecebimento_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConfirmarRecebimento");
    private final static QName _RequisicaoResponderComunicacao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoResponderComunicacao");
    private final static QName _RequisicaoConsultarAlteracao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarAlteracao");
    private final static QName _RequisicaoConsultarAssuntos_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarAssuntos");
    private final static QName _RequisicaoConsultarLocalidades_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "requisicaoConsultarLocalidades");
    private final static QName _RespostaConsultarDocumentosProcesso_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarDocumentosProcesso");
    private final static QName _RespostaConsultarLocalidades_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarLocalidades");
    private final static QName _RespostaConsultarRemessas_QNAME = new QName("http://www.cnj.jus.br/mni/v300/", "respostaConsultarRemessas");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.jus.cnj.intercomunicacao.servico
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarAvisosPendentes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarAvisosPendentes")
    public JAXBElement<RequisicaoConsultarAvisosPendentes> createRequisicaoConsultarAvisosPendentes(RequisicaoConsultarAvisosPendentes value) {
        return new JAXBElement<RequisicaoConsultarAvisosPendentes>(_RequisicaoConsultarAvisosPendentes_QNAME, RequisicaoConsultarAvisosPendentes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarCompetencias }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarCompetencias")
    public JAXBElement<RequisicaoConsultarCompetencias> createRequisicaoConsultarCompetencias(RequisicaoConsultarCompetencias value) {
        return new JAXBElement<RequisicaoConsultarCompetencias>(_RequisicaoConsultarCompetencias_QNAME, RequisicaoConsultarCompetencias.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoEntregarPeticao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoEntregarPeticao")
    public JAXBElement<RequisicaoEntregarPeticao> createRequisicaoEntregarPeticao(RequisicaoEntregarPeticao value) {
        return new JAXBElement<RequisicaoEntregarPeticao>(_RequisicaoEntregarPeticao_QNAME, RequisicaoEntregarPeticao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarCompetencias }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarCompetencias")
    public JAXBElement<RespostaConsultarCompetencias> createRespostaConsultarCompetencias(RespostaConsultarCompetencias value) {
        return new JAXBElement<RespostaConsultarCompetencias>(_RespostaConsultarCompetencias_QNAME, RespostaConsultarCompetencias.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoRemeterProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoRemeterProcesso")
    public JAXBElement<RequisicaoRemeterProcesso> createRequisicaoRemeterProcesso(RequisicaoRemeterProcesso value) {
        return new JAXBElement<RequisicaoRemeterProcesso>(_RequisicaoRemeterProcesso_QNAME, RequisicaoRemeterProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarProcesso")
    public JAXBElement<RespostaConsultarProcesso> createRespostaConsultarProcesso(RespostaConsultarProcesso value) {
        return new JAXBElement<RespostaConsultarProcesso>(_RespostaConsultarProcesso_QNAME, RespostaConsultarProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaEntregarPeticaoInicial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaEntregarPeticaoInicial")
    public JAXBElement<RespostaEntregarPeticaoInicial> createRespostaEntregarPeticaoInicial(RespostaEntregarPeticaoInicial value) {
        return new JAXBElement<RespostaEntregarPeticaoInicial>(_RespostaEntregarPeticaoInicial_QNAME, RespostaEntregarPeticaoInicial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaResponderComunicacao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaResponderComunicacao")
    public JAXBElement<RespostaResponderComunicacao> createRespostaResponderComunicacao(RespostaResponderComunicacao value) {
        return new JAXBElement<RespostaResponderComunicacao>(_RespostaResponderComunicacao_QNAME, RespostaResponderComunicacao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarDocumentosProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarDocumentosProcesso")
    public JAXBElement<RequisicaoConsultarDocumentosProcesso> createRequisicaoConsultarDocumentosProcesso(RequisicaoConsultarDocumentosProcesso value) {
        return new JAXBElement<RequisicaoConsultarDocumentosProcesso>(_RequisicaoConsultarDocumentosProcesso_QNAME, RequisicaoConsultarDocumentosProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarTeorComunicacao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarTeorComunicacao")
    public JAXBElement<RequisicaoConsultarTeorComunicacao> createRequisicaoConsultarTeorComunicacao(RequisicaoConsultarTeorComunicacao value) {
        return new JAXBElement<RequisicaoConsultarTeorComunicacao>(_RequisicaoConsultarTeorComunicacao_QNAME, RequisicaoConsultarTeorComunicacao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarAvisosPendentes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarAvisosPendentes")
    public JAXBElement<RespostaConsultarAvisosPendentes> createRespostaConsultarAvisosPendentes(RespostaConsultarAvisosPendentes value) {
        return new JAXBElement<RespostaConsultarAvisosPendentes>(_RespostaConsultarAvisosPendentes_QNAME, RespostaConsultarAvisosPendentes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConfirmarRecebimento }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConfirmarRecebimento")
    public JAXBElement<RequisicaoConfirmarRecebimento> createRequisicaoConfirmarRecebimento(RequisicaoConfirmarRecebimento value) {
        return new JAXBElement<RequisicaoConfirmarRecebimento>(_RequisicaoConfirmarRecebimento_QNAME, RequisicaoConfirmarRecebimento.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarRemessas }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarRemessas")
    public JAXBElement<RequisicaoConsultarRemessas> createRequisicaoConsultarRemessas(RequisicaoConsultarRemessas value) {
        return new JAXBElement<RequisicaoConsultarRemessas>(_RequisicaoConsultarRemessas_QNAME, RequisicaoConsultarRemessas.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarTeorComunicacao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarTeorComunicacao")
    public JAXBElement<RespostaConsultarTeorComunicacao> createRespostaConsultarTeorComunicacao(RespostaConsultarTeorComunicacao value) {
        return new JAXBElement<RespostaConsultarTeorComunicacao>(_RespostaConsultarTeorComunicacao_QNAME, RespostaConsultarTeorComunicacao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoEntregarPeticaoInicial }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoEntregarPeticaoInicial")
    public JAXBElement<RequisicaoEntregarPeticaoInicial> createRequisicaoEntregarPeticaoInicial(RequisicaoEntregarPeticaoInicial value) {
        return new JAXBElement<RequisicaoEntregarPeticaoInicial>(_RequisicaoEntregarPeticaoInicial_QNAME, RequisicaoEntregarPeticaoInicial.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarClasses }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarClasses")
    public JAXBElement<RequisicaoConsultarClasses> createRequisicaoConsultarClasses(RequisicaoConsultarClasses value) {
        return new JAXBElement<RequisicaoConsultarClasses>(_RequisicaoConsultarClasses_QNAME, RequisicaoConsultarClasses.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarAssuntos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarAssuntos")
    public JAXBElement<RespostaConsultarAssuntos> createRespostaConsultarAssuntos(RespostaConsultarAssuntos value) {
        return new JAXBElement<RespostaConsultarAssuntos>(_RespostaConsultarAssuntos_QNAME, RespostaConsultarAssuntos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarClasses }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarClasses")
    public JAXBElement<RespostaConsultarClasses> createRespostaConsultarClasses(RespostaConsultarClasses value) {
        return new JAXBElement<RespostaConsultarClasses>(_RespostaConsultarClasses_QNAME, RespostaConsultarClasses.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaEntregarPeticao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaEntregarPeticao")
    public JAXBElement<RespostaEntregarPeticao> createRespostaEntregarPeticao(RespostaEntregarPeticao value) {
        return new JAXBElement<RespostaEntregarPeticao>(_RespostaEntregarPeticao_QNAME, RespostaEntregarPeticao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaRemeterProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaRemeterProcesso")
    public JAXBElement<RespostaRemeterProcesso> createRespostaRemeterProcesso(RespostaRemeterProcesso value) {
        return new JAXBElement<RespostaRemeterProcesso>(_RespostaRemeterProcesso_QNAME, RespostaRemeterProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarProcesso")
    public JAXBElement<RequisicaoConsultarProcesso> createRequisicaoConsultarProcesso(RequisicaoConsultarProcesso value) {
        return new JAXBElement<RequisicaoConsultarProcesso>(_RequisicaoConsultarProcesso_QNAME, RequisicaoConsultarProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarAlteracao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarAlteracao")
    public JAXBElement<RespostaConsultarAlteracao> createRespostaConsultarAlteracao(RespostaConsultarAlteracao value) {
        return new JAXBElement<RespostaConsultarAlteracao>(_RespostaConsultarAlteracao_QNAME, RespostaConsultarAlteracao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConfirmarRecebimento }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConfirmarRecebimento")
    public JAXBElement<RespostaConfirmarRecebimento> createRespostaConfirmarRecebimento(RespostaConfirmarRecebimento value) {
        return new JAXBElement<RespostaConfirmarRecebimento>(_RespostaConfirmarRecebimento_QNAME, RespostaConfirmarRecebimento.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoResponderComunicacao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoResponderComunicacao")
    public JAXBElement<RequisicaoResponderComunicacao> createRequisicaoResponderComunicacao(RequisicaoResponderComunicacao value) {
        return new JAXBElement<RequisicaoResponderComunicacao>(_RequisicaoResponderComunicacao_QNAME, RequisicaoResponderComunicacao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarAlteracao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarAlteracao")
    public JAXBElement<RequisicaoConsultarAlteracao> createRequisicaoConsultarAlteracao(RequisicaoConsultarAlteracao value) {
        return new JAXBElement<RequisicaoConsultarAlteracao>(_RequisicaoConsultarAlteracao_QNAME, RequisicaoConsultarAlteracao.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarAssuntos }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarAssuntos")
    public JAXBElement<RequisicaoConsultarAssuntos> createRequisicaoConsultarAssuntos(RequisicaoConsultarAssuntos value) {
        return new JAXBElement<RequisicaoConsultarAssuntos>(_RequisicaoConsultarAssuntos_QNAME, RequisicaoConsultarAssuntos.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequisicaoConsultarLocalidades }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "requisicaoConsultarLocalidades")
    public JAXBElement<RequisicaoConsultarLocalidades> createRequisicaoConsultarLocalidades(RequisicaoConsultarLocalidades value) {
        return new JAXBElement<RequisicaoConsultarLocalidades>(_RequisicaoConsultarLocalidades_QNAME, RequisicaoConsultarLocalidades.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarDocumentosProcesso }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarDocumentosProcesso")
    public JAXBElement<RespostaConsultarDocumentosProcesso> createRespostaConsultarDocumentosProcesso(RespostaConsultarDocumentosProcesso value) {
        return new JAXBElement<RespostaConsultarDocumentosProcesso>(_RespostaConsultarDocumentosProcesso_QNAME, RespostaConsultarDocumentosProcesso.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarLocalidades }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarLocalidades")
    public JAXBElement<RespostaConsultarLocalidades> createRespostaConsultarLocalidades(RespostaConsultarLocalidades value) {
        return new JAXBElement<RespostaConsultarLocalidades>(_RespostaConsultarLocalidades_QNAME, RespostaConsultarLocalidades.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespostaConsultarRemessas }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/", name = "respostaConsultarRemessas")
    public JAXBElement<RespostaConsultarRemessas> createRespostaConsultarRemessas(RespostaConsultarRemessas value) {
        return new JAXBElement<RespostaConsultarRemessas>(_RespostaConsultarRemessas_QNAME, RespostaConsultarRemessas.class, null, value);
    }

}
