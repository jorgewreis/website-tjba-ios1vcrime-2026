
package br.jus.cnj.intercomunicacao.cda;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.jus.cnj.intercomunicacao.cda package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.jus.cnj.intercomunicacao.cda
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DividaAtiva }
     * 
     */
    public DividaAtiva createDividaAtiva() {
        return new DividaAtiva();
    }

    /**
     * Create an instance of {@link DevedorAlternativo }
     * 
     */
    public DevedorAlternativo createDevedorAlternativo() {
        return new DevedorAlternativo();
    }

    /**
     * Create an instance of {@link ValorDivida }
     * 
     */
    public ValorDivida createValorDivida() {
        return new ValorDivida();
    }

    /**
     * Create an instance of {@link Certidao }
     * 
     */
    public Certidao createCertidao() {
        return new Certidao();
    }

    /**
     * Create an instance of {@link DevedorPrincipal }
     * 
     */
    public DevedorPrincipal createDevedorPrincipal() {
        return new DevedorPrincipal();
    }

}
