@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.cnj.jus.br/mni/v300/cda", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.jus.cnj.intercomunicacao.cda;
