
package br.jus.cnj.intercomunicacao.cda;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoDevedorPrincipal complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoDevedorPrincipal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="inscricaoMF" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoDevedorPrincipal")
public class DevedorPrincipal
    implements Serializable
{

    @XmlAttribute(name = "inscricaoMF", required = true)
    protected String inscricaoMF;

    /**
     * Obtém o valor da propriedade inscricaoMF.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInscricaoMF() {
        return inscricaoMF;
    }

    /**
     * Define o valor da propriedade inscricaoMF.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInscricaoMF(String value) {
        this.inscricaoMF = value;
    }

    public boolean isSetInscricaoMF() {
        return (this.inscricaoMF!= null);
    }

}
