
package br.jus.cnj.intercomunicacao.cda;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoCertidao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoCertidao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="devedorPrincipal" type="{http://www.cnj.jus.br/mni/v300/cda}tipoDevedorPrincipal" maxOccurs="unbounded"/>
 *         &lt;element name="devedorAlternativo" type="{http://www.cnj.jus.br/mni/v300/cda}tipoDevedorAlternativo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="valor" type="{http://www.cnj.jus.br/mni/v300/cda}valorDivida" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCertidao", propOrder = {
    "devedorPrincipal",
    "devedorAlternativo",
    "valor"
})
public class Certidao
    implements Serializable
{

    @XmlElement(required = true)
    protected List<DevedorPrincipal> devedorPrincipal;
    protected List<DevedorAlternativo> devedorAlternativo;
    @XmlElement(required = true)
    protected List<ValorDivida> valor;

    /**
     * Gets the value of the devedorPrincipal property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the devedorPrincipal property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDevedorPrincipal().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DevedorPrincipal }
     * 
     * 
     */
    public List<DevedorPrincipal> getDevedorPrincipal() {
        if (devedorPrincipal == null) {
            devedorPrincipal = new ArrayList<DevedorPrincipal>();
        }
        return this.devedorPrincipal;
    }

    public boolean isSetDevedorPrincipal() {
        return ((this.devedorPrincipal!= null)&&(!this.devedorPrincipal.isEmpty()));
    }

    public void unsetDevedorPrincipal() {
        this.devedorPrincipal = null;
    }

    /**
     * Gets the value of the devedorAlternativo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the devedorAlternativo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDevedorAlternativo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DevedorAlternativo }
     * 
     * 
     */
    public List<DevedorAlternativo> getDevedorAlternativo() {
        if (devedorAlternativo == null) {
            devedorAlternativo = new ArrayList<DevedorAlternativo>();
        }
        return this.devedorAlternativo;
    }

    public boolean isSetDevedorAlternativo() {
        return ((this.devedorAlternativo!= null)&&(!this.devedorAlternativo.isEmpty()));
    }

    public void unsetDevedorAlternativo() {
        this.devedorAlternativo = null;
    }

    /**
     * Gets the value of the valor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the valor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValorDivida }
     * 
     * 
     */
    public List<ValorDivida> getValor() {
        if (valor == null) {
            valor = new ArrayList<ValorDivida>();
        }
        return this.valor;
    }

    public boolean isSetValor() {
        return ((this.valor!= null)&&(!this.valor.isEmpty()));
    }

    public void unsetValor() {
        this.valor = null;
    }

}
