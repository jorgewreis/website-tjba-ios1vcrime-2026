
package br.jus.cnj.intercomunicacao.cda;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoDividaAtiva element declaration.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;element name="tipoDividaAtiva">
 *   &lt;complexType>
 *     &lt;complexContent>
 *       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *         &lt;sequence>
 *           &lt;element name="certidao" type="{http://www.cnj.jus.br/mni/v300/cda}tipoCertidao" maxOccurs="unbounded"/>
 *         &lt;/sequence>
 *       &lt;/restriction>
 *     &lt;/complexContent>
 *   &lt;/complexType>
 * &lt;/element>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "certidao"
})
@XmlRootElement(name = "tipoDividaAtiva")
public class DividaAtiva
    implements Serializable
{

    @XmlElement(required = true)
    protected List<Certidao> certidao;

    /**
     * Gets the value of the certidao property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the certidao property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCertidao().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Certidao }
     * 
     * 
     */
    public List<Certidao> getCertidao() {
        if (certidao == null) {
            certidao = new ArrayList<Certidao>();
        }
        return this.certidao;
    }

    public boolean isSetCertidao() {
        return ((this.certidao!= null)&&(!this.certidao.isEmpty()));
    }

    public void unsetCertidao() {
        this.certidao = null;
    }

}
