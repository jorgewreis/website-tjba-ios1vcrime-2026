
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula a resposta decorrente da manifestação apresentada. Sendo bem sucedida 
 * ou não, deve ser fornecido protocolo da operação. O recibo deverá ser apresentado em caso de sucesso. 
 * 			
 * 
 * <p>Classe Java de tipoReciboManifestacaoProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoReciboManifestacaoProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRecibo"/>
 *         &lt;element name="numeroProtocolo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dataOperacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="documentoComprovante" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="reciboDocumentos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoReciboDocumentoProtocolado" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoReciboManifestacaoProcessual", propOrder = {
    "recibo",
    "numeroProtocolo",
    "dataOperacao",
    "documentoComprovante",
    "reciboDocumentos"
})
public class ReciboManifestacaoProcessual
    implements Serializable
{

    @XmlElement(required = true)
    protected Recibo recibo;
    @XmlElement(required = true)
    protected String numeroProtocolo;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataOperacao;
    @XmlMimeType("application/octet-stream")
    protected DataHandler documentoComprovante;
    protected List<ReciboDocumentoProtocolado> reciboDocumentos;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link Recibo }
     *     
     */
    public Recibo getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link Recibo }
     *     
     */
    public void setRecibo(Recibo value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProtocolo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroProtocolo() {
        return numeroProtocolo;
    }

    /**
     * Define o valor da propriedade numeroProtocolo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroProtocolo(String value) {
        this.numeroProtocolo = value;
    }

    public boolean isSetNumeroProtocolo() {
        return (this.numeroProtocolo!= null);
    }

    /**
     * Obtém o valor da propriedade dataOperacao.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataOperacao() {
        return dataOperacao;
    }

    /**
     * Define o valor da propriedade dataOperacao.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataOperacao(DataHora value) {
        this.dataOperacao = value;
    }

    public boolean isSetDataOperacao() {
        return (this.dataOperacao!= null);
    }

    /**
     * Obtém o valor da propriedade documentoComprovante.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getDocumentoComprovante() {
        return documentoComprovante;
    }

    /**
     * Define o valor da propriedade documentoComprovante.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setDocumentoComprovante(DataHandler value) {
        this.documentoComprovante = value;
    }

    public boolean isSetDocumentoComprovante() {
        return (this.documentoComprovante!= null);
    }

    /**
     * Gets the value of the reciboDocumentos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the reciboDocumentos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getReciboDocumentos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ReciboDocumentoProtocolado }
     * 
     * 
     */
    public List<ReciboDocumentoProtocolado> getReciboDocumentos() {
        if (reciboDocumentos == null) {
            reciboDocumentos = new ArrayList<ReciboDocumentoProtocolado>();
        }
        return this.reciboDocumentos;
    }

    public boolean isSetReciboDocumentos() {
        return ((this.reciboDocumentos!= null)&&(!this.reciboDocumentos.isEmpty()));
    }

    public void unsetReciboDocumentos() {
        this.reciboDocumentos = null;
    }

}
