
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadePendenciaComunicacao.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadePendenciaComunicacao">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PC"/>
 *     &lt;enumeration value="PR"/>
 *     &lt;enumeration value="AM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadePendenciaComunicacao")
@XmlEnum
public enum ModalidadePendenciaComunicacao {

    PC,
    PR,
    AM;

    public String value() {
        return name();
    }

    public static ModalidadePendenciaComunicacao fromValue(String v) {
        return valueOf(v);
    }

}
