
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadeTipoComunicacao.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadeTipoComunicacao">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CIT"/>
 *     &lt;enumeration value="INT"/>
 *     &lt;enumeration value="IDP"/>
 *     &lt;enumeration value="IDC"/>
 *     &lt;enumeration value="IAD"/>
 *     &lt;enumeration value="IST"/>
 *     &lt;enumeration value="IAC"/>
 *     &lt;enumeration value="NOT"/>
 *     &lt;enumeration value="VIS"/>
 *     &lt;enumeration value="URG"/>
 *     &lt;enumeration value="PTA"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadeTipoComunicacao")
@XmlEnum
public enum ModalidadeTipoComunicacao {

    CIT,
    INT,
    IDP,
    IDC,
    IAD,
    IST,
    IAC,
    NOT,
    VIS,
    URG,
    PTA;

    public String value() {
        return name();
    }

    public static ModalidadeTipoComunicacao fromValue(String v) {
        return valueOf(v);
    }

}
