
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir a consulta de teor de comunicação processual pendente relativa 
 * ao consultante em um determinado processo judicial. Os dados encapsulados são o identificador do consultante, sua 
 * senha, e o número do processo judicial no qual se está efetivando a consulta de comunicação. 
 * 
 * 
 * <p>Classe Java de requisicaoConsultarTeorComunicacao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarTeorComunicacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consultante" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacao"/>
 *         &lt;choice>
 *           &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *           &lt;element name="identificadorAviso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}identificadorComunicacao"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarTeorComunicacao", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "consultante",
    "numeroProcesso",
    "identificadorAviso"
})
public class RequisicaoConsultarTeorComunicacao
    implements Serializable
{

    @XmlElement(required = true)
    protected Autenticacao consultante;
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    @XmlSchemaType(name = "string")
    protected Identificador identificadorAviso;

    /**
     * Obtém o valor da propriedade consultante.
     * 
     * @return
     *     possible object is
     *     {@link Autenticacao }
     *     
     */
    public Autenticacao getConsultante() {
        return consultante;
    }

    /**
     * Define o valor da propriedade consultante.
     * 
     * @param value
     *     allowed object is
     *     {@link Autenticacao }
     *     
     */
    public void setConsultante(Autenticacao value) {
        this.consultante = value;
    }

    public boolean isSetConsultante() {
        return (this.consultante!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade identificadorAviso.
     * 
     * @return
     *     possible object is
     *     {@link Identificador }
     *     
     */
    public Identificador getIdentificadorAviso() {
        return identificadorAviso;
    }

    /**
     * Define o valor da propriedade identificadorAviso.
     * 
     * @param value
     *     allowed object is
     *     {@link Identificador }
     *     
     */
    public void setIdentificadorAviso(Identificador value) {
        this.identificadorAviso = value;
    }

    public boolean isSetIdentificadorAviso() {
        return (this.identificadorAviso!= null);
    }

}
