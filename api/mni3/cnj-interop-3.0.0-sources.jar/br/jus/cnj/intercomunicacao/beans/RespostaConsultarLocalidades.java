
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de respostaConsultarLocalidades complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="respostaConsultarLocalidades">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRecibo"/>
 *         &lt;element name="localidades" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoLocalidade" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respostaConsultarLocalidades", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recibo",
    "localidades"
})
public class RespostaConsultarLocalidades
    implements Serializable
{

    @XmlElement(required = true)
    protected Recibo recibo;
    protected List<Localidade> localidades;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link Recibo }
     *     
     */
    public Recibo getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link Recibo }
     *     
     */
    public void setRecibo(Recibo value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

    /**
     * Gets the value of the localidades property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the localidades property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLocalidades().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Localidade }
     * 
     * 
     */
    public List<Localidade> getLocalidades() {
        if (localidades == null) {
            localidades = new ArrayList<Localidade>();
        }
        return this.localidades;
    }

    public boolean isSetLocalidades() {
        return ((this.localidades!= null)&&(!this.localidades.isEmpty()));
    }

    public void unsetLocalidades() {
        this.localidades = null;
    }

}
