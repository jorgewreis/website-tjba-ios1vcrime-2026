
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que reune o conjunto de dados pertinentes à realização de uma consulta de avisos 
 * de comunicação pendentes. Caso seja omitida a dataInicioConsulta, deverá retornar a lista de todos os avisos pendentes 
 * (ou seja, aqueles em relação aos quais ainda não houve ciência pelo comunicado). Caso já tenha havido a ciência 
 * (por consulta realizada com o uso da operação consultarTeorComunicacao ou por decurso do prazo legal de ciência), 
 * não deverá retornar o aviso. 
 * 			
 * 
 * <p>Classe Java de requisicaoConsultarAvisosPendentes complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarAvisosPendentes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consultante" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacao"/>
 *         &lt;element name="idRepresentado" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dataInicial" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="dataFinal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="tipoPendencia" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadePendenciaComunicacao" minOccurs="0"/>
 *         &lt;element name="tiposAviso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeTipoComunicacao" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarAvisosPendentes", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "consultante",
    "idRepresentado",
    "dataInicial",
    "dataFinal",
    "tipoPendencia",
    "tiposAviso"
})
public class RequisicaoConsultarAvisosPendentes
    implements Serializable
{

    @XmlElement(required = true)
    protected Autenticacao consultante;
    protected String idRepresentado;
    @XmlSchemaType(name = "string")
    protected DataHora dataInicial;
    @XmlSchemaType(name = "string")
    protected DataHora dataFinal;
    @XmlElement(defaultValue = "AM")
    @XmlSchemaType(name = "string")
    protected ModalidadePendenciaComunicacao tipoPendencia;
    @XmlSchemaType(name = "string")
    protected List<ModalidadeTipoComunicacao> tiposAviso;

    /**
     * Obtém o valor da propriedade consultante.
     * 
     * @return
     *     possible object is
     *     {@link Autenticacao }
     *     
     */
    public Autenticacao getConsultante() {
        return consultante;
    }

    /**
     * Define o valor da propriedade consultante.
     * 
     * @param value
     *     allowed object is
     *     {@link Autenticacao }
     *     
     */
    public void setConsultante(Autenticacao value) {
        this.consultante = value;
    }

    public boolean isSetConsultante() {
        return (this.consultante!= null);
    }

    /**
     * Obtém o valor da propriedade idRepresentado.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdRepresentado() {
        return idRepresentado;
    }

    /**
     * Define o valor da propriedade idRepresentado.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdRepresentado(String value) {
        this.idRepresentado = value;
    }

    public boolean isSetIdRepresentado() {
        return (this.idRepresentado!= null);
    }

    /**
     * Obtém o valor da propriedade dataInicial.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataInicial() {
        return dataInicial;
    }

    /**
     * Define o valor da propriedade dataInicial.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataInicial(DataHora value) {
        this.dataInicial = value;
    }

    public boolean isSetDataInicial() {
        return (this.dataInicial!= null);
    }

    /**
     * Obtém o valor da propriedade dataFinal.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataFinal() {
        return dataFinal;
    }

    /**
     * Define o valor da propriedade dataFinal.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataFinal(DataHora value) {
        this.dataFinal = value;
    }

    public boolean isSetDataFinal() {
        return (this.dataFinal!= null);
    }

    /**
     * Obtém o valor da propriedade tipoPendencia.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadePendenciaComunicacao }
     *     
     */
    public ModalidadePendenciaComunicacao getTipoPendencia() {
        return tipoPendencia;
    }

    /**
     * Define o valor da propriedade tipoPendencia.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadePendenciaComunicacao }
     *     
     */
    public void setTipoPendencia(ModalidadePendenciaComunicacao value) {
        this.tipoPendencia = value;
    }

    public boolean isSetTipoPendencia() {
        return (this.tipoPendencia!= null);
    }

    /**
     * Gets the value of the tiposAviso property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tiposAviso property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTiposAviso().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ModalidadeTipoComunicacao }
     * 
     * 
     */
    public List<ModalidadeTipoComunicacao> getTiposAviso() {
        if (tiposAviso == null) {
            tiposAviso = new ArrayList<ModalidadeTipoComunicacao>();
        }
        return this.tiposAviso;
    }

    public boolean isSetTiposAviso() {
        return ((this.tiposAviso!= null)&&(!this.tiposAviso.isEmpty()));
    }

    public void unsetTiposAviso() {
        this.tiposAviso = null;
    }

}
