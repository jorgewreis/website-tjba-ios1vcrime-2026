
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a comunicar concretamente uma providência judicial para uma parte. A 
 * dataReferencia indica o momento em que foi considerada a parte intimada, seja por provocação do intimado/citado/notificado, 
 * seja por decurso do prazo legal para tomada de ciência. 
 * 			
 * 
 * <p>Classe Java de tipoComunicacaoProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoComunicacaoProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}identificadorComunicacao"/>
 *         &lt;element name="processo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCabecalhoProcessoSimples"/>
 *         &lt;element name="destinatario" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoaSimples"/>
 *         &lt;element name="remetente" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoOrgaoJulgador"/>
 *         &lt;element name="tipoComunicacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeTipoComunicacao" minOccurs="0"/>
 *         &lt;element name="tipoPrazo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadePrazo" minOccurs="0"/>
 *         &lt;element name="dataReferencia" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="prazo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="dataPrazoCalculado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="teor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="nivelSigilo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="parametro" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoParametro" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoComunicacaoProcessual", propOrder = {
    "id",
    "processo",
    "destinatario",
    "remetente",
    "tipoComunicacao",
    "tipoPrazo",
    "dataReferencia",
    "prazo",
    "dataPrazoCalculado",
    "teor",
    "documento",
    "nivelSigilo",
    "parametro",
    "any"
})
public class ComunicacaoProcessual
    implements Serializable
{

    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected Identificador id;
    @XmlElement(required = true)
    protected CabecalhoProcessoSimples processo;
    @XmlElement(required = true)
    protected PessoaSimples destinatario;
    @XmlElement(required = true)
    protected OrgaoJulgador remetente;
    @XmlSchemaType(name = "string")
    protected ModalidadeTipoComunicacao tipoComunicacao;
    @XmlSchemaType(name = "string")
    protected ModalidadePrazo tipoPrazo;
    @XmlSchemaType(name = "string")
    protected DataHora dataReferencia;
    protected Integer prazo;
    @XmlSchemaType(name = "string")
    protected DataHora dataPrazoCalculado;
    protected String teor;
    protected List<DocumentoProcessual> documento;
    protected Integer nivelSigilo;
    protected List<Parametro> parametro;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade id.
     * 
     * @return
     *     possible object is
     *     {@link Identificador }
     *     
     */
    public Identificador getId() {
        return id;
    }

    /**
     * Define o valor da propriedade id.
     * 
     * @param value
     *     allowed object is
     *     {@link Identificador }
     *     
     */
    public void setId(Identificador value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Obtém o valor da propriedade processo.
     * 
     * @return
     *     possible object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public CabecalhoProcessoSimples getProcesso() {
        return processo;
    }

    /**
     * Define o valor da propriedade processo.
     * 
     * @param value
     *     allowed object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public void setProcesso(CabecalhoProcessoSimples value) {
        this.processo = value;
    }

    public boolean isSetProcesso() {
        return (this.processo!= null);
    }

    /**
     * Obtém o valor da propriedade destinatario.
     * 
     * @return
     *     possible object is
     *     {@link PessoaSimples }
     *     
     */
    public PessoaSimples getDestinatario() {
        return destinatario;
    }

    /**
     * Define o valor da propriedade destinatario.
     * 
     * @param value
     *     allowed object is
     *     {@link PessoaSimples }
     *     
     */
    public void setDestinatario(PessoaSimples value) {
        this.destinatario = value;
    }

    public boolean isSetDestinatario() {
        return (this.destinatario!= null);
    }

    /**
     * Obtém o valor da propriedade remetente.
     * 
     * @return
     *     possible object is
     *     {@link OrgaoJulgador }
     *     
     */
    public OrgaoJulgador getRemetente() {
        return remetente;
    }

    /**
     * Define o valor da propriedade remetente.
     * 
     * @param value
     *     allowed object is
     *     {@link OrgaoJulgador }
     *     
     */
    public void setRemetente(OrgaoJulgador value) {
        this.remetente = value;
    }

    public boolean isSetRemetente() {
        return (this.remetente!= null);
    }

    /**
     * Obtém o valor da propriedade tipoComunicacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeTipoComunicacao }
     *     
     */
    public ModalidadeTipoComunicacao getTipoComunicacao() {
        return tipoComunicacao;
    }

    /**
     * Define o valor da propriedade tipoComunicacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeTipoComunicacao }
     *     
     */
    public void setTipoComunicacao(ModalidadeTipoComunicacao value) {
        this.tipoComunicacao = value;
    }

    public boolean isSetTipoComunicacao() {
        return (this.tipoComunicacao!= null);
    }

    /**
     * Obtém o valor da propriedade tipoPrazo.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadePrazo }
     *     
     */
    public ModalidadePrazo getTipoPrazo() {
        return tipoPrazo;
    }

    /**
     * Define o valor da propriedade tipoPrazo.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadePrazo }
     *     
     */
    public void setTipoPrazo(ModalidadePrazo value) {
        this.tipoPrazo = value;
    }

    public boolean isSetTipoPrazo() {
        return (this.tipoPrazo!= null);
    }

    /**
     * Obtém o valor da propriedade dataReferencia.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataReferencia() {
        return dataReferencia;
    }

    /**
     * Define o valor da propriedade dataReferencia.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataReferencia(DataHora value) {
        this.dataReferencia = value;
    }

    public boolean isSetDataReferencia() {
        return (this.dataReferencia!= null);
    }

    /**
     * Obtém o valor da propriedade prazo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPrazo() {
        return prazo;
    }

    /**
     * Define o valor da propriedade prazo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPrazo(Integer value) {
        this.prazo = value;
    }

    public boolean isSetPrazo() {
        return (this.prazo!= null);
    }

    /**
     * Obtém o valor da propriedade dataPrazoCalculado.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataPrazoCalculado() {
        return dataPrazoCalculado;
    }

    /**
     * Define o valor da propriedade dataPrazoCalculado.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataPrazoCalculado(DataHora value) {
        this.dataPrazoCalculado = value;
    }

    public boolean isSetDataPrazoCalculado() {
        return (this.dataPrazoCalculado!= null);
    }

    /**
     * Obtém o valor da propriedade teor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTeor() {
        return teor;
    }

    /**
     * Define o valor da propriedade teor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTeor(String value) {
        this.teor = value;
    }

    public boolean isSetTeor() {
        return (this.teor!= null);
    }

    /**
     * Gets the value of the documento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoProcessual }
     * 
     * 
     */
    public List<DocumentoProcessual> getDocumento() {
        if (documento == null) {
            documento = new ArrayList<DocumentoProcessual>();
        }
        return this.documento;
    }

    public boolean isSetDocumento() {
        return ((this.documento!= null)&&(!this.documento.isEmpty()));
    }

    public void unsetDocumento() {
        this.documento = null;
    }

    /**
     * Obtém o valor da propriedade nivelSigilo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNivelSigilo() {
        return nivelSigilo;
    }

    /**
     * Define o valor da propriedade nivelSigilo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNivelSigilo(Integer value) {
        this.nivelSigilo = value;
    }

    public boolean isSetNivelSigilo() {
        return (this.nivelSigilo!= null);
    }

    /**
     * Gets the value of the parametro property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parametro property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParametro().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parametro }
     * 
     * 
     */
    public List<Parametro> getParametro() {
        if (parametro == null) {
            parametro = new ArrayList<Parametro>();
        }
        return this.parametro;
    }

    public boolean isSetParametro() {
        return ((this.parametro!= null)&&(!this.parametro.isEmpty()));
    }

    public void unsetParametro() {
        this.parametro = null;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
