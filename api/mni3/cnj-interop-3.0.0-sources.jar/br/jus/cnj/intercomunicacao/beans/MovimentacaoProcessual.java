
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir apresentar informações relativas à movimentação processual. 
 * 
 * 			
 * 
 * <p>Classe Java de tipoMovimentoProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoMovimentoProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="complemento" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;choice>
 *           &lt;element name="movimentoNacional" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoNacional"/>
 *           &lt;element name="movimentoLocal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoLocal"/>
 *         &lt;/choice>
 *         &lt;element name="idDocumentoVinculado" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="dataHora" use="required" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" />
 *       &lt;attribute name="nivelSigilo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNivelSigilo" />
 *       &lt;attribute name="idMovimento" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoMovimentoProcessual", propOrder = {
    "complemento",
    "movimentoNacional",
    "movimentoLocal",
    "idDocumentoVinculado"
})
public class MovimentacaoProcessual
    implements Serializable
{

    protected List<String> complemento;
    protected MovimentoNacional movimentoNacional;
    protected MovimentoLocal movimentoLocal;
    protected List<String> idDocumentoVinculado;
    @XmlAttribute(name = "dataHora", required = true)
    protected DataHora dataHora;
    @XmlAttribute(name = "nivelSigilo")
    protected Integer nivelSigilo;
    @XmlAttribute(name = "idMovimento")
    protected String idMovimento;

    /**
     * Gets the value of the complemento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the complemento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComplemento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getComplemento() {
        if (complemento == null) {
            complemento = new ArrayList<String>();
        }
        return this.complemento;
    }

    public boolean isSetComplemento() {
        return ((this.complemento!= null)&&(!this.complemento.isEmpty()));
    }

    public void unsetComplemento() {
        this.complemento = null;
    }

    /**
     * Obtém o valor da propriedade movimentoNacional.
     * 
     * @return
     *     possible object is
     *     {@link MovimentoNacional }
     *     
     */
    public MovimentoNacional getMovimentoNacional() {
        return movimentoNacional;
    }

    /**
     * Define o valor da propriedade movimentoNacional.
     * 
     * @param value
     *     allowed object is
     *     {@link MovimentoNacional }
     *     
     */
    public void setMovimentoNacional(MovimentoNacional value) {
        this.movimentoNacional = value;
    }

    public boolean isSetMovimentoNacional() {
        return (this.movimentoNacional!= null);
    }

    /**
     * Obtém o valor da propriedade movimentoLocal.
     * 
     * @return
     *     possible object is
     *     {@link MovimentoLocal }
     *     
     */
    public MovimentoLocal getMovimentoLocal() {
        return movimentoLocal;
    }

    /**
     * Define o valor da propriedade movimentoLocal.
     * 
     * @param value
     *     allowed object is
     *     {@link MovimentoLocal }
     *     
     */
    public void setMovimentoLocal(MovimentoLocal value) {
        this.movimentoLocal = value;
    }

    public boolean isSetMovimentoLocal() {
        return (this.movimentoLocal!= null);
    }

    /**
     * Gets the value of the idDocumentoVinculado property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the idDocumentoVinculado property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdDocumentoVinculado().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getIdDocumentoVinculado() {
        if (idDocumentoVinculado == null) {
            idDocumentoVinculado = new ArrayList<String>();
        }
        return this.idDocumentoVinculado;
    }

    public boolean isSetIdDocumentoVinculado() {
        return ((this.idDocumentoVinculado!= null)&&(!this.idDocumentoVinculado.isEmpty()));
    }

    public void unsetIdDocumentoVinculado() {
        this.idDocumentoVinculado = null;
    }

    /**
     * Obtém o valor da propriedade dataHora.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataHora() {
        return dataHora;
    }

    /**
     * Define o valor da propriedade dataHora.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataHora(DataHora value) {
        this.dataHora = value;
    }

    public boolean isSetDataHora() {
        return (this.dataHora!= null);
    }

    /**
     * Obtém o valor da propriedade nivelSigilo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getNivelSigilo() {
        return nivelSigilo;
    }

    /**
     * Define o valor da propriedade nivelSigilo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNivelSigilo(int value) {
        this.nivelSigilo = value;
    }

    public boolean isSetNivelSigilo() {
        return (this.nivelSigilo!= null);
    }

    public void unsetNivelSigilo() {
        this.nivelSigilo = null;
    }

    /**
     * Obtém o valor da propriedade idMovimento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdMovimento() {
        return idMovimento;
    }

    /**
     * Define o valor da propriedade idMovimento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdMovimento(String value) {
        this.idMovimento = value;
    }

    public boolean isSetIdMovimento() {
        return (this.idMovimento!= null);
    }

}
