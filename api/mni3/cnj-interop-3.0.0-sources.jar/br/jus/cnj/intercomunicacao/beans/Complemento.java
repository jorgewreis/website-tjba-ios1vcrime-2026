
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * 
 * Tipo de elemento destinado a permitir a inclusão de complementos de movimentações processuais. 
 * 			
 * 
 * <p>Classe Java de tipoComplemento simple type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;simpleType name="tipoComplemento">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoComplemento", propOrder = {
    "value"
})
public class Complemento
    implements Serializable
{

    @XmlValue
    protected String value;

    /**
     * 
     * Tipo de elemento destinado a permitir a inclusão de complementos de movimentações processuais. 
     * 			
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Define o valor da propriedade value.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

}
