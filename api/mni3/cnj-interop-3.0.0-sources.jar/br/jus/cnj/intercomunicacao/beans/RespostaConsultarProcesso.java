
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula os dados de resposta relativos a uma consulta de processo judicial. 
 * Retorna indicativo do sucesso da operação, mensagem a seu respeito e zero ou um elemento do tipo 'tipoProcessoJudicial', 
 * definido no namespace intercomunicao.xsd, contendo o processo consultado. Os elementos documentos do elemento processo 
 * poderão encerrar apenas binários encriptados cuja chave será fornecida na consultaTeorComunicacao, caso haja intimação 
 * pendente para o documento transferido. 
 * 
 * 
 * <p>Classe Java de respostaConsultarProcesso complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="respostaConsultarProcesso">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRecibo"/>
 *         &lt;element name="processo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoProcessoJudicial" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respostaConsultarProcesso", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recibo",
    "processo"
})
public class RespostaConsultarProcesso
    implements Serializable
{

    @XmlElement(required = true)
    protected Recibo recibo;
    protected ProcessoJudicial processo;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link Recibo }
     *     
     */
    public Recibo getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link Recibo }
     *     
     */
    public void setRecibo(Recibo value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

    /**
     * Obtém o valor da propriedade processo.
     * 
     * @return
     *     possible object is
     *     {@link ProcessoJudicial }
     *     
     */
    public ProcessoJudicial getProcesso() {
        return processo;
    }

    /**
     * Define o valor da propriedade processo.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessoJudicial }
     *     
     */
    public void setProcesso(ProcessoJudicial value) {
        this.processo = value;
    }

    public boolean isSetProcesso() {
        return (this.processo!= null);
    }

}
