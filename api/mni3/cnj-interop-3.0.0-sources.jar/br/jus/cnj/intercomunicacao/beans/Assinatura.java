
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir o armazenamento dos dados relacionados à assinatura um objeto, 
 * seja ela digital ou simples (uso de login e senha para assinar o documento). 
 * 			
 * 
 * <p>Classe Java de tipoAssinatura complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoAssinatura">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="signatarioLogin" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoSignatarioSimples"/>
 *           &lt;element name="assinaturaDigital" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAssinaturaDigital"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoAssinatura", propOrder = {
    "signatarioLogin",
    "assinaturaDigital"
})
public class Assinatura
    implements Serializable
{

    protected SignatarioSimples signatarioLogin;
    protected AssinaturaDigital assinaturaDigital;

    /**
     * Obtém o valor da propriedade signatarioLogin.
     * 
     * @return
     *     possible object is
     *     {@link SignatarioSimples }
     *     
     */
    public SignatarioSimples getSignatarioLogin() {
        return signatarioLogin;
    }

    /**
     * Define o valor da propriedade signatarioLogin.
     * 
     * @param value
     *     allowed object is
     *     {@link SignatarioSimples }
     *     
     */
    public void setSignatarioLogin(SignatarioSimples value) {
        this.signatarioLogin = value;
    }

    public boolean isSetSignatarioLogin() {
        return (this.signatarioLogin!= null);
    }

    /**
     * Obtém o valor da propriedade assinaturaDigital.
     * 
     * @return
     *     possible object is
     *     {@link AssinaturaDigital }
     *     
     */
    public AssinaturaDigital getAssinaturaDigital() {
        return assinaturaDigital;
    }

    /**
     * Define o valor da propriedade assinaturaDigital.
     * 
     * @param value
     *     allowed object is
     *     {@link AssinaturaDigital }
     *     
     */
    public void setAssinaturaDigital(AssinaturaDigital value) {
        this.assinaturaDigital = value;
    }

    public boolean isSetAssinaturaDigital() {
        return (this.assinaturaDigital!= null);
    }

}
