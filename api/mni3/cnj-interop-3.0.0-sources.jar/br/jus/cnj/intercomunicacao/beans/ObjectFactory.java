
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.jus.cnj.intercomunicacao.beans package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Intercomunicacao_QNAME = new QName("http://www.cnj.jus.br/mni/v300/intercomunicacao", "intercomunicacao");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.jus.cnj.intercomunicacao.beans
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RequisicaoConsultarAvisosPendentes }
     * 
     */
    public RequisicaoConsultarAvisosPendentes createRequisicaoConsultarAvisosPendentes() {
        return new RequisicaoConsultarAvisosPendentes();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarCompetencias }
     * 
     */
    public RequisicaoConsultarCompetencias createRequisicaoConsultarCompetencias() {
        return new RequisicaoConsultarCompetencias();
    }

    /**
     * Create an instance of {@link RequisicaoRemeterProcesso }
     * 
     */
    public RequisicaoRemeterProcesso createRequisicaoRemeterProcesso() {
        return new RequisicaoRemeterProcesso();
    }

    /**
     * Create an instance of {@link RequisicaoEntregarPeticao }
     * 
     */
    public RequisicaoEntregarPeticao createRequisicaoEntregarPeticao() {
        return new RequisicaoEntregarPeticao();
    }

    /**
     * Create an instance of {@link RespostaConsultarCompetencias }
     * 
     */
    public RespostaConsultarCompetencias createRespostaConsultarCompetencias() {
        return new RespostaConsultarCompetencias();
    }

    /**
     * Create an instance of {@link RespostaConsultarProcesso }
     * 
     */
    public RespostaConsultarProcesso createRespostaConsultarProcesso() {
        return new RespostaConsultarProcesso();
    }

    /**
     * Create an instance of {@link RespostaEntregarPeticaoInicial }
     * 
     */
    public RespostaEntregarPeticaoInicial createRespostaEntregarPeticaoInicial() {
        return new RespostaEntregarPeticaoInicial();
    }

    /**
     * Create an instance of {@link RespostaResponderComunicacao }
     * 
     */
    public RespostaResponderComunicacao createRespostaResponderComunicacao() {
        return new RespostaResponderComunicacao();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarDocumentosProcesso }
     * 
     */
    public RequisicaoConsultarDocumentosProcesso createRequisicaoConsultarDocumentosProcesso() {
        return new RequisicaoConsultarDocumentosProcesso();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarTeorComunicacao }
     * 
     */
    public RequisicaoConsultarTeorComunicacao createRequisicaoConsultarTeorComunicacao() {
        return new RequisicaoConsultarTeorComunicacao();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarRemessas }
     * 
     */
    public RequisicaoConsultarRemessas createRequisicaoConsultarRemessas() {
        return new RequisicaoConsultarRemessas();
    }

    /**
     * Create an instance of {@link RespostaConsultarAvisosPendentes }
     * 
     */
    public RespostaConsultarAvisosPendentes createRespostaConsultarAvisosPendentes() {
        return new RespostaConsultarAvisosPendentes();
    }

    /**
     * Create an instance of {@link RequisicaoConfirmarRecebimento }
     * 
     */
    public RequisicaoConfirmarRecebimento createRequisicaoConfirmarRecebimento() {
        return new RequisicaoConfirmarRecebimento();
    }

    /**
     * Create an instance of {@link RespostaConsultarTeorComunicacao }
     * 
     */
    public RespostaConsultarTeorComunicacao createRespostaConsultarTeorComunicacao() {
        return new RespostaConsultarTeorComunicacao();
    }

    /**
     * Create an instance of {@link RequisicaoEntregarPeticaoInicial }
     * 
     */
    public RequisicaoEntregarPeticaoInicial createRequisicaoEntregarPeticaoInicial() {
        return new RequisicaoEntregarPeticaoInicial();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarClasses }
     * 
     */
    public RequisicaoConsultarClasses createRequisicaoConsultarClasses() {
        return new RequisicaoConsultarClasses();
    }

    /**
     * Create an instance of {@link RespostaConsultarAssuntos }
     * 
     */
    public RespostaConsultarAssuntos createRespostaConsultarAssuntos() {
        return new RespostaConsultarAssuntos();
    }

    /**
     * Create an instance of {@link RespostaConsultarClasses }
     * 
     */
    public RespostaConsultarClasses createRespostaConsultarClasses() {
        return new RespostaConsultarClasses();
    }

    /**
     * Create an instance of {@link RespostaRemeterProcesso }
     * 
     */
    public RespostaRemeterProcesso createRespostaRemeterProcesso() {
        return new RespostaRemeterProcesso();
    }

    /**
     * Create an instance of {@link RespostaEntregarPeticao }
     * 
     */
    public RespostaEntregarPeticao createRespostaEntregarPeticao() {
        return new RespostaEntregarPeticao();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarProcesso }
     * 
     */
    public RequisicaoConsultarProcesso createRequisicaoConsultarProcesso() {
        return new RequisicaoConsultarProcesso();
    }

    /**
     * Create an instance of {@link RespostaConsultarAlteracao }
     * 
     */
    public RespostaConsultarAlteracao createRespostaConsultarAlteracao() {
        return new RespostaConsultarAlteracao();
    }

    /**
     * Create an instance of {@link RespostaConfirmarRecebimento }
     * 
     */
    public RespostaConfirmarRecebimento createRespostaConfirmarRecebimento() {
        return new RespostaConfirmarRecebimento();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarAlteracao }
     * 
     */
    public RequisicaoConsultarAlteracao createRequisicaoConsultarAlteracao() {
        return new RequisicaoConsultarAlteracao();
    }

    /**
     * Create an instance of {@link RequisicaoResponderComunicacao }
     * 
     */
    public RequisicaoResponderComunicacao createRequisicaoResponderComunicacao() {
        return new RequisicaoResponderComunicacao();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarLocalidades }
     * 
     */
    public RequisicaoConsultarLocalidades createRequisicaoConsultarLocalidades() {
        return new RequisicaoConsultarLocalidades();
    }

    /**
     * Create an instance of {@link RequisicaoConsultarAssuntos }
     * 
     */
    public RequisicaoConsultarAssuntos createRequisicaoConsultarAssuntos() {
        return new RequisicaoConsultarAssuntos();
    }

    /**
     * Create an instance of {@link RespostaConsultarDocumentosProcesso }
     * 
     */
    public RespostaConsultarDocumentosProcesso createRespostaConsultarDocumentosProcesso() {
        return new RespostaConsultarDocumentosProcesso();
    }

    /**
     * Create an instance of {@link RespostaConsultarLocalidades }
     * 
     */
    public RespostaConsultarLocalidades createRespostaConsultarLocalidades() {
        return new RespostaConsultarLocalidades();
    }

    /**
     * Create an instance of {@link RespostaConsultarRemessas }
     * 
     */
    public RespostaConsultarRemessas createRespostaConsultarRemessas() {
        return new RespostaConsultarRemessas();
    }

    /**
     * Create an instance of {@link Intercomunicacao }
     * 
     */
    public Intercomunicacao createIntercomunicacao() {
        return new Intercomunicacao();
    }

    /**
     * Create an instance of {@link AssuntoLocal }
     * 
     */
    public AssuntoLocal createAssuntoLocal() {
        return new AssuntoLocal();
    }

    /**
     * Create an instance of {@link Pessoa }
     * 
     */
    public Pessoa createPessoa() {
        return new Pessoa();
    }

    /**
     * Create an instance of {@link Cidade }
     * 
     */
    public Cidade createCidade() {
        return new Cidade();
    }

    /**
     * Create an instance of {@link NumeroUnico }
     * 
     */
    public NumeroUnico createNumeroUnico() {
        return new NumeroUnico();
    }

    /**
     * Create an instance of {@link DataHora }
     * 
     */
    public DataHora createDataHora() {
        return new DataHora();
    }

    /**
     * Create an instance of {@link MensagemResposta }
     * 
     */
    public MensagemResposta createMensagemResposta() {
        return new MensagemResposta();
    }

    /**
     * Create an instance of {@link ReciboManifestacaoProcessual }
     * 
     */
    public ReciboManifestacaoProcessual createReciboManifestacaoProcessual() {
        return new ReciboManifestacaoProcessual();
    }

    /**
     * Create an instance of {@link MovimentacaoProcessual }
     * 
     */
    public MovimentacaoProcessual createMovimentacaoProcessual() {
        return new MovimentacaoProcessual();
    }

    /**
     * Create an instance of {@link Autenticacao }
     * 
     */
    public Autenticacao createAutenticacao() {
        return new Autenticacao();
    }

    /**
     * Create an instance of {@link MovimentoLocal }
     * 
     */
    public MovimentoLocal createMovimentoLocal() {
        return new MovimentoLocal();
    }

    /**
     * Create an instance of {@link CabecalhoProcessual }
     * 
     */
    public CabecalhoProcessual createCabecalhoProcessual() {
        return new CabecalhoProcessual();
    }

    /**
     * Create an instance of {@link RelacionamentoPessoal }
     * 
     */
    public RelacionamentoPessoal createRelacionamentoPessoal() {
        return new RelacionamentoPessoal();
    }

    /**
     * Create an instance of {@link AutenticacaoSimples }
     * 
     */
    public AutenticacaoSimples createAutenticacaoSimples() {
        return new AutenticacaoSimples();
    }

    /**
     * Create an instance of {@link Assinatura }
     * 
     */
    public Assinatura createAssinatura() {
        return new Assinatura();
    }

    /**
     * Create an instance of {@link DocumentoIdentificacao }
     * 
     */
    public DocumentoIdentificacao createDocumentoIdentificacao() {
        return new DocumentoIdentificacao();
    }

    /**
     * Create an instance of {@link HistoricoDeslocamento }
     * 
     */
    public HistoricoDeslocamento createHistoricoDeslocamento() {
        return new HistoricoDeslocamento();
    }

    /**
     * Create an instance of {@link Data }
     * 
     */
    public Data createData() {
        return new Data();
    }

    /**
     * Create an instance of {@link DocumentoProcessual }
     * 
     */
    public DocumentoProcessual createDocumentoProcessual() {
        return new DocumentoProcessual();
    }

    /**
     * Create an instance of {@link Hash }
     * 
     */
    public Hash createHash() {
        return new Hash();
    }

    /**
     * Create an instance of {@link VinculacaoProcessual }
     * 
     */
    public VinculacaoProcessual createVinculacaoProcessual() {
        return new VinculacaoProcessual();
    }

    /**
     * Create an instance of {@link PoloProcessual }
     * 
     */
    public PoloProcessual createPoloProcessual() {
        return new PoloProcessual();
    }

    /**
     * Create an instance of {@link UnidadeJudiciaria }
     * 
     */
    public UnidadeJudiciaria createUnidadeJudiciaria() {
        return new UnidadeJudiciaria();
    }

    /**
     * Create an instance of {@link PessoaSimples }
     * 
     */
    public PessoaSimples createPessoaSimples() {
        return new PessoaSimples();
    }

    /**
     * Create an instance of {@link AvisoComunicacaoPendente }
     * 
     */
    public AvisoComunicacaoPendente createAvisoComunicacaoPendente() {
        return new AvisoComunicacaoPendente();
    }

    /**
     * Create an instance of {@link Endereco }
     * 
     */
    public Endereco createEndereco() {
        return new Endereco();
    }

    /**
     * Create an instance of {@link CadastroIdentificador }
     * 
     */
    public CadastroIdentificador createCadastroIdentificador() {
        return new CadastroIdentificador();
    }

    /**
     * Create an instance of {@link Identificador }
     * 
     */
    public Identificador createIdentificador() {
        return new Identificador();
    }

    /**
     * Create an instance of {@link Competencia }
     * 
     */
    public Competencia createCompetencia() {
        return new Competencia();
    }

    /**
     * Create an instance of {@link CabecalhoProcessoSimples }
     * 
     */
    public CabecalhoProcessoSimples createCabecalhoProcessoSimples() {
        return new CabecalhoProcessoSimples();
    }

    /**
     * Create an instance of {@link MovimentoNacional }
     * 
     */
    public MovimentoNacional createMovimentoNacional() {
        return new MovimentoNacional();
    }

    /**
     * Create an instance of {@link ConteudoDocumento }
     * 
     */
    public ConteudoDocumento createConteudoDocumento() {
        return new ConteudoDocumento();
    }

    /**
     * Create an instance of {@link ReciboTokenAutenticacao }
     * 
     */
    public ReciboTokenAutenticacao createReciboTokenAutenticacao() {
        return new ReciboTokenAutenticacao();
    }

    /**
     * Create an instance of {@link HistoricoRemessa }
     * 
     */
    public HistoricoRemessa createHistoricoRemessa() {
        return new HistoricoRemessa();
    }

    /**
     * Create an instance of {@link ProcessoJudicial }
     * 
     */
    public ProcessoJudicial createProcessoJudicial() {
        return new ProcessoJudicial();
    }

    /**
     * Create an instance of {@link CadastroOAB }
     * 
     */
    public CadastroOAB createCadastroOAB() {
        return new CadastroOAB();
    }

    /**
     * Create an instance of {@link OrgaoJulgador }
     * 
     */
    public OrgaoJulgador createOrgaoJulgador() {
        return new OrgaoJulgador();
    }

    /**
     * Create an instance of {@link SignatarioSimples }
     * 
     */
    public SignatarioSimples createSignatarioSimples() {
        return new SignatarioSimples();
    }

    /**
     * Create an instance of {@link ComunicacaoProcessual }
     * 
     */
    public ComunicacaoProcessual createComunicacaoProcessual() {
        return new ComunicacaoProcessual();
    }

    /**
     * Create an instance of {@link RepresentanteProcessual }
     * 
     */
    public RepresentanteProcessual createRepresentanteProcessual() {
        return new RepresentanteProcessual();
    }

    /**
     * Create an instance of {@link Localidade }
     * 
     */
    public Localidade createLocalidade() {
        return new Localidade();
    }

    /**
     * Create an instance of {@link Recibo }
     * 
     */
    public Recibo createRecibo() {
        return new Recibo();
    }

    /**
     * Create an instance of {@link RespostaAviso }
     * 
     */
    public RespostaAviso createRespostaAviso() {
        return new RespostaAviso();
    }

    /**
     * Create an instance of {@link ReciboDocumentoProtocolado }
     * 
     */
    public ReciboDocumentoProtocolado createReciboDocumentoProtocolado() {
        return new ReciboDocumentoProtocolado();
    }

    /**
     * Create an instance of {@link Parte }
     * 
     */
    public Parte createParte() {
        return new Parte();
    }

    /**
     * Create an instance of {@link AssinaturaDigital }
     * 
     */
    public AssinaturaDigital createAssinaturaDigital() {
        return new AssinaturaDigital();
    }

    /**
     * Create an instance of {@link AssuntoProcessual }
     * 
     */
    public AssuntoProcessual createAssuntoProcessual() {
        return new AssuntoProcessual();
    }

    /**
     * Create an instance of {@link Complemento }
     * 
     */
    public Complemento createComplemento() {
        return new Complemento();
    }

    /**
     * Create an instance of {@link Parametro }
     * 
     */
    public Parametro createParametro() {
        return new Parametro();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Intercomunicacao }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.cnj.jus.br/mni/v300/intercomunicacao", name = "intercomunicacao")
    public JAXBElement<Intercomunicacao> createIntercomunicacao(Intercomunicacao value) {
        return new JAXBElement<Intercomunicacao>(_Intercomunicacao_QNAME, Intercomunicacao.class, null, value);
    }

}
