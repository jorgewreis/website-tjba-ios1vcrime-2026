
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * 
 * Tipo destinado a permitir a inclusão de dados relativos à inscrição do advogado na Ordem dos Advogados 
 * do Brasil. O número da ordem deve ser incluído no formato CCDDDDDDDC, sendo os primeiros 'C' dois caracteres indicativos 
 * da unidade federativa brasileira em que há a inscrição, os sete digitos 'D' seguintes o número da inscrição, devendo 
 * incluir zeros ('0') à esquerda caso o número tenha menos de 7 dígitos e o último caracter a letra identificadora 
 * do tipo de inscrição. 
 * 			
 * 
 * <p>Classe Java de tipoCadastroOAB simple type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;simpleType name="tipoCadastroOAB">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;pattern value="[A-Za-z]{2}\d{7}[A-Za-z]{1}"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCadastroOAB", propOrder = {
    "value"
})
public class CadastroOAB
    implements Serializable
{

    @XmlValue
    protected String value;

    /**
     * 
     * Tipo destinado a permitir a inclusão de dados relativos à inscrição do advogado na Ordem dos Advogados 
     * do Brasil. O número da ordem deve ser incluído no formato CCDDDDDDDC, sendo os primeiros 'C' dois caracteres indicativos 
     * da unidade federativa brasileira em que há a inscrição, os sete digitos 'D' seguintes o número da inscrição, devendo 
     * incluir zeros ('0') à esquerda caso o número tenha menos de 7 dígitos e o último caracter a letra identificadora 
     * do tipo de inscrição. 
     * 			
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Define o valor da propriedade value.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

}
