
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo destinado a permitir a identificação de um assunto processual. 
 * 			
 * 
 * <p>Classe Java de tipoAssuntoProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoAssuntoProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="codigoNacional" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="assuntoLocal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAssuntoLocal"/>
 *       &lt;/choice>
 *       &lt;attribute name="principal" type="{http://www.w3.org/2001/XMLSchema}boolean" default="false" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoAssuntoProcessual", propOrder = {
    "codigoNacional",
    "assuntoLocal"
})
public class AssuntoProcessual
    implements Serializable
{

    protected Integer codigoNacional;
    protected AssuntoLocal assuntoLocal;
    @XmlAttribute(name = "principal")
    protected Boolean principal;

    /**
     * Obtém o valor da propriedade codigoNacional.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoNacional() {
        return codigoNacional;
    }

    /**
     * Define o valor da propriedade codigoNacional.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoNacional(Integer value) {
        this.codigoNacional = value;
    }

    public boolean isSetCodigoNacional() {
        return (this.codigoNacional!= null);
    }

    /**
     * Obtém o valor da propriedade assuntoLocal.
     * 
     * @return
     *     possible object is
     *     {@link AssuntoLocal }
     *     
     */
    public AssuntoLocal getAssuntoLocal() {
        return assuntoLocal;
    }

    /**
     * Define o valor da propriedade assuntoLocal.
     * 
     * @param value
     *     allowed object is
     *     {@link AssuntoLocal }
     *     
     */
    public void setAssuntoLocal(AssuntoLocal value) {
        this.assuntoLocal = value;
    }

    public boolean isSetAssuntoLocal() {
        return (this.assuntoLocal!= null);
    }

    /**
     * Obtém o valor da propriedade principal.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isPrincipal() {
        if (principal == null) {
            return false;
        } else {
            return principal;
        }
    }

    /**
     * Define o valor da propriedade principal.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPrincipal(boolean value) {
        this.principal = value;
    }

    public boolean isSetPrincipal() {
        return (this.principal!= null);
    }

    public void unsetPrincipal() {
        this.principal = null;
    }

}
