
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir o armazenamento dos dados relacionados à assinatura digital 
 * de um objeto. 
 * 			
 * 
 * <p>Classe Java de tipoAssinaturaDigital complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoAssinaturaDigital">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="assinatura" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *         &lt;element name="dataAssinatura" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="cadeiaCertificado" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="algoritmo">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="sha1WithRSAEncryption"/>
 *               &lt;enumeration value="sha256WithRSAEncryption"/>
 *               &lt;enumeration value="sha256WithECDSAEncryption"/>
 *               &lt;enumeration value="sha512WithRSAEncryption"/>
 *               &lt;enumeration value="sha512WithECDSAEncryption"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codificacaoCadeiaCertificado" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoAssinaturaDigital", propOrder = {
    "assinatura",
    "dataAssinatura",
    "cadeiaCertificado",
    "algoritmo",
    "codificacaoCadeiaCertificado"
})
public class AssinaturaDigital
    implements Serializable
{

    @XmlElement(required = true)
    @XmlMimeType("application/octet-stream")
    protected DataHandler assinatura;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataAssinatura;
    @XmlElement(required = true)
    protected String cadeiaCertificado;
    @XmlElement(required = true, defaultValue = "sha256WithRSAEncryption")
    protected String algoritmo;
    @XmlElement(required = true, defaultValue = "PEM")
    protected String codificacaoCadeiaCertificado;

    /**
     * Obtém o valor da propriedade assinatura.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getAssinatura() {
        return assinatura;
    }

    /**
     * Define o valor da propriedade assinatura.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setAssinatura(DataHandler value) {
        this.assinatura = value;
    }

    public boolean isSetAssinatura() {
        return (this.assinatura!= null);
    }

    /**
     * Obtém o valor da propriedade dataAssinatura.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataAssinatura() {
        return dataAssinatura;
    }

    /**
     * Define o valor da propriedade dataAssinatura.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataAssinatura(DataHora value) {
        this.dataAssinatura = value;
    }

    public boolean isSetDataAssinatura() {
        return (this.dataAssinatura!= null);
    }

    /**
     * Obtém o valor da propriedade cadeiaCertificado.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCadeiaCertificado() {
        return cadeiaCertificado;
    }

    /**
     * Define o valor da propriedade cadeiaCertificado.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCadeiaCertificado(String value) {
        this.cadeiaCertificado = value;
    }

    public boolean isSetCadeiaCertificado() {
        return (this.cadeiaCertificado!= null);
    }

    /**
     * Obtém o valor da propriedade algoritmo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAlgoritmo() {
        return algoritmo;
    }

    /**
     * Define o valor da propriedade algoritmo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAlgoritmo(String value) {
        this.algoritmo = value;
    }

    public boolean isSetAlgoritmo() {
        return (this.algoritmo!= null);
    }

    /**
     * Obtém o valor da propriedade codificacaoCadeiaCertificado.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodificacaoCadeiaCertificado() {
        return codificacaoCadeiaCertificado;
    }

    /**
     * Define o valor da propriedade codificacaoCadeiaCertificado.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodificacaoCadeiaCertificado(String value) {
        this.codificacaoCadeiaCertificado = value;
    }

    public boolean isSetCodificacaoCadeiaCertificado() {
        return (this.codificacaoCadeiaCertificado!= null);
    }

}
