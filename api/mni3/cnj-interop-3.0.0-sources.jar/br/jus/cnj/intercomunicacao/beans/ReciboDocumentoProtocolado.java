
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar hash, horário e número do processo judicial dos documentos 
 * originários de manifestações processuais e remessa de processos. 
 * 			
 * 
 * <p>Classe Java de tipoReciboDocumentoProtocolado complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoReciboDocumentoProtocolado">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="hashDocumento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoHash"/>
 *         &lt;element name="dataRecebimento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoReciboDocumentoProtocolado", propOrder = {
    "hashDocumento",
    "dataRecebimento",
    "numeroProcesso"
})
public class ReciboDocumentoProtocolado
    implements Serializable
{

    @XmlElement(required = true)
    protected Hash hashDocumento;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataRecebimento;
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;

    /**
     * Obtém o valor da propriedade hashDocumento.
     * 
     * @return
     *     possible object is
     *     {@link Hash }
     *     
     */
    public Hash getHashDocumento() {
        return hashDocumento;
    }

    /**
     * Define o valor da propriedade hashDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link Hash }
     *     
     */
    public void setHashDocumento(Hash value) {
        this.hashDocumento = value;
    }

    public boolean isSetHashDocumento() {
        return (this.hashDocumento!= null);
    }

    /**
     * Obtém o valor da propriedade dataRecebimento.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataRecebimento() {
        return dataRecebimento;
    }

    /**
     * Define o valor da propriedade dataRecebimento.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataRecebimento(DataHora value) {
        this.dataRecebimento = value;
    }

    public boolean isSetDataRecebimento() {
        return (this.dataRecebimento!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

}
