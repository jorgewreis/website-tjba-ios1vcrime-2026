
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoOrgaoJulgador complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoOrgaoJulgador">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="instancia">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ORIG"/>
 *               &lt;enumeration value="REV"/>
 *               &lt;enumeration value="ESP"/>
 *               &lt;enumeration value="EXT"/>
 *               &lt;enumeration value="ADM"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codigoLocalidade" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="orgaoColegiado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoOrgaoJulgador" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoOrgaoJulgador", propOrder = {
    "codigo",
    "nome",
    "instancia",
    "codigoLocalidade",
    "orgaoColegiado"
})
public class OrgaoJulgador
    implements Serializable
{

    @XmlElement(required = true)
    protected String codigo;
    @XmlElement(required = true)
    protected String nome;
    @XmlElement(required = true)
    protected String instancia;
    protected String codigoLocalidade;
    protected OrgaoJulgador orgaoColegiado;

    /**
     * Obtém o valor da propriedade codigo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define o valor da propriedade codigo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    public boolean isSetCodigo() {
        return (this.codigo!= null);
    }

    /**
     * Obtém o valor da propriedade nome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    public boolean isSetNome() {
        return (this.nome!= null);
    }

    /**
     * Obtém o valor da propriedade instancia.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInstancia() {
        return instancia;
    }

    /**
     * Define o valor da propriedade instancia.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInstancia(String value) {
        this.instancia = value;
    }

    public boolean isSetInstancia() {
        return (this.instancia!= null);
    }

    /**
     * Obtém o valor da propriedade codigoLocalidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoLocalidade() {
        return codigoLocalidade;
    }

    /**
     * Define o valor da propriedade codigoLocalidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoLocalidade(String value) {
        this.codigoLocalidade = value;
    }

    public boolean isSetCodigoLocalidade() {
        return (this.codigoLocalidade!= null);
    }

    /**
     * Obtém o valor da propriedade orgaoColegiado.
     * 
     * @return
     *     possible object is
     *     {@link OrgaoJulgador }
     *     
     */
    public OrgaoJulgador getOrgaoColegiado() {
        return orgaoColegiado;
    }

    /**
     * Define o valor da propriedade orgaoColegiado.
     * 
     * @param value
     *     allowed object is
     *     {@link OrgaoJulgador }
     *     
     */
    public void setOrgaoColegiado(OrgaoJulgador value) {
        this.orgaoColegiado = value;
    }

    public boolean isSetOrgaoColegiado() {
        return (this.orgaoColegiado!= null);
    }

}
