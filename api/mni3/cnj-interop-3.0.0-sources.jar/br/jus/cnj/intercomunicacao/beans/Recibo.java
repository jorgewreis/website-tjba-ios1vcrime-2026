
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula elementos comuns a respostas decorrentes de chamada a operações do 
 * modelo. Sendo bem sucedida ou não, deve ser fornecido protocolo da operação. 
 * 			
 * 
 * <p>Classe Java de tipoRecibo complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoRecibo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sucesso" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="mensagens" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMensagemResposta" maxOccurs="unbounded"/>
 *         &lt;element name="reciboToken" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoReciboTokenAutenticacao" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoRecibo", propOrder = {
    "sucesso",
    "mensagens",
    "reciboToken"
})
public class Recibo
    implements Serializable
{

    protected boolean sucesso;
    @XmlElement(required = true)
    protected List<MensagemResposta> mensagens;
    protected ReciboTokenAutenticacao reciboToken;

    /**
     * Obtém o valor da propriedade sucesso.
     * 
     */
    public boolean isSucesso() {
        return sucesso;
    }

    /**
     * Define o valor da propriedade sucesso.
     * 
     */
    public void setSucesso(boolean value) {
        this.sucesso = value;
    }

    public boolean isSetSucesso() {
        return true;
    }

    /**
     * Gets the value of the mensagens property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mensagens property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMensagens().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MensagemResposta }
     * 
     * 
     */
    public List<MensagemResposta> getMensagens() {
        if (mensagens == null) {
            mensagens = new ArrayList<MensagemResposta>();
        }
        return this.mensagens;
    }

    public boolean isSetMensagens() {
        return ((this.mensagens!= null)&&(!this.mensagens.isEmpty()));
    }

    public void unsetMensagens() {
        this.mensagens = null;
    }

    /**
     * Obtém o valor da propriedade reciboToken.
     * 
     * @return
     *     possible object is
     *     {@link ReciboTokenAutenticacao }
     *     
     */
    public ReciboTokenAutenticacao getReciboToken() {
        return reciboToken;
    }

    /**
     * Define o valor da propriedade reciboToken.
     * 
     * @param value
     *     allowed object is
     *     {@link ReciboTokenAutenticacao }
     *     
     */
    public void setReciboToken(ReciboTokenAutenticacao value) {
        this.reciboToken = value;
    }

    public boolean isSetReciboToken() {
        return (this.reciboToken!= null);
    }

}
