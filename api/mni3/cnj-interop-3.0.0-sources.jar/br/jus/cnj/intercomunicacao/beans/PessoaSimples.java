
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir a individualização de uma pessoa física ou jurídica de modo 
 * simplificado, ou seja, somente a quantidade de atributos suficientes para sua identificação. 
 * 			
 * 
 * <p>Classe Java de tipoPessoaSimples complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoPessoaSimples">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="nome" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="qualificacaoPessoa" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeQualificacaoPessoa"/>
 *         &lt;choice>
 *           &lt;element name="numeroDocumentoPrincipal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCadastroIdentificador"/>
 *           &lt;element name="justificativaAusenciaDocumentoPrincipal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoPessoaSimples", propOrder = {
    "nome",
    "qualificacaoPessoa",
    "numeroDocumentoPrincipal",
    "justificativaAusenciaDocumentoPrincipal"
})
public class PessoaSimples
    implements Serializable
{

    @XmlElement(required = true)
    protected String nome;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeQualificacaoPessoa qualificacaoPessoa;
    @XmlSchemaType(name = "string")
    protected CadastroIdentificador numeroDocumentoPrincipal;
    protected String justificativaAusenciaDocumentoPrincipal;

    /**
     * Obtém o valor da propriedade nome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o valor da propriedade nome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    public boolean isSetNome() {
        return (this.nome!= null);
    }

    /**
     * Obtém o valor da propriedade qualificacaoPessoa.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeQualificacaoPessoa }
     *     
     */
    public ModalidadeQualificacaoPessoa getQualificacaoPessoa() {
        return qualificacaoPessoa;
    }

    /**
     * Define o valor da propriedade qualificacaoPessoa.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeQualificacaoPessoa }
     *     
     */
    public void setQualificacaoPessoa(ModalidadeQualificacaoPessoa value) {
        this.qualificacaoPessoa = value;
    }

    public boolean isSetQualificacaoPessoa() {
        return (this.qualificacaoPessoa!= null);
    }

    /**
     * Obtém o valor da propriedade numeroDocumentoPrincipal.
     * 
     * @return
     *     possible object is
     *     {@link CadastroIdentificador }
     *     
     */
    public CadastroIdentificador getNumeroDocumentoPrincipal() {
        return numeroDocumentoPrincipal;
    }

    /**
     * Define o valor da propriedade numeroDocumentoPrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link CadastroIdentificador }
     *     
     */
    public void setNumeroDocumentoPrincipal(CadastroIdentificador value) {
        this.numeroDocumentoPrincipal = value;
    }

    public boolean isSetNumeroDocumentoPrincipal() {
        return (this.numeroDocumentoPrincipal!= null);
    }

    /**
     * Obtém o valor da propriedade justificativaAusenciaDocumentoPrincipal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJustificativaAusenciaDocumentoPrincipal() {
        return justificativaAusenciaDocumentoPrincipal;
    }

    /**
     * Define o valor da propriedade justificativaAusenciaDocumentoPrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJustificativaAusenciaDocumentoPrincipal(String value) {
        this.justificativaAusenciaDocumentoPrincipal = value;
    }

    public boolean isSetJustificativaAusenciaDocumentoPrincipal() {
        return (this.justificativaAusenciaDocumentoPrincipal!= null);
    }

}
