
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula dados essenciais a confirmação de envio de processo entre tribunais. 
 * 
 * 			
 * 
 * <p>Classe Java de requisicaoConfirmarRecebimento complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConfirmarRecebimento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recebedor" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacao"/>
 *         &lt;element name="protocolo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConfirmarRecebimento", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recebedor",
    "protocolo"
})
public class RequisicaoConfirmarRecebimento
    implements Serializable
{

    @XmlElement(required = true)
    protected Autenticacao recebedor;
    @XmlElement(required = true)
    protected String protocolo;

    /**
     * Obtém o valor da propriedade recebedor.
     * 
     * @return
     *     possible object is
     *     {@link Autenticacao }
     *     
     */
    public Autenticacao getRecebedor() {
        return recebedor;
    }

    /**
     * Define o valor da propriedade recebedor.
     * 
     * @param value
     *     allowed object is
     *     {@link Autenticacao }
     *     
     */
    public void setRecebedor(Autenticacao value) {
        this.recebedor = value;
    }

    public boolean isSetRecebedor() {
        return (this.recebedor!= null);
    }

    /**
     * Obtém o valor da propriedade protocolo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtocolo() {
        return protocolo;
    }

    /**
     * Define o valor da propriedade protocolo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtocolo(String value) {
        this.protocolo = value;
    }

    public boolean isSetProtocolo() {
        return (this.protocolo!= null);
    }

}
