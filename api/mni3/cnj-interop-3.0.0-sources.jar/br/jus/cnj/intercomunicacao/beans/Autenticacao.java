
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar as credenciais de acesso ao sistema. 
 * 			
 * 
 * <p>Classe Java de tipoAutenticacao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoAutenticacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *           &lt;element name="autenticacaoSimples" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacaoSimples"/>
 *           &lt;element name="autenticacaoCertificada" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAssinaturaDigital"/>
 *         &lt;/choice>
 *         &lt;element name="pessoaVinculada" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCadastroIdentificador" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoAutenticacao", propOrder = {
    "token",
    "autenticacaoSimples",
    "autenticacaoCertificada",
    "pessoaVinculada"
})
public class Autenticacao
    implements Serializable
{

    protected String token;
    protected AutenticacaoSimples autenticacaoSimples;
    protected AssinaturaDigital autenticacaoCertificada;
    @XmlSchemaType(name = "string")
    protected CadastroIdentificador pessoaVinculada;

    /**
     * Obtém o valor da propriedade token.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Define o valor da propriedade token.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    public boolean isSetToken() {
        return (this.token!= null);
    }

    /**
     * Obtém o valor da propriedade autenticacaoSimples.
     * 
     * @return
     *     possible object is
     *     {@link AutenticacaoSimples }
     *     
     */
    public AutenticacaoSimples getAutenticacaoSimples() {
        return autenticacaoSimples;
    }

    /**
     * Define o valor da propriedade autenticacaoSimples.
     * 
     * @param value
     *     allowed object is
     *     {@link AutenticacaoSimples }
     *     
     */
    public void setAutenticacaoSimples(AutenticacaoSimples value) {
        this.autenticacaoSimples = value;
    }

    public boolean isSetAutenticacaoSimples() {
        return (this.autenticacaoSimples!= null);
    }

    /**
     * Obtém o valor da propriedade autenticacaoCertificada.
     * 
     * @return
     *     possible object is
     *     {@link AssinaturaDigital }
     *     
     */
    public AssinaturaDigital getAutenticacaoCertificada() {
        return autenticacaoCertificada;
    }

    /**
     * Define o valor da propriedade autenticacaoCertificada.
     * 
     * @param value
     *     allowed object is
     *     {@link AssinaturaDigital }
     *     
     */
    public void setAutenticacaoCertificada(AssinaturaDigital value) {
        this.autenticacaoCertificada = value;
    }

    public boolean isSetAutenticacaoCertificada() {
        return (this.autenticacaoCertificada!= null);
    }

    /**
     * Obtém o valor da propriedade pessoaVinculada.
     * 
     * @return
     *     possible object is
     *     {@link CadastroIdentificador }
     *     
     */
    public CadastroIdentificador getPessoaVinculada() {
        return pessoaVinculada;
    }

    /**
     * Define o valor da propriedade pessoaVinculada.
     * 
     * @param value
     *     allowed object is
     *     {@link CadastroIdentificador }
     *     
     */
    public void setPessoaVinculada(CadastroIdentificador value) {
        this.pessoaVinculada = value;
    }

    public boolean isSetPessoaVinculada() {
        return (this.pessoaVinculada!= null);
    }

}
