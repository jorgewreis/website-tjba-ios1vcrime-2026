
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula os dados da remessa de processo entre instâncias. 
 * 			
 * 
 * <p>Classe Java de requisicaoRemeterProcesso complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoRemeterProcesso">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="manifestante" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacao"/>
 *         &lt;choice>
 *           &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *           &lt;element name="dadosBasicos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCabecalhoProcesso"/>
 *         &lt;/choice>
 *         &lt;element name="documentos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" maxOccurs="unbounded"/>
 *         &lt;element name="dataEnvio" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="movimento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoProcessual" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="fluxo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoNacional"/>
 *         &lt;element name="tribunalRetorno" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoUnidadeJudiciaria" minOccurs="0"/>
 *         &lt;element name="parametros" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoParametro" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoRemeterProcesso", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "manifestante",
    "numeroProcesso",
    "dadosBasicos",
    "documentos",
    "dataEnvio",
    "movimento",
    "fluxo",
    "tribunalRetorno",
    "parametros",
    "any"
})
public class RequisicaoRemeterProcesso
    implements Serializable
{

    @XmlElement(required = true)
    protected Autenticacao manifestante;
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    protected CabecalhoProcessual dadosBasicos;
    @XmlElement(required = true)
    protected List<DocumentoProcessual> documentos;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataEnvio;
    protected List<MovimentacaoProcessual> movimento;
    @XmlElement(required = true)
    protected MovimentoNacional fluxo;
    protected UnidadeJudiciaria tribunalRetorno;
    protected List<Parametro> parametros;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade manifestante.
     * 
     * @return
     *     possible object is
     *     {@link Autenticacao }
     *     
     */
    public Autenticacao getManifestante() {
        return manifestante;
    }

    /**
     * Define o valor da propriedade manifestante.
     * 
     * @param value
     *     allowed object is
     *     {@link Autenticacao }
     *     
     */
    public void setManifestante(Autenticacao value) {
        this.manifestante = value;
    }

    public boolean isSetManifestante() {
        return (this.manifestante!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade dadosBasicos.
     * 
     * @return
     *     possible object is
     *     {@link CabecalhoProcessual }
     *     
     */
    public CabecalhoProcessual getDadosBasicos() {
        return dadosBasicos;
    }

    /**
     * Define o valor da propriedade dadosBasicos.
     * 
     * @param value
     *     allowed object is
     *     {@link CabecalhoProcessual }
     *     
     */
    public void setDadosBasicos(CabecalhoProcessual value) {
        this.dadosBasicos = value;
    }

    public boolean isSetDadosBasicos() {
        return (this.dadosBasicos!= null);
    }

    /**
     * Gets the value of the documentos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoProcessual }
     * 
     * 
     */
    public List<DocumentoProcessual> getDocumentos() {
        if (documentos == null) {
            documentos = new ArrayList<DocumentoProcessual>();
        }
        return this.documentos;
    }

    public boolean isSetDocumentos() {
        return ((this.documentos!= null)&&(!this.documentos.isEmpty()));
    }

    public void unsetDocumentos() {
        this.documentos = null;
    }

    /**
     * Obtém o valor da propriedade dataEnvio.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataEnvio() {
        return dataEnvio;
    }

    /**
     * Define o valor da propriedade dataEnvio.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataEnvio(DataHora value) {
        this.dataEnvio = value;
    }

    public boolean isSetDataEnvio() {
        return (this.dataEnvio!= null);
    }

    /**
     * Gets the value of the movimento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the movimento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMovimento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MovimentacaoProcessual }
     * 
     * 
     */
    public List<MovimentacaoProcessual> getMovimento() {
        if (movimento == null) {
            movimento = new ArrayList<MovimentacaoProcessual>();
        }
        return this.movimento;
    }

    public boolean isSetMovimento() {
        return ((this.movimento!= null)&&(!this.movimento.isEmpty()));
    }

    public void unsetMovimento() {
        this.movimento = null;
    }

    /**
     * Obtém o valor da propriedade fluxo.
     * 
     * @return
     *     possible object is
     *     {@link MovimentoNacional }
     *     
     */
    public MovimentoNacional getFluxo() {
        return fluxo;
    }

    /**
     * Define o valor da propriedade fluxo.
     * 
     * @param value
     *     allowed object is
     *     {@link MovimentoNacional }
     *     
     */
    public void setFluxo(MovimentoNacional value) {
        this.fluxo = value;
    }

    public boolean isSetFluxo() {
        return (this.fluxo!= null);
    }

    /**
     * Obtém o valor da propriedade tribunalRetorno.
     * 
     * @return
     *     possible object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public UnidadeJudiciaria getTribunalRetorno() {
        return tribunalRetorno;
    }

    /**
     * Define o valor da propriedade tribunalRetorno.
     * 
     * @param value
     *     allowed object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public void setTribunalRetorno(UnidadeJudiciaria value) {
        this.tribunalRetorno = value;
    }

    public boolean isSetTribunalRetorno() {
        return (this.tribunalRetorno!= null);
    }

    /**
     * Gets the value of the parametros property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parametros property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParametros().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parametro }
     * 
     * 
     */
    public List<Parametro> getParametros() {
        if (parametros == null) {
            parametros = new ArrayList<Parametro>();
        }
        return this.parametros;
    }

    public boolean isSetParametros() {
        return ((this.parametros!= null)&&(!this.parametros.isEmpty()));
    }

    public void unsetParametros() {
        this.parametros = null;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
