
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a representar os dados básicos do cabeçalho do processo: número, localidade, 
 * classe, assuntos e órgão julgador. 
 * 			
 * 
 * <p>Classe Java de tipoCabecalhoProcessoSimples complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoCabecalhoProcessoSimples">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numero" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *         &lt;element name="classeProcessual">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="orgaoJulgador" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoOrgaoJulgador" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCabecalhoProcessoSimples", propOrder = {
    "numero",
    "classeProcessual",
    "orgaoJulgador"
})
public class CabecalhoProcessoSimples
    implements Serializable
{

    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected NumeroUnico numero;
    protected int classeProcessual;
    protected OrgaoJulgador orgaoJulgador;

    /**
     * Obtém o valor da propriedade numero.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumero() {
        return numero;
    }

    /**
     * Define o valor da propriedade numero.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumero(NumeroUnico value) {
        this.numero = value;
    }

    public boolean isSetNumero() {
        return (this.numero!= null);
    }

    /**
     * Obtém o valor da propriedade classeProcessual.
     * 
     */
    public int getClasseProcessual() {
        return classeProcessual;
    }

    /**
     * Define o valor da propriedade classeProcessual.
     * 
     */
    public void setClasseProcessual(int value) {
        this.classeProcessual = value;
    }

    public boolean isSetClasseProcessual() {
        return true;
    }

    /**
     * Obtém o valor da propriedade orgaoJulgador.
     * 
     * @return
     *     possible object is
     *     {@link OrgaoJulgador }
     *     
     */
    public OrgaoJulgador getOrgaoJulgador() {
        return orgaoJulgador;
    }

    /**
     * Define o valor da propriedade orgaoJulgador.
     * 
     * @param value
     *     allowed object is
     *     {@link OrgaoJulgador }
     *     
     */
    public void setOrgaoJulgador(OrgaoJulgador value) {
        this.orgaoJulgador = value;
    }

    public boolean isSetOrgaoJulgador() {
        return (this.orgaoJulgador!= null);
    }

}
