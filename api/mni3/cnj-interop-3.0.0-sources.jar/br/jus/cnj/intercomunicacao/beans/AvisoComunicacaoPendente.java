
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a indicar a existência de uma comunicação pendente. 
 * 			
 * 
 * <p>Classe Java de tipoAvisoComunicacaoPendente complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoAvisoComunicacaoPendente">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAviso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}identificadorComunicacao"/>
 *         &lt;element name="tipoComunicacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeTipoComunicacao"/>
 *         &lt;element name="destinatario" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoaSimples"/>
 *         &lt;element name="processo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCabecalhoProcessoSimples"/>
 *         &lt;element name="remetente" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoOrgaoJulgador"/>
 *         &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *         &lt;element name="dataDisponibilizacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="tipoPrazo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadePrazo"/>
 *         &lt;element name="prazo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoAvisoComunicacaoPendente", propOrder = {
    "idAviso",
    "tipoComunicacao",
    "destinatario",
    "processo",
    "remetente",
    "numeroProcesso",
    "dataDisponibilizacao",
    "tipoPrazo",
    "prazo"
})
public class AvisoComunicacaoPendente
    implements Serializable
{

    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected Identificador idAviso;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeTipoComunicacao tipoComunicacao;
    @XmlElement(required = true)
    protected PessoaSimples destinatario;
    @XmlElement(required = true)
    protected CabecalhoProcessoSimples processo;
    @XmlElement(required = true)
    protected OrgaoJulgador remetente;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataDisponibilizacao;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadePrazo tipoPrazo;
    protected Integer prazo;

    /**
     * Obtém o valor da propriedade idAviso.
     * 
     * @return
     *     possible object is
     *     {@link Identificador }
     *     
     */
    public Identificador getIdAviso() {
        return idAviso;
    }

    /**
     * Define o valor da propriedade idAviso.
     * 
     * @param value
     *     allowed object is
     *     {@link Identificador }
     *     
     */
    public void setIdAviso(Identificador value) {
        this.idAviso = value;
    }

    public boolean isSetIdAviso() {
        return (this.idAviso!= null);
    }

    /**
     * Obtém o valor da propriedade tipoComunicacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeTipoComunicacao }
     *     
     */
    public ModalidadeTipoComunicacao getTipoComunicacao() {
        return tipoComunicacao;
    }

    /**
     * Define o valor da propriedade tipoComunicacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeTipoComunicacao }
     *     
     */
    public void setTipoComunicacao(ModalidadeTipoComunicacao value) {
        this.tipoComunicacao = value;
    }

    public boolean isSetTipoComunicacao() {
        return (this.tipoComunicacao!= null);
    }

    /**
     * Obtém o valor da propriedade destinatario.
     * 
     * @return
     *     possible object is
     *     {@link PessoaSimples }
     *     
     */
    public PessoaSimples getDestinatario() {
        return destinatario;
    }

    /**
     * Define o valor da propriedade destinatario.
     * 
     * @param value
     *     allowed object is
     *     {@link PessoaSimples }
     *     
     */
    public void setDestinatario(PessoaSimples value) {
        this.destinatario = value;
    }

    public boolean isSetDestinatario() {
        return (this.destinatario!= null);
    }

    /**
     * Obtém o valor da propriedade processo.
     * 
     * @return
     *     possible object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public CabecalhoProcessoSimples getProcesso() {
        return processo;
    }

    /**
     * Define o valor da propriedade processo.
     * 
     * @param value
     *     allowed object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public void setProcesso(CabecalhoProcessoSimples value) {
        this.processo = value;
    }

    public boolean isSetProcesso() {
        return (this.processo!= null);
    }

    /**
     * Obtém o valor da propriedade remetente.
     * 
     * @return
     *     possible object is
     *     {@link OrgaoJulgador }
     *     
     */
    public OrgaoJulgador getRemetente() {
        return remetente;
    }

    /**
     * Define o valor da propriedade remetente.
     * 
     * @param value
     *     allowed object is
     *     {@link OrgaoJulgador }
     *     
     */
    public void setRemetente(OrgaoJulgador value) {
        this.remetente = value;
    }

    public boolean isSetRemetente() {
        return (this.remetente!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade dataDisponibilizacao.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataDisponibilizacao() {
        return dataDisponibilizacao;
    }

    /**
     * Define o valor da propriedade dataDisponibilizacao.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataDisponibilizacao(DataHora value) {
        this.dataDisponibilizacao = value;
    }

    public boolean isSetDataDisponibilizacao() {
        return (this.dataDisponibilizacao!= null);
    }

    /**
     * Obtém o valor da propriedade tipoPrazo.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadePrazo }
     *     
     */
    public ModalidadePrazo getTipoPrazo() {
        return tipoPrazo;
    }

    /**
     * Define o valor da propriedade tipoPrazo.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadePrazo }
     *     
     */
    public void setTipoPrazo(ModalidadePrazo value) {
        this.tipoPrazo = value;
    }

    public boolean isSetTipoPrazo() {
        return (this.tipoPrazo!= null);
    }

    /**
     * Obtém o valor da propriedade prazo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPrazo() {
        return prazo;
    }

    /**
     * Define o valor da propriedade prazo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPrazo(Integer value) {
        this.prazo = value;
    }

    public boolean isSetPrazo() {
        return (this.prazo!= null);
    }

}
