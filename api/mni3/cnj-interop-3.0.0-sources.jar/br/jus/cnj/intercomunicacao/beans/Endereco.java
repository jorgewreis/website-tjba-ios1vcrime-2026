
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir o cadastro de endereços. Esse tipo tem o atributo opcional 
 * 'cep' e os elementos de texto 'logradouro', 'numero', 'complemento', 'bairro', 'cidade', 'estado' e 'pais', todos 
 * opcionais. Na implementação de validação, a presença do 'cep' deve dispensar o preenchimento dos elementos 'cidade', 
 * 'estado' e 'pais' e poderá dispensar a presença dos demais elementos que já estiverem presentes no diretório nacional 
 * de endereços (DNE) como vinculados ao código de endereçamento postal definido. 
 * 			
 * 
 * <p>Classe Java de tipoEndereco complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoEndereco">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="logradouro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numero" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="complemento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="bairro" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cidade" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCidade" minOccurs="0"/>
 *         &lt;element name="unidadeFederacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeUnidadeFederacao" minOccurs="0"/>
 *         &lt;element name="pais" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[A-Za-z]{2}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="cep" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="\d{8}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoEndereco", propOrder = {
    "logradouro",
    "numero",
    "complemento",
    "bairro",
    "cidade",
    "unidadeFederacao",
    "pais",
    "cep"
})
public class Endereco
    implements Serializable
{

    protected String logradouro;
    protected String numero;
    protected String complemento;
    protected String bairro;
    protected Cidade cidade;
    @XmlSchemaType(name = "string")
    protected ModalidadeUnidadeFederacao unidadeFederacao;
    @XmlElement(defaultValue = "BR")
    protected String pais;
    protected String cep;

    /**
     * Obtém o valor da propriedade logradouro.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLogradouro() {
        return logradouro;
    }

    /**
     * Define o valor da propriedade logradouro.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLogradouro(String value) {
        this.logradouro = value;
    }

    public boolean isSetLogradouro() {
        return (this.logradouro!= null);
    }

    /**
     * Obtém o valor da propriedade numero.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumero() {
        return numero;
    }

    /**
     * Define o valor da propriedade numero.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumero(String value) {
        this.numero = value;
    }

    public boolean isSetNumero() {
        return (this.numero!= null);
    }

    /**
     * Obtém o valor da propriedade complemento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComplemento() {
        return complemento;
    }

    /**
     * Define o valor da propriedade complemento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComplemento(String value) {
        this.complemento = value;
    }

    public boolean isSetComplemento() {
        return (this.complemento!= null);
    }

    /**
     * Obtém o valor da propriedade bairro.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBairro() {
        return bairro;
    }

    /**
     * Define o valor da propriedade bairro.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBairro(String value) {
        this.bairro = value;
    }

    public boolean isSetBairro() {
        return (this.bairro!= null);
    }

    /**
     * Obtém o valor da propriedade cidade.
     * 
     * @return
     *     possible object is
     *     {@link Cidade }
     *     
     */
    public Cidade getCidade() {
        return cidade;
    }

    /**
     * Define o valor da propriedade cidade.
     * 
     * @param value
     *     allowed object is
     *     {@link Cidade }
     *     
     */
    public void setCidade(Cidade value) {
        this.cidade = value;
    }

    public boolean isSetCidade() {
        return (this.cidade!= null);
    }

    /**
     * Obtém o valor da propriedade unidadeFederacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public ModalidadeUnidadeFederacao getUnidadeFederacao() {
        return unidadeFederacao;
    }

    /**
     * Define o valor da propriedade unidadeFederacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public void setUnidadeFederacao(ModalidadeUnidadeFederacao value) {
        this.unidadeFederacao = value;
    }

    public boolean isSetUnidadeFederacao() {
        return (this.unidadeFederacao!= null);
    }

    /**
     * Obtém o valor da propriedade pais.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPais() {
        return pais;
    }

    /**
     * Define o valor da propriedade pais.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPais(String value) {
        this.pais = value;
    }

    public boolean isSetPais() {
        return (this.pais!= null);
    }

    /**
     * Obtém o valor da propriedade cep.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCep() {
        return cep;
    }

    /**
     * Define o valor da propriedade cep.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCep(String value) {
        this.cep = value;
    }

    public boolean isSetCep() {
        return (this.cep!= null);
    }

}
