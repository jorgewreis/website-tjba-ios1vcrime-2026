
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado à transferência ou à viabilização de transferência de documento processual. 
 * 
 * 			
 * 
 * <p>Classe Java de tipoDocumento complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoDocumento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idDocumento" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="idDocumentoVinculado" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoTipoDocumento">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="dataHora" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="nivelSigilo" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="idMovimento" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descricao" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codigoTipoDocumentoLocal" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="conteudo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoConteudoDocumento" minOccurs="0"/>
 *         &lt;element name="documentoVinculado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="unidadeJudiciaria" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoUnidadeJudiciaria" minOccurs="0"/>
 *         &lt;element name="tamanhoConteudo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="outroParametro" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoParametro" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoDocumento", propOrder = {
    "idDocumento",
    "idDocumentoVinculado",
    "codigoTipoDocumento",
    "dataHora",
    "nivelSigilo",
    "idMovimento",
    "descricao",
    "codigoTipoDocumentoLocal",
    "conteudo",
    "documentoVinculado",
    "unidadeJudiciaria",
    "tamanhoConteudo",
    "outroParametro",
    "any"
})
public class DocumentoProcessual
    implements Serializable
{

    @XmlElement(required = true)
    protected String idDocumento;
    protected String idDocumentoVinculado;
    protected int codigoTipoDocumento;
    @XmlSchemaType(name = "string")
    protected DataHora dataHora;
    @XmlElement(defaultValue = "0")
    protected Integer nivelSigilo;
    protected String idMovimento;
    protected String descricao;
    protected String codigoTipoDocumentoLocal;
    protected ConteudoDocumento conteudo;
    protected List<DocumentoProcessual> documentoVinculado;
    protected UnidadeJudiciaria unidadeJudiciaria;
    protected Long tamanhoConteudo;
    protected List<Parametro> outroParametro;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade idDocumento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDocumento() {
        return idDocumento;
    }

    /**
     * Define o valor da propriedade idDocumento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDocumento(String value) {
        this.idDocumento = value;
    }

    public boolean isSetIdDocumento() {
        return (this.idDocumento!= null);
    }

    /**
     * Obtém o valor da propriedade idDocumentoVinculado.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDocumentoVinculado() {
        return idDocumentoVinculado;
    }

    /**
     * Define o valor da propriedade idDocumentoVinculado.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDocumentoVinculado(String value) {
        this.idDocumentoVinculado = value;
    }

    public boolean isSetIdDocumentoVinculado() {
        return (this.idDocumentoVinculado!= null);
    }

    /**
     * Obtém o valor da propriedade codigoTipoDocumento.
     * 
     */
    public int getCodigoTipoDocumento() {
        return codigoTipoDocumento;
    }

    /**
     * Define o valor da propriedade codigoTipoDocumento.
     * 
     */
    public void setCodigoTipoDocumento(int value) {
        this.codigoTipoDocumento = value;
    }

    public boolean isSetCodigoTipoDocumento() {
        return true;
    }

    /**
     * Obtém o valor da propriedade dataHora.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataHora() {
        return dataHora;
    }

    /**
     * Define o valor da propriedade dataHora.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataHora(DataHora value) {
        this.dataHora = value;
    }

    public boolean isSetDataHora() {
        return (this.dataHora!= null);
    }

    /**
     * Obtém o valor da propriedade nivelSigilo.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNivelSigilo() {
        return nivelSigilo;
    }

    /**
     * Define o valor da propriedade nivelSigilo.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNivelSigilo(Integer value) {
        this.nivelSigilo = value;
    }

    public boolean isSetNivelSigilo() {
        return (this.nivelSigilo!= null);
    }

    /**
     * Obtém o valor da propriedade idMovimento.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdMovimento() {
        return idMovimento;
    }

    /**
     * Define o valor da propriedade idMovimento.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdMovimento(String value) {
        this.idMovimento = value;
    }

    public boolean isSetIdMovimento() {
        return (this.idMovimento!= null);
    }

    /**
     * Obtém o valor da propriedade descricao.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * Define o valor da propriedade descricao.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescricao(String value) {
        this.descricao = value;
    }

    public boolean isSetDescricao() {
        return (this.descricao!= null);
    }

    /**
     * Obtém o valor da propriedade codigoTipoDocumentoLocal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoTipoDocumentoLocal() {
        return codigoTipoDocumentoLocal;
    }

    /**
     * Define o valor da propriedade codigoTipoDocumentoLocal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoTipoDocumentoLocal(String value) {
        this.codigoTipoDocumentoLocal = value;
    }

    public boolean isSetCodigoTipoDocumentoLocal() {
        return (this.codigoTipoDocumentoLocal!= null);
    }

    /**
     * Obtém o valor da propriedade conteudo.
     * 
     * @return
     *     possible object is
     *     {@link ConteudoDocumento }
     *     
     */
    public ConteudoDocumento getConteudo() {
        return conteudo;
    }

    /**
     * Define o valor da propriedade conteudo.
     * 
     * @param value
     *     allowed object is
     *     {@link ConteudoDocumento }
     *     
     */
    public void setConteudo(ConteudoDocumento value) {
        this.conteudo = value;
    }

    public boolean isSetConteudo() {
        return (this.conteudo!= null);
    }

    /**
     * Gets the value of the documentoVinculado property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documentoVinculado property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumentoVinculado().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoProcessual }
     * 
     * 
     */
    public List<DocumentoProcessual> getDocumentoVinculado() {
        if (documentoVinculado == null) {
            documentoVinculado = new ArrayList<DocumentoProcessual>();
        }
        return this.documentoVinculado;
    }

    public boolean isSetDocumentoVinculado() {
        return ((this.documentoVinculado!= null)&&(!this.documentoVinculado.isEmpty()));
    }

    public void unsetDocumentoVinculado() {
        this.documentoVinculado = null;
    }

    /**
     * Obtém o valor da propriedade unidadeJudiciaria.
     * 
     * @return
     *     possible object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public UnidadeJudiciaria getUnidadeJudiciaria() {
        return unidadeJudiciaria;
    }

    /**
     * Define o valor da propriedade unidadeJudiciaria.
     * 
     * @param value
     *     allowed object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public void setUnidadeJudiciaria(UnidadeJudiciaria value) {
        this.unidadeJudiciaria = value;
    }

    public boolean isSetUnidadeJudiciaria() {
        return (this.unidadeJudiciaria!= null);
    }

    /**
     * Obtém o valor da propriedade tamanhoConteudo.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTamanhoConteudo() {
        return tamanhoConteudo;
    }

    /**
     * Define o valor da propriedade tamanhoConteudo.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTamanhoConteudo(Long value) {
        this.tamanhoConteudo = value;
    }

    public boolean isSetTamanhoConteudo() {
        return (this.tamanhoConteudo!= null);
    }

    /**
     * Gets the value of the outroParametro property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outroParametro property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutroParametro().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parametro }
     * 
     * 
     */
    public List<Parametro> getOutroParametro() {
        if (outroParametro == null) {
            outroParametro = new ArrayList<Parametro>();
        }
        return this.outroParametro;
    }

    public boolean isSetOutroParametro() {
        return ((this.outroParametro!= null)&&(!this.outroParametro.isEmpty()));
    }

    public void unsetOutroParametro() {
        this.outroParametro = null;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
