
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula dados essenciais à consulta de assuntos. 
 * 			
 * 
 * <p>Classe Java de requisicaoConsultarAssuntos complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarAssuntos">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoLocalidade" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codigoClasse" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoCompetencia" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarAssuntos", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "codigoLocalidade",
    "codigoClasse",
    "codigoCompetencia"
})
public class RequisicaoConsultarAssuntos
    implements Serializable
{

    @XmlElement(required = true)
    protected String codigoLocalidade;
    protected int codigoClasse;
    protected Integer codigoCompetencia;

    /**
     * Obtém o valor da propriedade codigoLocalidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoLocalidade() {
        return codigoLocalidade;
    }

    /**
     * Define o valor da propriedade codigoLocalidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoLocalidade(String value) {
        this.codigoLocalidade = value;
    }

    public boolean isSetCodigoLocalidade() {
        return (this.codigoLocalidade!= null);
    }

    /**
     * Obtém o valor da propriedade codigoClasse.
     * 
     */
    public int getCodigoClasse() {
        return codigoClasse;
    }

    /**
     * Define o valor da propriedade codigoClasse.
     * 
     */
    public void setCodigoClasse(int value) {
        this.codigoClasse = value;
    }

    public boolean isSetCodigoClasse() {
        return true;
    }

    /**
     * Obtém o valor da propriedade codigoCompetencia.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoCompetencia() {
        return codigoCompetencia;
    }

    /**
     * Define o valor da propriedade codigoCompetencia.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoCompetencia(Integer value) {
        this.codigoCompetencia = value;
    }

    public boolean isSetCodigoCompetencia() {
        return (this.codigoCompetencia!= null);
    }

}
