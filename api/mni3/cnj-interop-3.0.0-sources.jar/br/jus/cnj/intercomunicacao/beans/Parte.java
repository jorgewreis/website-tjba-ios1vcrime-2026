
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que permite a identificação de uma parte que compõe o processo. Cada parte deve 
 * ter apenas uma pessoa física ou jurídica. 
 * 			
 * 
 * <p>Classe Java de tipoParte complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoParte">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="pessoa" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoa"/>
 *           &lt;element name="interessePublico" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;/choice>
 *         &lt;element name="advogado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRepresentanteProcessual" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pessoaProcessualRelacionada" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoParte" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="assistenciaJudiciaria" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="intimacaoPendente" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="0"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="relacionamentoProcessual" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeRelacionamentoProcessual" minOccurs="0"/>
 *         &lt;element name="situacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeSituacaoParte"/>
 *         &lt;element name="complemento" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoParte", propOrder = {
    "pessoa",
    "interessePublico",
    "advogado",
    "pessoaProcessualRelacionada",
    "assistenciaJudiciaria",
    "intimacaoPendente",
    "relacionamentoProcessual",
    "situacao",
    "complemento",
    "any"
})
public class Parte
    implements Serializable
{

    protected Pessoa pessoa;
    protected Boolean interessePublico;
    protected List<RepresentanteProcessual> advogado;
    protected List<Parte> pessoaProcessualRelacionada;
    protected Boolean assistenciaJudiciaria;
    protected Integer intimacaoPendente;
    @XmlSchemaType(name = "string")
    protected ModalidadeRelacionamentoProcessual relacionamentoProcessual;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeSituacaoParte situacao;
    protected List<String> complemento;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade pessoa.
     * 
     * @return
     *     possible object is
     *     {@link Pessoa }
     *     
     */
    public Pessoa getPessoa() {
        return pessoa;
    }

    /**
     * Define o valor da propriedade pessoa.
     * 
     * @param value
     *     allowed object is
     *     {@link Pessoa }
     *     
     */
    public void setPessoa(Pessoa value) {
        this.pessoa = value;
    }

    public boolean isSetPessoa() {
        return (this.pessoa!= null);
    }

    /**
     * Obtém o valor da propriedade interessePublico.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isInteressePublico() {
        return interessePublico;
    }

    /**
     * Define o valor da propriedade interessePublico.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setInteressePublico(Boolean value) {
        this.interessePublico = value;
    }

    public boolean isSetInteressePublico() {
        return (this.interessePublico!= null);
    }

    /**
     * Gets the value of the advogado property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the advogado property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdvogado().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RepresentanteProcessual }
     * 
     * 
     */
    public List<RepresentanteProcessual> getAdvogado() {
        if (advogado == null) {
            advogado = new ArrayList<RepresentanteProcessual>();
        }
        return this.advogado;
    }

    public boolean isSetAdvogado() {
        return ((this.advogado!= null)&&(!this.advogado.isEmpty()));
    }

    public void unsetAdvogado() {
        this.advogado = null;
    }

    /**
     * Gets the value of the pessoaProcessualRelacionada property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pessoaProcessualRelacionada property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPessoaProcessualRelacionada().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parte }
     * 
     * 
     */
    public List<Parte> getPessoaProcessualRelacionada() {
        if (pessoaProcessualRelacionada == null) {
            pessoaProcessualRelacionada = new ArrayList<Parte>();
        }
        return this.pessoaProcessualRelacionada;
    }

    public boolean isSetPessoaProcessualRelacionada() {
        return ((this.pessoaProcessualRelacionada!= null)&&(!this.pessoaProcessualRelacionada.isEmpty()));
    }

    public void unsetPessoaProcessualRelacionada() {
        this.pessoaProcessualRelacionada = null;
    }

    /**
     * Obtém o valor da propriedade assistenciaJudiciaria.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAssistenciaJudiciaria() {
        return assistenciaJudiciaria;
    }

    /**
     * Define o valor da propriedade assistenciaJudiciaria.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAssistenciaJudiciaria(Boolean value) {
        this.assistenciaJudiciaria = value;
    }

    public boolean isSetAssistenciaJudiciaria() {
        return (this.assistenciaJudiciaria!= null);
    }

    /**
     * Obtém o valor da propriedade intimacaoPendente.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getIntimacaoPendente() {
        return intimacaoPendente;
    }

    /**
     * Define o valor da propriedade intimacaoPendente.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setIntimacaoPendente(Integer value) {
        this.intimacaoPendente = value;
    }

    public boolean isSetIntimacaoPendente() {
        return (this.intimacaoPendente!= null);
    }

    /**
     * Obtém o valor da propriedade relacionamentoProcessual.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeRelacionamentoProcessual }
     *     
     */
    public ModalidadeRelacionamentoProcessual getRelacionamentoProcessual() {
        return relacionamentoProcessual;
    }

    /**
     * Define o valor da propriedade relacionamentoProcessual.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeRelacionamentoProcessual }
     *     
     */
    public void setRelacionamentoProcessual(ModalidadeRelacionamentoProcessual value) {
        this.relacionamentoProcessual = value;
    }

    public boolean isSetRelacionamentoProcessual() {
        return (this.relacionamentoProcessual!= null);
    }

    /**
     * Obtém o valor da propriedade situacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeSituacaoParte }
     *     
     */
    public ModalidadeSituacaoParte getSituacao() {
        return situacao;
    }

    /**
     * Define o valor da propriedade situacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeSituacaoParte }
     *     
     */
    public void setSituacao(ModalidadeSituacaoParte value) {
        this.situacao = value;
    }

    public boolean isSetSituacao() {
        return (this.situacao!= null);
    }

    /**
     * Gets the value of the complemento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the complemento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComplemento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getComplemento() {
        if (complemento == null) {
            complemento = new ArrayList<String>();
        }
        return this.complemento;
    }

    public boolean isSetComplemento() {
        return ((this.complemento!= null)&&(!this.complemento.isEmpty()));
    }

    public void unsetComplemento() {
        this.complemento = null;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
