
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadeRelacionamentoPessoal.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadeRelacionamentoPessoal">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="P"/>
 *     &lt;enumeration value="AP"/>
 *     &lt;enumeration value="SP"/>
 *     &lt;enumeration value="T"/>
 *     &lt;enumeration value="C"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadeRelacionamentoPessoal")
@XmlEnum
public enum ModalidadeRelacionamentoPessoal {

    P,
    AP,
    SP,
    T,
    C;

    public String value() {
        return name();
    }

    public static ModalidadeRelacionamentoPessoal fromValue(String v) {
        return valueOf(v);
    }

}
