
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar as unidades judiciárias e respectivas datas de recebimento pelas quais o processo judicial tramitou. 
 * 			
 * 
 * <p>Classe Java de tipoHistoricoDeslocamento complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoHistoricoDeslocamento">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="unidadeJudiciaria" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoUnidadeJudiciaria"/>
 *         &lt;element name="dataAjuizamento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *         &lt;element name="numeroInterno" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="classeProcessual">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoHistoricoDeslocamento", propOrder = {
    "unidadeJudiciaria",
    "dataAjuizamento",
    "numeroProcesso",
    "numeroInterno",
    "classeProcessual"
})
public class HistoricoDeslocamento
    implements Serializable
{

    @XmlElement(required = true)
    protected UnidadeJudiciaria unidadeJudiciaria;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataAjuizamento;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    protected String numeroInterno;
    protected int classeProcessual;

    /**
     * Obtém o valor da propriedade unidadeJudiciaria.
     * 
     * @return
     *     possible object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public UnidadeJudiciaria getUnidadeJudiciaria() {
        return unidadeJudiciaria;
    }

    /**
     * Define o valor da propriedade unidadeJudiciaria.
     * 
     * @param value
     *     allowed object is
     *     {@link UnidadeJudiciaria }
     *     
     */
    public void setUnidadeJudiciaria(UnidadeJudiciaria value) {
        this.unidadeJudiciaria = value;
    }

    public boolean isSetUnidadeJudiciaria() {
        return (this.unidadeJudiciaria!= null);
    }

    /**
     * Obtém o valor da propriedade dataAjuizamento.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataAjuizamento() {
        return dataAjuizamento;
    }

    /**
     * Define o valor da propriedade dataAjuizamento.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataAjuizamento(DataHora value) {
        this.dataAjuizamento = value;
    }

    public boolean isSetDataAjuizamento() {
        return (this.dataAjuizamento!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade numeroInterno.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroInterno() {
        return numeroInterno;
    }

    /**
     * Define o valor da propriedade numeroInterno.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroInterno(String value) {
        this.numeroInterno = value;
    }

    public boolean isSetNumeroInterno() {
        return (this.numeroInterno!= null);
    }

    /**
     * Obtém o valor da propriedade classeProcessual.
     * 
     */
    public int getClasseProcessual() {
        return classeProcessual;
    }

    /**
     * Define o valor da propriedade classeProcessual.
     * 
     */
    public void setClasseProcessual(int value) {
        this.classeProcessual = value;
    }

    public boolean isSetClasseProcessual() {
        return true;
    }

}
