
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * 
 * Tipo de dados destinado a limitar a entrada de dados relativos a cadastros no Ministério da Fazenda 
 * Brasileiro (CPF e CNPJ) e/ou ao registro individual do cidadão (riC). A restrição imposta é que o dado qualificado 
 * por este tipo seja integralmente numérico, com 11 (CPF e riC) ou 14 (CNPJ) dígitos. 
 * 			
 * 
 * <p>Classe Java de tipoCadastroIdentificador simple type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;simpleType name="tipoCadastroIdentificador">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;pattern value="(\d{11})|(\d{14})"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCadastroIdentificador", propOrder = {
    "value"
})
public class CadastroIdentificador
    implements Serializable
{

    @XmlValue
    protected String value;

    /**
     * 
     * Tipo de dados destinado a limitar a entrada de dados relativos a cadastros no Ministério da Fazenda 
     * Brasileiro (CPF e CNPJ) e/ou ao registro individual do cidadão (riC). A restrição imposta é que o dado qualificado 
     * por este tipo seja integralmente numérico, com 11 (CPF e riC) ou 14 (CNPJ) dígitos. 
     * 			
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Define o valor da propriedade value.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

}
