
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo destinado a permitir a listagem do histórico do protocolo de uma operação de remessa. 
 * 			
 * 
 * <p>Classe Java de tipoHistoricoRemessa complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoHistoricoRemessa">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numeroProtocolo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico" minOccurs="0"/>
 *         &lt;element name="situacao">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ABERTO"/>
 *               &lt;enumeration value="SUSPENSO"/>
 *               &lt;enumeration value="CANCELADO"/>
 *               &lt;enumeration value="CONCLUIDO"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="dataCriacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="dataAtualizacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="mensagens" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMensagemResposta" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoHistoricoRemessa", propOrder = {
    "numeroProtocolo",
    "numeroProcesso",
    "situacao",
    "dataCriacao",
    "dataAtualizacao",
    "mensagens"
})
public class HistoricoRemessa
    implements Serializable
{

    @XmlElement(required = true)
    protected String numeroProtocolo;
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    @XmlElement(required = true)
    protected String situacao;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataCriacao;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataAtualizacao;
    protected List<MensagemResposta> mensagens;

    /**
     * Obtém o valor da propriedade numeroProtocolo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroProtocolo() {
        return numeroProtocolo;
    }

    /**
     * Define o valor da propriedade numeroProtocolo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroProtocolo(String value) {
        this.numeroProtocolo = value;
    }

    public boolean isSetNumeroProtocolo() {
        return (this.numeroProtocolo!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade situacao.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituacao() {
        return situacao;
    }

    /**
     * Define o valor da propriedade situacao.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituacao(String value) {
        this.situacao = value;
    }

    public boolean isSetSituacao() {
        return (this.situacao!= null);
    }

    /**
     * Obtém o valor da propriedade dataCriacao.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataCriacao() {
        return dataCriacao;
    }

    /**
     * Define o valor da propriedade dataCriacao.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataCriacao(DataHora value) {
        this.dataCriacao = value;
    }

    public boolean isSetDataCriacao() {
        return (this.dataCriacao!= null);
    }

    /**
     * Obtém o valor da propriedade dataAtualizacao.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataAtualizacao() {
        return dataAtualizacao;
    }

    /**
     * Define o valor da propriedade dataAtualizacao.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataAtualizacao(DataHora value) {
        this.dataAtualizacao = value;
    }

    public boolean isSetDataAtualizacao() {
        return (this.dataAtualizacao!= null);
    }

    /**
     * Gets the value of the mensagens property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mensagens property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMensagens().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MensagemResposta }
     * 
     * 
     */
    public List<MensagemResposta> getMensagens() {
        if (mensagens == null) {
            mensagens = new ArrayList<MensagemResposta>();
        }
        return this.mensagens;
    }

    public boolean isSetMensagens() {
        return ((this.mensagens!= null)&&(!this.mensagens.isEmpty()));
    }

    public void unsetMensagens() {
        this.mensagens = null;
    }

}
