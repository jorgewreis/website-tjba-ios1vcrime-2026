
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula dados essenciais à consulta do histórico de remessas. 
 * 			
 * 
 * <p>Classe Java de requisicaoConsultarRemessas complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarRemessas">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numerosProtocolos" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="100"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarRemessas", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "numerosProtocolos"
})
public class RequisicaoConsultarRemessas
    implements Serializable
{

    @XmlElement(required = true)
    protected List<String> numerosProtocolos;

    /**
     * Gets the value of the numerosProtocolos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the numerosProtocolos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNumerosProtocolos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getNumerosProtocolos() {
        if (numerosProtocolos == null) {
            numerosProtocolos = new ArrayList<String>();
        }
        return this.numerosProtocolos;
    }

    public boolean isSetNumerosProtocolos() {
        return ((this.numerosProtocolos!= null)&&(!this.numerosProtocolos.isEmpty()));
    }

    public void unsetNumerosProtocolos() {
        this.numerosProtocolos = null;
    }

}
