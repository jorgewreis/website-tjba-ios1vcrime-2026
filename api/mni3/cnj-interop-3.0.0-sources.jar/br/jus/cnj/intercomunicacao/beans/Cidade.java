
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoCidade complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoCidade">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="municipio" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="unidadeFederacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeUnidadeFederacao" minOccurs="0"/>
 *         &lt;element name="codigoIBGE" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[0-9]{7}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCidade", propOrder = {
    "municipio",
    "unidadeFederacao",
    "codigoIBGE"
})
public class Cidade
    implements Serializable
{

    @XmlElement(required = true)
    protected String municipio;
    @XmlSchemaType(name = "string")
    protected ModalidadeUnidadeFederacao unidadeFederacao;
    protected String codigoIBGE;

    /**
     * Obtém o valor da propriedade municipio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMunicipio() {
        return municipio;
    }

    /**
     * Define o valor da propriedade municipio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMunicipio(String value) {
        this.municipio = value;
    }

    public boolean isSetMunicipio() {
        return (this.municipio!= null);
    }

    /**
     * Obtém o valor da propriedade unidadeFederacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public ModalidadeUnidadeFederacao getUnidadeFederacao() {
        return unidadeFederacao;
    }

    /**
     * Define o valor da propriedade unidadeFederacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public void setUnidadeFederacao(ModalidadeUnidadeFederacao value) {
        this.unidadeFederacao = value;
    }

    public boolean isSetUnidadeFederacao() {
        return (this.unidadeFederacao!= null);
    }

    /**
     * Obtém o valor da propriedade codigoIBGE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoIBGE() {
        return codigoIBGE;
    }

    /**
     * Define o valor da propriedade codigoIBGE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoIBGE(String value) {
        this.codigoIBGE = value;
    }

    public boolean isSetCodigoIBGE() {
        return (this.codigoIBGE!= null);
    }

}
