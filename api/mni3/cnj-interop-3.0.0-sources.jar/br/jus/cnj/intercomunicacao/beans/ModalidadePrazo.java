
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadePrazo.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadePrazo">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="HOR"/>
 *     &lt;enumeration value="DIA"/>
 *     &lt;enumeration value="MES"/>
 *     &lt;enumeration value="ANO"/>
 *     &lt;enumeration value="DATA_CERTA"/>
 *     &lt;enumeration value="SEMPRAZO"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadePrazo")
@XmlEnum
public enum ModalidadePrazo {

    HOR,
    DIA,
    MES,
    ANO,
    DATA_CERTA,
    SEMPRAZO;

    public String value() {
        return name();
    }

    public static ModalidadePrazo fromValue(String v) {
        return valueOf(v);
    }

}
