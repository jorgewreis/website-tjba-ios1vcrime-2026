
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadeQualificacaoPessoa.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadeQualificacaoPessoa">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FIS"/>
 *     &lt;enumeration value="JUR"/>
 *     &lt;enumeration value="AUT"/>
 *     &lt;enumeration value="ORP"/>
 *     &lt;enumeration value="EDP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadeQualificacaoPessoa")
@XmlEnum
public enum ModalidadeQualificacaoPessoa {


    /**
     * 
     * Pessoa física 
     * 					
     * 
     */
    FIS,

    /**
     * 
     * Pessoa jurídica, seja de direito público, seja de direito privado 
     * 					
     * 
     */
    JUR,

    /**
     * 
     * Enfeixamento de funções 
     * 					
     * 
     */
    AUT,

    /**
     * 
     * Órgão de representação jurídica de interesses sem personalidade jurídica própria 
     * 					
     * 
     */
    ORP,

    /**
     * 
     * Ente despersonalizado: espólio, massa falida e outras representações sem personalidade jurídica 
     * 
     * 					
     * 
     */
    EDP;

    public String value() {
        return name();
    }

    public static ModalidadeQualificacaoPessoa fromValue(String v) {
        return valueOf(v);
    }

}
