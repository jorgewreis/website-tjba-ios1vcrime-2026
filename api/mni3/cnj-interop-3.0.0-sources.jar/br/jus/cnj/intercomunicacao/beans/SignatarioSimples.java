
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo complexo destinado a permitir a identificação de signatários de documentos caso a assinatura 
 * tenha sido feita com o uso de login e senha, sem prejuízo da obrigatoriedade de o sistema cliente assinar eletronicamente 
 * o documento no padrão ICP-Br quando do envio. 
 * 			
 * 
 * <p>Classe Java de tipoSignatarioSimples complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoSignatarioSimples">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="identificador" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCadastroIdentificador"/>
 *         &lt;element name="dataHora" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoSignatarioSimples", propOrder = {
    "identificador",
    "dataHora"
})
public class SignatarioSimples
    implements Serializable
{

    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected CadastroIdentificador identificador;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataHora;

    /**
     * Obtém o valor da propriedade identificador.
     * 
     * @return
     *     possible object is
     *     {@link CadastroIdentificador }
     *     
     */
    public CadastroIdentificador getIdentificador() {
        return identificador;
    }

    /**
     * Define o valor da propriedade identificador.
     * 
     * @param value
     *     allowed object is
     *     {@link CadastroIdentificador }
     *     
     */
    public void setIdentificador(CadastroIdentificador value) {
        this.identificador = value;
    }

    public boolean isSetIdentificador() {
        return (this.identificador!= null);
    }

    /**
     * Obtém o valor da propriedade dataHora.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataHora() {
        return dataHora;
    }

    /**
     * Define o valor da propriedade dataHora.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataHora(DataHora value) {
        this.dataHora = value;
    }

    public boolean isSetDataHora() {
        return (this.dataHora!= null);
    }

}
