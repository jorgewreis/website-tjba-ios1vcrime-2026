
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a especificar a mensagem relativa à realização da operação. 
 * 			
 * 
 * <p>Classe Java de tipoMensagemResposta complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoMensagemResposta">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="descritivo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codigo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codigoUnico" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="tipo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="INFORMACAO"/>
 *               &lt;enumeration value="ALERTA"/>
 *               &lt;enumeration value="ERRO"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoMensagemResposta", propOrder = {
    "descritivo",
    "codigo",
    "codigoUnico",
    "tipo"
})
public class MensagemResposta
    implements Serializable
{

    @XmlElement(required = true)
    protected String descritivo;
    @XmlElement(required = true)
    protected String codigo;
    @XmlElement(required = true)
    protected String codigoUnico;
    @XmlElement(defaultValue = "INFORMACAO")
    protected String tipo;

    /**
     * Obtém o valor da propriedade descritivo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescritivo() {
        return descritivo;
    }

    /**
     * Define o valor da propriedade descritivo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescritivo(String value) {
        this.descritivo = value;
    }

    public boolean isSetDescritivo() {
        return (this.descritivo!= null);
    }

    /**
     * Obtém o valor da propriedade codigo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Define o valor da propriedade codigo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigo(String value) {
        this.codigo = value;
    }

    public boolean isSetCodigo() {
        return (this.codigo!= null);
    }

    /**
     * Obtém o valor da propriedade codigoUnico.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoUnico() {
        return codigoUnico;
    }

    /**
     * Define o valor da propriedade codigoUnico.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoUnico(String value) {
        this.codigoUnico = value;
    }

    public boolean isSetCodigoUnico() {
        return (this.codigoUnico!= null);
    }

    /**
     * Obtém o valor da propriedade tipo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Define o valor da propriedade tipo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipo(String value) {
        this.tipo = value;
    }

    public boolean isSetTipo() {
        return (this.tipo!= null);
    }

}
