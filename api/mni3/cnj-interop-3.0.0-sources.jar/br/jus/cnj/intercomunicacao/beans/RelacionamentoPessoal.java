
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo destinado a permitir a vinculação entre uma parte e outra pessoa, sendo esclarecido o tipo 
 * de relacionamento por meio da modalidade indicada no atributo do elemento. 
 * 			
 * 
 * <p>Classe Java de tipoRelacionamentoPessoal complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoRelacionamentoPessoal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pessoa" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoa"/>
 *       &lt;/sequence>
 *       &lt;attribute name="modalidadeRelacionamento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeRelacionamentoPessoal" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoRelacionamentoPessoal", propOrder = {
    "pessoa"
})
public class RelacionamentoPessoal
    implements Serializable
{

    @XmlElement(required = true)
    protected Pessoa pessoa;
    @XmlAttribute(name = "modalidadeRelacionamento")
    protected ModalidadeRelacionamentoPessoal modalidadeRelacionamento;

    /**
     * Obtém o valor da propriedade pessoa.
     * 
     * @return
     *     possible object is
     *     {@link Pessoa }
     *     
     */
    public Pessoa getPessoa() {
        return pessoa;
    }

    /**
     * Define o valor da propriedade pessoa.
     * 
     * @param value
     *     allowed object is
     *     {@link Pessoa }
     *     
     */
    public void setPessoa(Pessoa value) {
        this.pessoa = value;
    }

    public boolean isSetPessoa() {
        return (this.pessoa!= null);
    }

    /**
     * Obtém o valor da propriedade modalidadeRelacionamento.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeRelacionamentoPessoal }
     *     
     */
    public ModalidadeRelacionamentoPessoal getModalidadeRelacionamento() {
        return modalidadeRelacionamento;
    }

    /**
     * Define o valor da propriedade modalidadeRelacionamento.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeRelacionamentoPessoal }
     *     
     */
    public void setModalidadeRelacionamento(ModalidadeRelacionamentoPessoal value) {
        this.modalidadeRelacionamento = value;
    }

    public boolean isSetModalidadeRelacionamento() {
        return (this.modalidadeRelacionamento!= null);
    }

}
