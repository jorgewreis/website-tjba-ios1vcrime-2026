
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir a individualização de uma pessoa física ou jurídica. 
 * 			
 * 
 * <p>Classe Java de tipoPessoa complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoPessoa">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dadosBasicos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoaSimples"/>
 *         &lt;element name="outroNome" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="dataNascimento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoData" minOccurs="0"/>
 *         &lt;element name="dataObito" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoData" minOccurs="0"/>
 *         &lt;element name="sexo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeGeneroPessoa"/>
 *         &lt;element name="nomeGenitor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomeGenitora" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="documento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumentoIdentificacao" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="cidadeNatural" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCidade" minOccurs="0"/>
 *         &lt;element name="nacionalidade" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[A-Za-z]{2}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="endereco" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoEndereco" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pessoaRelacionada" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRelacionamentoPessoal" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pessoaVinculada" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPessoa" minOccurs="0"/>
 *         &lt;element name="escolaridade" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNivelEscolaridade" minOccurs="0"/>
 *         &lt;element name="qualificacaoPessoa" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeQualificacaoPessoa"/>
 *         &lt;choice>
 *           &lt;element name="numeroDocumentoPrincipal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCadastroIdentificador"/>
 *           &lt;element name="justificativaAusenciaDocumentoPrincipal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;/choice>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoPessoa", propOrder = {
    "dadosBasicos",
    "outroNome",
    "dataNascimento",
    "dataObito",
    "sexo",
    "nomeGenitor",
    "nomeGenitora",
    "documento",
    "cidadeNatural",
    "nacionalidade",
    "endereco",
    "pessoaRelacionada",
    "pessoaVinculada",
    "escolaridade",
    "qualificacaoPessoa",
    "numeroDocumentoPrincipal",
    "justificativaAusenciaDocumentoPrincipal",
    "any"
})
public class Pessoa
    implements Serializable
{

    @XmlElement(required = true)
    protected PessoaSimples dadosBasicos;
    protected List<String> outroNome;
    @XmlSchemaType(name = "string")
    protected Data dataNascimento;
    @XmlSchemaType(name = "string")
    protected Data dataObito;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeGeneroPessoa sexo;
    protected String nomeGenitor;
    protected String nomeGenitora;
    protected List<DocumentoIdentificacao> documento;
    protected Cidade cidadeNatural;
    @XmlElement(defaultValue = "BR")
    protected String nacionalidade;
    protected List<Endereco> endereco;
    @XmlElement(nillable = true)
    protected List<RelacionamentoPessoal> pessoaRelacionada;
    protected Pessoa pessoaVinculada;
    protected String escolaridade;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeQualificacaoPessoa qualificacaoPessoa;
    @XmlSchemaType(name = "string")
    protected CadastroIdentificador numeroDocumentoPrincipal;
    protected String justificativaAusenciaDocumentoPrincipal;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade dadosBasicos.
     * 
     * @return
     *     possible object is
     *     {@link PessoaSimples }
     *     
     */
    public PessoaSimples getDadosBasicos() {
        return dadosBasicos;
    }

    /**
     * Define o valor da propriedade dadosBasicos.
     * 
     * @param value
     *     allowed object is
     *     {@link PessoaSimples }
     *     
     */
    public void setDadosBasicos(PessoaSimples value) {
        this.dadosBasicos = value;
    }

    public boolean isSetDadosBasicos() {
        return (this.dadosBasicos!= null);
    }

    /**
     * Gets the value of the outroNome property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outroNome property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutroNome().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOutroNome() {
        if (outroNome == null) {
            outroNome = new ArrayList<String>();
        }
        return this.outroNome;
    }

    public boolean isSetOutroNome() {
        return ((this.outroNome!= null)&&(!this.outroNome.isEmpty()));
    }

    public void unsetOutroNome() {
        this.outroNome = null;
    }

    /**
     * Obtém o valor da propriedade dataNascimento.
     * 
     * @return
     *     possible object is
     *     {@link Data }
     *     
     */
    public Data getDataNascimento() {
        return dataNascimento;
    }

    /**
     * Define o valor da propriedade dataNascimento.
     * 
     * @param value
     *     allowed object is
     *     {@link Data }
     *     
     */
    public void setDataNascimento(Data value) {
        this.dataNascimento = value;
    }

    public boolean isSetDataNascimento() {
        return (this.dataNascimento!= null);
    }

    /**
     * Obtém o valor da propriedade dataObito.
     * 
     * @return
     *     possible object is
     *     {@link Data }
     *     
     */
    public Data getDataObito() {
        return dataObito;
    }

    /**
     * Define o valor da propriedade dataObito.
     * 
     * @param value
     *     allowed object is
     *     {@link Data }
     *     
     */
    public void setDataObito(Data value) {
        this.dataObito = value;
    }

    public boolean isSetDataObito() {
        return (this.dataObito!= null);
    }

    /**
     * Obtém o valor da propriedade sexo.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeGeneroPessoa }
     *     
     */
    public ModalidadeGeneroPessoa getSexo() {
        return sexo;
    }

    /**
     * Define o valor da propriedade sexo.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeGeneroPessoa }
     *     
     */
    public void setSexo(ModalidadeGeneroPessoa value) {
        this.sexo = value;
    }

    public boolean isSetSexo() {
        return (this.sexo!= null);
    }

    /**
     * Obtém o valor da propriedade nomeGenitor.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeGenitor() {
        return nomeGenitor;
    }

    /**
     * Define o valor da propriedade nomeGenitor.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeGenitor(String value) {
        this.nomeGenitor = value;
    }

    public boolean isSetNomeGenitor() {
        return (this.nomeGenitor!= null);
    }

    /**
     * Obtém o valor da propriedade nomeGenitora.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeGenitora() {
        return nomeGenitora;
    }

    /**
     * Define o valor da propriedade nomeGenitora.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeGenitora(String value) {
        this.nomeGenitora = value;
    }

    public boolean isSetNomeGenitora() {
        return (this.nomeGenitora!= null);
    }

    /**
     * Gets the value of the documento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoIdentificacao }
     * 
     * 
     */
    public List<DocumentoIdentificacao> getDocumento() {
        if (documento == null) {
            documento = new ArrayList<DocumentoIdentificacao>();
        }
        return this.documento;
    }

    public boolean isSetDocumento() {
        return ((this.documento!= null)&&(!this.documento.isEmpty()));
    }

    public void unsetDocumento() {
        this.documento = null;
    }

    /**
     * Obtém o valor da propriedade cidadeNatural.
     * 
     * @return
     *     possible object is
     *     {@link Cidade }
     *     
     */
    public Cidade getCidadeNatural() {
        return cidadeNatural;
    }

    /**
     * Define o valor da propriedade cidadeNatural.
     * 
     * @param value
     *     allowed object is
     *     {@link Cidade }
     *     
     */
    public void setCidadeNatural(Cidade value) {
        this.cidadeNatural = value;
    }

    public boolean isSetCidadeNatural() {
        return (this.cidadeNatural!= null);
    }

    /**
     * Obtém o valor da propriedade nacionalidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNacionalidade() {
        return nacionalidade;
    }

    /**
     * Define o valor da propriedade nacionalidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNacionalidade(String value) {
        this.nacionalidade = value;
    }

    public boolean isSetNacionalidade() {
        return (this.nacionalidade!= null);
    }

    /**
     * Gets the value of the endereco property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the endereco property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEndereco().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Endereco }
     * 
     * 
     */
    public List<Endereco> getEndereco() {
        if (endereco == null) {
            endereco = new ArrayList<Endereco>();
        }
        return this.endereco;
    }

    public boolean isSetEndereco() {
        return ((this.endereco!= null)&&(!this.endereco.isEmpty()));
    }

    public void unsetEndereco() {
        this.endereco = null;
    }

    /**
     * Gets the value of the pessoaRelacionada property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pessoaRelacionada property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPessoaRelacionada().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RelacionamentoPessoal }
     * 
     * 
     */
    public List<RelacionamentoPessoal> getPessoaRelacionada() {
        if (pessoaRelacionada == null) {
            pessoaRelacionada = new ArrayList<RelacionamentoPessoal>();
        }
        return this.pessoaRelacionada;
    }

    public boolean isSetPessoaRelacionada() {
        return ((this.pessoaRelacionada!= null)&&(!this.pessoaRelacionada.isEmpty()));
    }

    public void unsetPessoaRelacionada() {
        this.pessoaRelacionada = null;
    }

    /**
     * Obtém o valor da propriedade pessoaVinculada.
     * 
     * @return
     *     possible object is
     *     {@link Pessoa }
     *     
     */
    public Pessoa getPessoaVinculada() {
        return pessoaVinculada;
    }

    /**
     * Define o valor da propriedade pessoaVinculada.
     * 
     * @param value
     *     allowed object is
     *     {@link Pessoa }
     *     
     */
    public void setPessoaVinculada(Pessoa value) {
        this.pessoaVinculada = value;
    }

    public boolean isSetPessoaVinculada() {
        return (this.pessoaVinculada!= null);
    }

    /**
     * Obtém o valor da propriedade escolaridade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEscolaridade() {
        return escolaridade;
    }

    /**
     * Define o valor da propriedade escolaridade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEscolaridade(String value) {
        this.escolaridade = value;
    }

    public boolean isSetEscolaridade() {
        return (this.escolaridade!= null);
    }

    /**
     * Obtém o valor da propriedade qualificacaoPessoa.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeQualificacaoPessoa }
     *     
     */
    public ModalidadeQualificacaoPessoa getQualificacaoPessoa() {
        return qualificacaoPessoa;
    }

    /**
     * Define o valor da propriedade qualificacaoPessoa.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeQualificacaoPessoa }
     *     
     */
    public void setQualificacaoPessoa(ModalidadeQualificacaoPessoa value) {
        this.qualificacaoPessoa = value;
    }

    public boolean isSetQualificacaoPessoa() {
        return (this.qualificacaoPessoa!= null);
    }

    /**
     * Obtém o valor da propriedade numeroDocumentoPrincipal.
     * 
     * @return
     *     possible object is
     *     {@link CadastroIdentificador }
     *     
     */
    public CadastroIdentificador getNumeroDocumentoPrincipal() {
        return numeroDocumentoPrincipal;
    }

    /**
     * Define o valor da propriedade numeroDocumentoPrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link CadastroIdentificador }
     *     
     */
    public void setNumeroDocumentoPrincipal(CadastroIdentificador value) {
        this.numeroDocumentoPrincipal = value;
    }

    public boolean isSetNumeroDocumentoPrincipal() {
        return (this.numeroDocumentoPrincipal!= null);
    }

    /**
     * Obtém o valor da propriedade justificativaAusenciaDocumentoPrincipal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJustificativaAusenciaDocumentoPrincipal() {
        return justificativaAusenciaDocumentoPrincipal;
    }

    /**
     * Define o valor da propriedade justificativaAusenciaDocumentoPrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJustificativaAusenciaDocumentoPrincipal(String value) {
        this.justificativaAusenciaDocumentoPrincipal = value;
    }

    public boolean isSetJustificativaAusenciaDocumentoPrincipal() {
        return (this.justificativaAusenciaDocumentoPrincipal!= null);
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
