
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que permite informar uma vinculação entre um processo judicial e outro. 
 * 			
 * 
 * <p>Classe Java de tipoVinculacaoProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoVinculacaoProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="numeroProcesso" use="required" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico" />
 *       &lt;attribute name="vinculo" use="required" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeVinculacaoProcesso" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoVinculacaoProcessual")
public class VinculacaoProcessual
    implements Serializable
{

    @XmlAttribute(name = "numeroProcesso", required = true)
    protected NumeroUnico numeroProcesso;
    @XmlAttribute(name = "vinculo", required = true)
    protected ModalidadeVinculacaoProcesso vinculo;

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade vinculo.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeVinculacaoProcesso }
     *     
     */
    public ModalidadeVinculacaoProcesso getVinculo() {
        return vinculo;
    }

    /**
     * Define o valor da propriedade vinculo.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeVinculacaoProcesso }
     *     
     */
    public void setVinculo(ModalidadeVinculacaoProcesso value) {
        this.vinculo = value;
    }

    public boolean isSetVinculo() {
        return (this.vinculo!= null);
    }

}
