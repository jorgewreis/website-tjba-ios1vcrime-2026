
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar o token de autenticação gerado pelo sistema de destino. Visa 
 * tornar mais ágil o processo de autenticação em operações sequentes, tornando desnecessário realizar o custoso procedimento 
 * de credenciamento a cada chamada de operação. 
 * 			
 * 
 * <p>Classe Java de tipoReciboTokenAutenticacao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoReciboTokenAutenticacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="token" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dataExpiracao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoReciboTokenAutenticacao", propOrder = {
    "token",
    "dataExpiracao"
})
public class ReciboTokenAutenticacao
    implements Serializable
{

    @XmlElement(required = true)
    protected String token;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataExpiracao;

    /**
     * Obtém o valor da propriedade token.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Define o valor da propriedade token.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

    public boolean isSetToken() {
        return (this.token!= null);
    }

    /**
     * Obtém o valor da propriedade dataExpiracao.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataExpiracao() {
        return dataExpiracao;
    }

    /**
     * Define o valor da propriedade dataExpiracao.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataExpiracao(DataHora value) {
        this.dataExpiracao = value;
    }

    public boolean isSetDataExpiracao() {
        return (this.dataExpiracao!= null);
    }

}
