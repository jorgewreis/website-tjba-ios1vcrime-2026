
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir a manifestação processual em casos de resposta a avisos de 
 * comunicação. 
 * 			
 * 
 * <p>Classe Java de tipoRespostaAviso complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoRespostaAviso">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAviso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}identificadorComunicacao" maxOccurs="unbounded"/>
 *         &lt;element name="documento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoRespostaAviso", propOrder = {
    "idAviso",
    "documento"
})
public class RespostaAviso
    implements Serializable
{

    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected List<Identificador> idAviso;
    protected DocumentoProcessual documento;

    /**
     * Gets the value of the idAviso property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the idAviso property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdAviso().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Identificador }
     * 
     * 
     */
    public List<Identificador> getIdAviso() {
        if (idAviso == null) {
            idAviso = new ArrayList<Identificador>();
        }
        return this.idAviso;
    }

    public boolean isSetIdAviso() {
        return ((this.idAviso!= null)&&(!this.idAviso.isEmpty()));
    }

    public void unsetIdAviso() {
        this.idAviso = null;
    }

    /**
     * Obtém o valor da propriedade documento.
     * 
     * @return
     *     possible object is
     *     {@link DocumentoProcessual }
     *     
     */
    public DocumentoProcessual getDocumento() {
        return documento;
    }

    /**
     * Define o valor da propriedade documento.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentoProcessual }
     *     
     */
    public void setDocumento(DocumentoProcessual value) {
        this.documento = value;
    }

    public boolean isSetDocumento() {
        return (this.documento!= null);
    }

}
