
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadeSituacaoParte.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadeSituacaoParte">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="I"/>
 *     &lt;enumeration value="B"/>
 *     &lt;enumeration value="S"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadeSituacaoParte")
@XmlEnum
public enum ModalidadeSituacaoParte {

    A,
    I,
    B,
    S;

    public String value() {
        return name();
    }

    public static ModalidadeSituacaoParte fromValue(String v) {
        return valueOf(v);
    }

}
