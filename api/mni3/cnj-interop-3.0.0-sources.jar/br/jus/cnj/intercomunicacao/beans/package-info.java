@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.cnj.jus.br/mni/v300/intercomunicacao", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.jus.cnj.intercomunicacao.beans;
