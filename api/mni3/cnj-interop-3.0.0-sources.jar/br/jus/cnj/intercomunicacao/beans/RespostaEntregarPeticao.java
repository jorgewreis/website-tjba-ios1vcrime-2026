
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula o retorno decorrente da entrega de uma petição incidental. Sendo 
 * bem sucedida ou não, deve ser fornecido protocolo da operação. O recibo deverá ser apresentado em caso de sucesso. 
 * 
 * 			
 * 
 * <p>Classe Java de respostaEntregarPeticao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="respostaEntregarPeticao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoReciboManifestacaoProcessual"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respostaEntregarPeticao", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recibo"
})
public class RespostaEntregarPeticao
    implements Serializable
{

    @XmlElement(required = true)
    protected ReciboManifestacaoProcessual recibo;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link ReciboManifestacaoProcessual }
     *     
     */
    public ReciboManifestacaoProcessual getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link ReciboManifestacaoProcessual }
     *     
     */
    public void setRecibo(ReciboManifestacaoProcessual value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

}
