
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Elemento destinado a encapsular os parâmetros necessários a uma consulta processual. A identificação 
 * do consultante e sua senha são desnecessárias caso tenha havido a autenticação e autorização por meio de certificado 
 * cliente. 
 * 			
 * 
 * <p>Classe Java de requisicaoConsultarProcesso complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarProcesso">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="consultante" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAutenticacao"/>
 *         &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *         &lt;element name="dataInicial" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="dataFinal" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora" minOccurs="0"/>
 *         &lt;element name="incluirCabecalho" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="incluirPartes" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="incluirEnderecos" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="incluirMovimentos" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="incluirDocumentos" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarProcesso", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "consultante",
    "numeroProcesso",
    "dataInicial",
    "dataFinal",
    "incluirCabecalho",
    "incluirPartes",
    "incluirEnderecos",
    "incluirMovimentos",
    "incluirDocumentos"
})
public class RequisicaoConsultarProcesso
    implements Serializable
{

    @XmlElement(required = true)
    protected Autenticacao consultante;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    @XmlSchemaType(name = "string")
    protected DataHora dataInicial;
    @XmlSchemaType(name = "string")
    protected DataHora dataFinal;
    protected Boolean incluirCabecalho;
    protected Boolean incluirPartes;
    protected Boolean incluirEnderecos;
    protected Boolean incluirMovimentos;
    protected Boolean incluirDocumentos;

    /**
     * Obtém o valor da propriedade consultante.
     * 
     * @return
     *     possible object is
     *     {@link Autenticacao }
     *     
     */
    public Autenticacao getConsultante() {
        return consultante;
    }

    /**
     * Define o valor da propriedade consultante.
     * 
     * @param value
     *     allowed object is
     *     {@link Autenticacao }
     *     
     */
    public void setConsultante(Autenticacao value) {
        this.consultante = value;
    }

    public boolean isSetConsultante() {
        return (this.consultante!= null);
    }

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade dataInicial.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataInicial() {
        return dataInicial;
    }

    /**
     * Define o valor da propriedade dataInicial.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataInicial(DataHora value) {
        this.dataInicial = value;
    }

    public boolean isSetDataInicial() {
        return (this.dataInicial!= null);
    }

    /**
     * Obtém o valor da propriedade dataFinal.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataFinal() {
        return dataFinal;
    }

    /**
     * Define o valor da propriedade dataFinal.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataFinal(DataHora value) {
        this.dataFinal = value;
    }

    public boolean isSetDataFinal() {
        return (this.dataFinal!= null);
    }

    /**
     * Obtém o valor da propriedade incluirCabecalho.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncluirCabecalho() {
        return incluirCabecalho;
    }

    /**
     * Define o valor da propriedade incluirCabecalho.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncluirCabecalho(Boolean value) {
        this.incluirCabecalho = value;
    }

    public boolean isSetIncluirCabecalho() {
        return (this.incluirCabecalho!= null);
    }

    /**
     * Obtém o valor da propriedade incluirPartes.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncluirPartes() {
        return incluirPartes;
    }

    /**
     * Define o valor da propriedade incluirPartes.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncluirPartes(Boolean value) {
        this.incluirPartes = value;
    }

    public boolean isSetIncluirPartes() {
        return (this.incluirPartes!= null);
    }

    /**
     * Obtém o valor da propriedade incluirEnderecos.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncluirEnderecos() {
        return incluirEnderecos;
    }

    /**
     * Define o valor da propriedade incluirEnderecos.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncluirEnderecos(Boolean value) {
        this.incluirEnderecos = value;
    }

    public boolean isSetIncluirEnderecos() {
        return (this.incluirEnderecos!= null);
    }

    /**
     * Obtém o valor da propriedade incluirMovimentos.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncluirMovimentos() {
        return incluirMovimentos;
    }

    /**
     * Define o valor da propriedade incluirMovimentos.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncluirMovimentos(Boolean value) {
        this.incluirMovimentos = value;
    }

    public boolean isSetIncluirMovimentos() {
        return (this.incluirMovimentos!= null);
    }

    /**
     * Obtém o valor da propriedade incluirDocumentos.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncluirDocumentos() {
        return incluirDocumentos;
    }

    /**
     * Define o valor da propriedade incluirDocumentos.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncluirDocumentos(Boolean value) {
        this.incluirDocumentos = value;
    }

    public boolean isSetIncluirDocumentos() {
        return (this.incluirDocumentos!= null);
    }

}
