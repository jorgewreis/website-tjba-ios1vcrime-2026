
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a permitir prestar informações relativas a movimentos criados localmente 
 * pelo tribunal. 
 * 			
 * 
 * <p>Classe Java de tipoMovimentoLocal complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoMovimentoLocal">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="movimentoLocalPai" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoLocal" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="codigoMovimento" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="codigoPaiNacional" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="descricao" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoMovimentoLocal", propOrder = {
    "movimentoLocalPai"
})
public class MovimentoLocal
    implements Serializable
{

    protected MovimentoLocal movimentoLocalPai;
    @XmlAttribute(name = "codigoMovimento", required = true)
    protected int codigoMovimento;
    @XmlAttribute(name = "codigoPaiNacional", required = true)
    protected int codigoPaiNacional;
    @XmlAttribute(name = "descricao", required = true)
    protected String descricao;

    /**
     * Obtém o valor da propriedade movimentoLocalPai.
     * 
     * @return
     *     possible object is
     *     {@link MovimentoLocal }
     *     
     */
    public MovimentoLocal getMovimentoLocalPai() {
        return movimentoLocalPai;
    }

    /**
     * Define o valor da propriedade movimentoLocalPai.
     * 
     * @param value
     *     allowed object is
     *     {@link MovimentoLocal }
     *     
     */
    public void setMovimentoLocalPai(MovimentoLocal value) {
        this.movimentoLocalPai = value;
    }

    public boolean isSetMovimentoLocalPai() {
        return (this.movimentoLocalPai!= null);
    }

    /**
     * Obtém o valor da propriedade codigoMovimento.
     * 
     */
    public int getCodigoMovimento() {
        return codigoMovimento;
    }

    /**
     * Define o valor da propriedade codigoMovimento.
     * 
     */
    public void setCodigoMovimento(int value) {
        this.codigoMovimento = value;
    }

    public boolean isSetCodigoMovimento() {
        return true;
    }

    /**
     * Obtém o valor da propriedade codigoPaiNacional.
     * 
     */
    public int getCodigoPaiNacional() {
        return codigoPaiNacional;
    }

    /**
     * Define o valor da propriedade codigoPaiNacional.
     * 
     */
    public void setCodigoPaiNacional(int value) {
        this.codigoPaiNacional = value;
    }

    public boolean isSetCodigoPaiNacional() {
        return true;
    }

    /**
     * Obtém o valor da propriedade descricao.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * Define o valor da propriedade descricao.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescricao(String value) {
        this.descricao = value;
    }

    public boolean isSetDescricao() {
        return (this.descricao!= null);
    }

}
