
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de requisicaoConsultarLocalidades complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="requisicaoConsultarLocalidades">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="estado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeUnidadeFederacao" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "requisicaoConsultarLocalidades", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "estado"
})
public class RequisicaoConsultarLocalidades
    implements Serializable
{

    @XmlSchemaType(name = "string")
    protected ModalidadeUnidadeFederacao estado;

    /**
     * Obtém o valor da propriedade estado.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public ModalidadeUnidadeFederacao getEstado() {
        return estado;
    }

    /**
     * Define o valor da propriedade estado.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public void setEstado(ModalidadeUnidadeFederacao value) {
        this.estado = value;
    }

    public boolean isSetEstado() {
        return (this.estado!= null);
    }

}
