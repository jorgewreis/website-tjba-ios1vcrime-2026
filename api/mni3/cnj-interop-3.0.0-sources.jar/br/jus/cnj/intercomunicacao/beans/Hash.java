
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar o resultado do algoritmo de resumo matemático de um determinado 
 * valor em conjunto com o seu respectivo tipo. 
 * 			
 * 
 * <p>Classe Java de tipoHash complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoHash">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="hash" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="algoritmo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeAlgoritmoHash"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoHash", propOrder = {
    "hash",
    "algoritmo"
})
public class Hash
    implements Serializable
{

    @XmlElement(required = true)
    protected String hash;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeAlgoritmoHash algoritmo;

    /**
     * Obtém o valor da propriedade hash.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHash() {
        return hash;
    }

    /**
     * Define o valor da propriedade hash.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHash(String value) {
        this.hash = value;
    }

    public boolean isSetHash() {
        return (this.hash!= null);
    }

    /**
     * Obtém o valor da propriedade algoritmo.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeAlgoritmoHash }
     *     
     */
    public ModalidadeAlgoritmoHash getAlgoritmo() {
        return algoritmo;
    }

    /**
     * Define o valor da propriedade algoritmo.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeAlgoritmoHash }
     *     
     */
    public void setAlgoritmo(ModalidadeAlgoritmoHash value) {
        this.algoritmo = value;
    }

    public boolean isSetAlgoritmo() {
        return (this.algoritmo!= null);
    }

}
