
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula os dados de resposta relativos à existência de alterações em um processo 
 * judicial. 
 * 			
 * 
 * <p>Classe Java de respostaConsultarAlteracao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="respostaConsultarAlteracao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRecibo"/>
 *         &lt;element name="hashCabecalho" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoHash" minOccurs="0"/>
 *         &lt;element name="hashMovimentacoes" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoHash" minOccurs="0"/>
 *         &lt;element name="hashDocumentos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoHash" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respostaConsultarAlteracao", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recibo",
    "hashCabecalho",
    "hashMovimentacoes",
    "hashDocumentos"
})
public class RespostaConsultarAlteracao
    implements Serializable
{

    @XmlElement(required = true)
    protected Recibo recibo;
    protected Hash hashCabecalho;
    protected Hash hashMovimentacoes;
    protected Hash hashDocumentos;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link Recibo }
     *     
     */
    public Recibo getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link Recibo }
     *     
     */
    public void setRecibo(Recibo value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

    /**
     * Obtém o valor da propriedade hashCabecalho.
     * 
     * @return
     *     possible object is
     *     {@link Hash }
     *     
     */
    public Hash getHashCabecalho() {
        return hashCabecalho;
    }

    /**
     * Define o valor da propriedade hashCabecalho.
     * 
     * @param value
     *     allowed object is
     *     {@link Hash }
     *     
     */
    public void setHashCabecalho(Hash value) {
        this.hashCabecalho = value;
    }

    public boolean isSetHashCabecalho() {
        return (this.hashCabecalho!= null);
    }

    /**
     * Obtém o valor da propriedade hashMovimentacoes.
     * 
     * @return
     *     possible object is
     *     {@link Hash }
     *     
     */
    public Hash getHashMovimentacoes() {
        return hashMovimentacoes;
    }

    /**
     * Define o valor da propriedade hashMovimentacoes.
     * 
     * @param value
     *     allowed object is
     *     {@link Hash }
     *     
     */
    public void setHashMovimentacoes(Hash value) {
        this.hashMovimentacoes = value;
    }

    public boolean isSetHashMovimentacoes() {
        return (this.hashMovimentacoes!= null);
    }

    /**
     * Obtém o valor da propriedade hashDocumentos.
     * 
     * @return
     *     possible object is
     *     {@link Hash }
     *     
     */
    public Hash getHashDocumentos() {
        return hashDocumentos;
    }

    /**
     * Define o valor da propriedade hashDocumentos.
     * 
     * @param value
     *     allowed object is
     *     {@link Hash }
     *     
     */
    public void setHashDocumentos(Hash value) {
        this.hashDocumentos = value;
    }

    public boolean isSetHashDocumentos() {
        return (this.hashDocumentos!= null);
    }

}
