
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento destinado a armazenar os dados de um processo judicial. 
 * 			
 * 
 * <p>Classe Java de tipoProcessoJudicial complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoProcessoJudicial">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;choice>
 *           &lt;element name="numeroProcesso" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNumeroUnico"/>
 *           &lt;element name="dadosBasicos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCabecalhoProcesso"/>
 *         &lt;/choice>
 *         &lt;element name="movimento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoMovimentoProcessual" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="documento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoProcessoJudicial", propOrder = {
    "numeroProcesso",
    "dadosBasicos",
    "movimento",
    "documento"
})
public class ProcessoJudicial
    implements Serializable
{

    @XmlSchemaType(name = "string")
    protected NumeroUnico numeroProcesso;
    protected CabecalhoProcessual dadosBasicos;
    protected List<MovimentacaoProcessual> movimento;
    protected List<DocumentoProcessual> documento;

    /**
     * Obtém o valor da propriedade numeroProcesso.
     * 
     * @return
     *     possible object is
     *     {@link NumeroUnico }
     *     
     */
    public NumeroUnico getNumeroProcesso() {
        return numeroProcesso;
    }

    /**
     * Define o valor da propriedade numeroProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link NumeroUnico }
     *     
     */
    public void setNumeroProcesso(NumeroUnico value) {
        this.numeroProcesso = value;
    }

    public boolean isSetNumeroProcesso() {
        return (this.numeroProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade dadosBasicos.
     * 
     * @return
     *     possible object is
     *     {@link CabecalhoProcessual }
     *     
     */
    public CabecalhoProcessual getDadosBasicos() {
        return dadosBasicos;
    }

    /**
     * Define o valor da propriedade dadosBasicos.
     * 
     * @param value
     *     allowed object is
     *     {@link CabecalhoProcessual }
     *     
     */
    public void setDadosBasicos(CabecalhoProcessual value) {
        this.dadosBasicos = value;
    }

    public boolean isSetDadosBasicos() {
        return (this.dadosBasicos!= null);
    }

    /**
     * Gets the value of the movimento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the movimento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMovimento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MovimentacaoProcessual }
     * 
     * 
     */
    public List<MovimentacaoProcessual> getMovimento() {
        if (movimento == null) {
            movimento = new ArrayList<MovimentacaoProcessual>();
        }
        return this.movimento;
    }

    public boolean isSetMovimento() {
        return ((this.movimento!= null)&&(!this.movimento.isEmpty()));
    }

    public void unsetMovimento() {
        this.movimento = null;
    }

    /**
     * Gets the value of the documento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoProcessual }
     * 
     * 
     */
    public List<DocumentoProcessual> getDocumento() {
        if (documento == null) {
            documento = new ArrayList<DocumentoProcessual>();
        }
        return this.documento;
    }

    public boolean isSetDocumento() {
        return ((this.documento!= null)&&(!this.documento.isEmpty()));
    }

    public void unsetDocumento() {
        this.documento = null;
    }

}
