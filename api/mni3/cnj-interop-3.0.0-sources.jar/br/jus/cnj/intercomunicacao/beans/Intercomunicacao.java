
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento raiz da intercomunicação. Ele deverá conter um dos elementos principais (processojudicial, 
 * avisocomunicacao e comunicacaoprocessual). 
 * 			
 * 
 * <p>Classe Java de tipoIntercomunicacao complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoIntercomunicacao">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="processojudicial" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoProcessoJudicial" maxOccurs="unbounded"/>
 *         &lt;element name="avisocomunicacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAvisoComunicacaoPendente" maxOccurs="unbounded"/>
 *         &lt;element name="comunicacaoprocessual" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoComunicacaoProcessual" maxOccurs="unbounded"/>
 *         &lt;element name="documento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDocumento" maxOccurs="unbounded"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoIntercomunicacao", propOrder = {
    "processojudicial",
    "avisocomunicacao",
    "comunicacaoprocessual",
    "documento"
})
public class Intercomunicacao
    implements Serializable
{

    protected List<ProcessoJudicial> processojudicial;
    protected List<AvisoComunicacaoPendente> avisocomunicacao;
    protected List<ComunicacaoProcessual> comunicacaoprocessual;
    protected List<DocumentoProcessual> documento;

    /**
     * Gets the value of the processojudicial property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the processojudicial property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProcessojudicial().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProcessoJudicial }
     * 
     * 
     */
    public List<ProcessoJudicial> getProcessojudicial() {
        if (processojudicial == null) {
            processojudicial = new ArrayList<ProcessoJudicial>();
        }
        return this.processojudicial;
    }

    public boolean isSetProcessojudicial() {
        return ((this.processojudicial!= null)&&(!this.processojudicial.isEmpty()));
    }

    public void unsetProcessojudicial() {
        this.processojudicial = null;
    }

    /**
     * Gets the value of the avisocomunicacao property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the avisocomunicacao property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAvisocomunicacao().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvisoComunicacaoPendente }
     * 
     * 
     */
    public List<AvisoComunicacaoPendente> getAvisocomunicacao() {
        if (avisocomunicacao == null) {
            avisocomunicacao = new ArrayList<AvisoComunicacaoPendente>();
        }
        return this.avisocomunicacao;
    }

    public boolean isSetAvisocomunicacao() {
        return ((this.avisocomunicacao!= null)&&(!this.avisocomunicacao.isEmpty()));
    }

    public void unsetAvisocomunicacao() {
        this.avisocomunicacao = null;
    }

    /**
     * Gets the value of the comunicacaoprocessual property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the comunicacaoprocessual property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComunicacaoprocessual().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ComunicacaoProcessual }
     * 
     * 
     */
    public List<ComunicacaoProcessual> getComunicacaoprocessual() {
        if (comunicacaoprocessual == null) {
            comunicacaoprocessual = new ArrayList<ComunicacaoProcessual>();
        }
        return this.comunicacaoprocessual;
    }

    public boolean isSetComunicacaoprocessual() {
        return ((this.comunicacaoprocessual!= null)&&(!this.comunicacaoprocessual.isEmpty()));
    }

    public void unsetComunicacaoprocessual() {
        this.comunicacaoprocessual = null;
    }

    /**
     * Gets the value of the documento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the documento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocumento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocumentoProcessual }
     * 
     * 
     */
    public List<DocumentoProcessual> getDocumento() {
        if (documento == null) {
            documento = new ArrayList<DocumentoProcessual>();
        }
        return this.documento;
    }

    public boolean isSetDocumento() {
        return ((this.documento!= null)&&(!this.documento.isEmpty()));
    }

    public void unsetDocumento() {
        this.documento = null;
    }

}
