
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que encapsula os dados de resposta relativos à existência de avisos pendentes. 
 * Retorna a indicação relativa ao sucesso da operação, campo de mensagem em texto e zero ou mais objetos do tipo 
 * 'tipoAvisoComunicacaoPendente' definido no namespace intercomunicacao.xsd. 
 * 
 * 
 * <p>Classe Java de respostaConsultarAvisosPendentes complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="respostaConsultarAvisosPendentes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="recibo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoRecibo"/>
 *         &lt;element name="avisos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAvisoComunicacaoPendente" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "respostaConsultarAvisosPendentes", namespace = "http://www.cnj.jus.br/mni/v300/tipos-servico-intercomunicacao", propOrder = {
    "recibo",
    "avisos"
})
public class RespostaConsultarAvisosPendentes
    implements Serializable
{

    @XmlElement(required = true)
    protected Recibo recibo;
    protected List<AvisoComunicacaoPendente> avisos;

    /**
     * Obtém o valor da propriedade recibo.
     * 
     * @return
     *     possible object is
     *     {@link Recibo }
     *     
     */
    public Recibo getRecibo() {
        return recibo;
    }

    /**
     * Define o valor da propriedade recibo.
     * 
     * @param value
     *     allowed object is
     *     {@link Recibo }
     *     
     */
    public void setRecibo(Recibo value) {
        this.recibo = value;
    }

    public boolean isSetRecibo() {
        return (this.recibo!= null);
    }

    /**
     * Gets the value of the avisos property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the avisos property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAvisos().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvisoComunicacaoPendente }
     * 
     * 
     */
    public List<AvisoComunicacaoPendente> getAvisos() {
        if (avisos == null) {
            avisos = new ArrayList<AvisoComunicacaoPendente>();
        }
        return this.avisos;
    }

    public boolean isSetAvisos() {
        return ((this.avisos!= null)&&(!this.avisos.isEmpty()));
    }

    public void unsetAvisos() {
        this.avisos = null;
    }

}
