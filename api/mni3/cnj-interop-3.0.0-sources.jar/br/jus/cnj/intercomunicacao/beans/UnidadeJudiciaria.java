
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * Tipo de elemento que permite a indicação da unidade de justiça a qual o processo judicial esteja 
 * vinculado, considerando os elementos:
 *  - “J”: Justiça;
 *  - “TR”: Tribunal e;
 *  - “OOOO”: unidade de origem, conforme disposto na Resolução CNJ 65/2008 que normatiza a as regras de numeração 
 * única processual. 
 * 			
 * 
 * <p>Classe Java de tipoUnidadeJudiciaria complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoUnidadeJudiciaria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="justica">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}integer">
 *               &lt;minInclusive value="1"/>
 *               &lt;maxInclusive value="9"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="tribunal">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[0-9]{2}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="unidade">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;pattern value="[0-9]{4}"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoUnidadeJudiciaria", propOrder = {
    "justica",
    "tribunal",
    "unidade"
})
public class UnidadeJudiciaria
    implements Serializable
{

    protected int justica;
    @XmlElement(required = true)
    protected String tribunal;
    @XmlElement(required = true)
    protected String unidade;

    /**
     * Obtém o valor da propriedade justica.
     * 
     */
    public int getJustica() {
        return justica;
    }

    /**
     * Define o valor da propriedade justica.
     * 
     */
    public void setJustica(int value) {
        this.justica = value;
    }

    public boolean isSetJustica() {
        return true;
    }

    /**
     * Obtém o valor da propriedade tribunal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTribunal() {
        return tribunal;
    }

    /**
     * Define o valor da propriedade tribunal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTribunal(String value) {
        this.tribunal = value;
    }

    public boolean isSetTribunal() {
        return (this.tribunal!= null);
    }

    /**
     * Obtém o valor da propriedade unidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnidade() {
        return unidade;
    }

    /**
     * Define o valor da propriedade unidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnidade(String value) {
        this.unidade = value;
    }

    public boolean isSetUnidade() {
        return (this.unidade!= null);
    }

}
