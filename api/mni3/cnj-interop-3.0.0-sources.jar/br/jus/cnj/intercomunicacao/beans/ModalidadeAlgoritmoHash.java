
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadeAlgoritmoHash.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadeAlgoritmoHash">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="MD5"/>
 *     &lt;enumeration value="SHA-1"/>
 *     &lt;enumeration value="SHA-256"/>
 *     &lt;enumeration value="SHA-512"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadeAlgoritmoHash")
@XmlEnum
public enum ModalidadeAlgoritmoHash {

    @XmlEnumValue("MD5")
    MD_5("MD5"),
    @XmlEnumValue("SHA-1")
    SHA_1("SHA-1"),
    @XmlEnumValue("SHA-256")
    SHA_256("SHA-256"),
    @XmlEnumValue("SHA-512")
    SHA_512("SHA-512");
    private final String value;

    ModalidadeAlgoritmoHash(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ModalidadeAlgoritmoHash fromValue(String v) {
        for (ModalidadeAlgoritmoHash c: ModalidadeAlgoritmoHash.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
