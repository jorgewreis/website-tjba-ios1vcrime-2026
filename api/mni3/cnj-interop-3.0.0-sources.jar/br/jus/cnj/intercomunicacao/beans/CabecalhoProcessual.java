
package br.jus.cnj.intercomunicacao.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoCabecalhoProcesso complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoCabecalhoProcesso">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dadosBasicos" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCabecalhoProcessoSimples"/>
 *         &lt;element name="competencia" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="classeProcessual" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codigoLocalidade" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nivelSigilo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoNivelSigilo"/>
 *         &lt;element name="intervencaoMP" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="tamanhoProcesso" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="dataAjuizamento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoDataHora"/>
 *         &lt;element name="polo" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoPoloProcessual" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="assunto" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoAssuntoProcessual" maxOccurs="unbounded"/>
 *         &lt;element name="magistradoAtuante" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoCadastroIdentificador" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="processoVinculado" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoVinculacaoProcessual" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="prioridade" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadePrioridade"/>
 *         &lt;element name="outroParametro" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoParametro" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="valorCausa" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="orgaoJulgador" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoOrgaoJulgador"/>
 *         &lt;element name="outrosNumeros" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="processoFisico" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="pedidoLiminarPendente" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="historicoDeslocamento" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}tipoHistoricoDeslocamento" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;any namespace='##other' maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCabecalhoProcesso", propOrder = {
    "dadosBasicos",
    "competencia",
    "classeProcessual",
    "codigoLocalidade",
    "nivelSigilo",
    "intervencaoMP",
    "tamanhoProcesso",
    "dataAjuizamento",
    "polo",
    "assunto",
    "magistradoAtuante",
    "processoVinculado",
    "prioridade",
    "outroParametro",
    "valorCausa",
    "orgaoJulgador",
    "outrosNumeros",
    "processoFisico",
    "pedidoLiminarPendente",
    "historicoDeslocamento",
    "any"
})
public class CabecalhoProcessual
    implements Serializable
{

    @XmlElement(required = true)
    protected CabecalhoProcessoSimples dadosBasicos;
    protected Integer competencia;
    protected int classeProcessual;
    @XmlElement(required = true)
    protected String codigoLocalidade;
    protected int nivelSigilo;
    protected Boolean intervencaoMP;
    protected Integer tamanhoProcesso;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected DataHora dataAjuizamento;
    protected List<PoloProcessual> polo;
    @XmlElement(required = true)
    protected List<AssuntoProcessual> assunto;
    @XmlSchemaType(name = "string")
    protected List<CadastroIdentificador> magistradoAtuante;
    protected List<VinculacaoProcessual> processoVinculado;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadePrioridade prioridade;
    protected List<Parametro> outroParametro;
    protected Double valorCausa;
    @XmlElement(required = true)
    protected OrgaoJulgador orgaoJulgador;
    protected List<String> outrosNumeros;
    @XmlElement(defaultValue = "false")
    protected Boolean processoFisico;
    @XmlElement(defaultValue = "false")
    protected Boolean pedidoLiminarPendente;
    protected List<HistoricoDeslocamento> historicoDeslocamento;
    @XmlAnyElement(lax = true)
    protected List<Object> any;

    /**
     * Obtém o valor da propriedade dadosBasicos.
     * 
     * @return
     *     possible object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public CabecalhoProcessoSimples getDadosBasicos() {
        return dadosBasicos;
    }

    /**
     * Define o valor da propriedade dadosBasicos.
     * 
     * @param value
     *     allowed object is
     *     {@link CabecalhoProcessoSimples }
     *     
     */
    public void setDadosBasicos(CabecalhoProcessoSimples value) {
        this.dadosBasicos = value;
    }

    public boolean isSetDadosBasicos() {
        return (this.dadosBasicos!= null);
    }

    /**
     * Obtém o valor da propriedade competencia.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCompetencia() {
        return competencia;
    }

    /**
     * Define o valor da propriedade competencia.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCompetencia(Integer value) {
        this.competencia = value;
    }

    public boolean isSetCompetencia() {
        return (this.competencia!= null);
    }

    /**
     * Obtém o valor da propriedade classeProcessual.
     * 
     */
    public int getClasseProcessual() {
        return classeProcessual;
    }

    /**
     * Define o valor da propriedade classeProcessual.
     * 
     */
    public void setClasseProcessual(int value) {
        this.classeProcessual = value;
    }

    public boolean isSetClasseProcessual() {
        return true;
    }

    /**
     * Obtém o valor da propriedade codigoLocalidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodigoLocalidade() {
        return codigoLocalidade;
    }

    /**
     * Define o valor da propriedade codigoLocalidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodigoLocalidade(String value) {
        this.codigoLocalidade = value;
    }

    public boolean isSetCodigoLocalidade() {
        return (this.codigoLocalidade!= null);
    }

    /**
     * Obtém o valor da propriedade nivelSigilo.
     * 
     */
    public int getNivelSigilo() {
        return nivelSigilo;
    }

    /**
     * Define o valor da propriedade nivelSigilo.
     * 
     */
    public void setNivelSigilo(int value) {
        this.nivelSigilo = value;
    }

    public boolean isSetNivelSigilo() {
        return true;
    }

    /**
     * Obtém o valor da propriedade intervencaoMP.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIntervencaoMP() {
        return intervencaoMP;
    }

    /**
     * Define o valor da propriedade intervencaoMP.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIntervencaoMP(Boolean value) {
        this.intervencaoMP = value;
    }

    public boolean isSetIntervencaoMP() {
        return (this.intervencaoMP!= null);
    }

    /**
     * Obtém o valor da propriedade tamanhoProcesso.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTamanhoProcesso() {
        return tamanhoProcesso;
    }

    /**
     * Define o valor da propriedade tamanhoProcesso.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTamanhoProcesso(Integer value) {
        this.tamanhoProcesso = value;
    }

    public boolean isSetTamanhoProcesso() {
        return (this.tamanhoProcesso!= null);
    }

    /**
     * Obtém o valor da propriedade dataAjuizamento.
     * 
     * @return
     *     possible object is
     *     {@link DataHora }
     *     
     */
    public DataHora getDataAjuizamento() {
        return dataAjuizamento;
    }

    /**
     * Define o valor da propriedade dataAjuizamento.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHora }
     *     
     */
    public void setDataAjuizamento(DataHora value) {
        this.dataAjuizamento = value;
    }

    public boolean isSetDataAjuizamento() {
        return (this.dataAjuizamento!= null);
    }

    /**
     * Gets the value of the polo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the polo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPolo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PoloProcessual }
     * 
     * 
     */
    public List<PoloProcessual> getPolo() {
        if (polo == null) {
            polo = new ArrayList<PoloProcessual>();
        }
        return this.polo;
    }

    public boolean isSetPolo() {
        return ((this.polo!= null)&&(!this.polo.isEmpty()));
    }

    public void unsetPolo() {
        this.polo = null;
    }

    /**
     * Gets the value of the assunto property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assunto property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssunto().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssuntoProcessual }
     * 
     * 
     */
    public List<AssuntoProcessual> getAssunto() {
        if (assunto == null) {
            assunto = new ArrayList<AssuntoProcessual>();
        }
        return this.assunto;
    }

    public boolean isSetAssunto() {
        return ((this.assunto!= null)&&(!this.assunto.isEmpty()));
    }

    public void unsetAssunto() {
        this.assunto = null;
    }

    /**
     * Gets the value of the magistradoAtuante property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the magistradoAtuante property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMagistradoAtuante().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CadastroIdentificador }
     * 
     * 
     */
    public List<CadastroIdentificador> getMagistradoAtuante() {
        if (magistradoAtuante == null) {
            magistradoAtuante = new ArrayList<CadastroIdentificador>();
        }
        return this.magistradoAtuante;
    }

    public boolean isSetMagistradoAtuante() {
        return ((this.magistradoAtuante!= null)&&(!this.magistradoAtuante.isEmpty()));
    }

    public void unsetMagistradoAtuante() {
        this.magistradoAtuante = null;
    }

    /**
     * Gets the value of the processoVinculado property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the processoVinculado property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProcessoVinculado().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VinculacaoProcessual }
     * 
     * 
     */
    public List<VinculacaoProcessual> getProcessoVinculado() {
        if (processoVinculado == null) {
            processoVinculado = new ArrayList<VinculacaoProcessual>();
        }
        return this.processoVinculado;
    }

    public boolean isSetProcessoVinculado() {
        return ((this.processoVinculado!= null)&&(!this.processoVinculado.isEmpty()));
    }

    public void unsetProcessoVinculado() {
        this.processoVinculado = null;
    }

    /**
     * Obtém o valor da propriedade prioridade.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadePrioridade }
     *     
     */
    public ModalidadePrioridade getPrioridade() {
        return prioridade;
    }

    /**
     * Define o valor da propriedade prioridade.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadePrioridade }
     *     
     */
    public void setPrioridade(ModalidadePrioridade value) {
        this.prioridade = value;
    }

    public boolean isSetPrioridade() {
        return (this.prioridade!= null);
    }

    /**
     * Gets the value of the outroParametro property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outroParametro property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutroParametro().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parametro }
     * 
     * 
     */
    public List<Parametro> getOutroParametro() {
        if (outroParametro == null) {
            outroParametro = new ArrayList<Parametro>();
        }
        return this.outroParametro;
    }

    public boolean isSetOutroParametro() {
        return ((this.outroParametro!= null)&&(!this.outroParametro.isEmpty()));
    }

    public void unsetOutroParametro() {
        this.outroParametro = null;
    }

    /**
     * Obtém o valor da propriedade valorCausa.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getValorCausa() {
        return valorCausa;
    }

    /**
     * Define o valor da propriedade valorCausa.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setValorCausa(Double value) {
        this.valorCausa = value;
    }

    public boolean isSetValorCausa() {
        return (this.valorCausa!= null);
    }

    /**
     * Obtém o valor da propriedade orgaoJulgador.
     * 
     * @return
     *     possible object is
     *     {@link OrgaoJulgador }
     *     
     */
    public OrgaoJulgador getOrgaoJulgador() {
        return orgaoJulgador;
    }

    /**
     * Define o valor da propriedade orgaoJulgador.
     * 
     * @param value
     *     allowed object is
     *     {@link OrgaoJulgador }
     *     
     */
    public void setOrgaoJulgador(OrgaoJulgador value) {
        this.orgaoJulgador = value;
    }

    public boolean isSetOrgaoJulgador() {
        return (this.orgaoJulgador!= null);
    }

    /**
     * Gets the value of the outrosNumeros property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the outrosNumeros property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOutrosNumeros().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOutrosNumeros() {
        if (outrosNumeros == null) {
            outrosNumeros = new ArrayList<String>();
        }
        return this.outrosNumeros;
    }

    public boolean isSetOutrosNumeros() {
        return ((this.outrosNumeros!= null)&&(!this.outrosNumeros.isEmpty()));
    }

    public void unsetOutrosNumeros() {
        this.outrosNumeros = null;
    }

    /**
     * Obtém o valor da propriedade processoFisico.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isProcessoFisico() {
        return processoFisico;
    }

    /**
     * Define o valor da propriedade processoFisico.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setProcessoFisico(Boolean value) {
        this.processoFisico = value;
    }

    public boolean isSetProcessoFisico() {
        return (this.processoFisico!= null);
    }

    /**
     * Obtém o valor da propriedade pedidoLiminarPendente.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPedidoLiminarPendente() {
        return pedidoLiminarPendente;
    }

    /**
     * Define o valor da propriedade pedidoLiminarPendente.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPedidoLiminarPendente(Boolean value) {
        this.pedidoLiminarPendente = value;
    }

    public boolean isSetPedidoLiminarPendente() {
        return (this.pedidoLiminarPendente!= null);
    }

    /**
     * Gets the value of the historicoDeslocamento property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the historicoDeslocamento property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHistoricoDeslocamento().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HistoricoDeslocamento }
     * 
     * 
     */
    public List<HistoricoDeslocamento> getHistoricoDeslocamento() {
        if (historicoDeslocamento == null) {
            historicoDeslocamento = new ArrayList<HistoricoDeslocamento>();
        }
        return this.historicoDeslocamento;
    }

    public boolean isSetHistoricoDeslocamento() {
        return ((this.historicoDeslocamento!= null)&&(!this.historicoDeslocamento.isEmpty()));
    }

    public void unsetHistoricoDeslocamento() {
        this.historicoDeslocamento = null;
    }

    /**
     * Gets the value of the any property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the any property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAny().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getAny() {
        if (any == null) {
            any = new ArrayList<Object>();
        }
        return this.any;
    }

    public boolean isSetAny() {
        return ((this.any!= null)&&(!this.any.isEmpty()));
    }

    public void unsetAny() {
        this.any = null;
    }

}
