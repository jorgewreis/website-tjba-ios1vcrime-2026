
package br.jus.cnj.intercomunicacao.beans;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de modalidadePrioridade.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * <p>
 * <pre>
 * &lt;simpleType name="modalidadePrioridade">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="IDOSO"/>
 *     &lt;enumeration value="REU_PRESO"/>
 *     &lt;enumeration value="PERECIMENTO"/>
 *     &lt;enumeration value="MENOR"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "modalidadePrioridade")
@XmlEnum
public enum ModalidadePrioridade {

    IDOSO,
    REU_PRESO,
    PERECIMENTO,
    MENOR;

    public String value() {
        return name();
    }

    public static ModalidadePrioridade fromValue(String v) {
        return valueOf(v);
    }

}
