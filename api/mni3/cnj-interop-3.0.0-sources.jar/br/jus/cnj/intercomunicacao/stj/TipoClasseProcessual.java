
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * Lista classe processual conforme Resolução 46 do CNJ.
 * 
 * <p>Classe Java de tipoClasseProcessual complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoClasseProcessual">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codigoClasseTribunalOrigem" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codigoClassePrimeiraInstancia" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;minInclusive value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoClasseProcessual", propOrder = {
    "codigoClasseTribunalOrigem",
    "codigoClassePrimeiraInstancia"
})
public class TipoClasseProcessual
    implements Serializable
{

    protected Integer codigoClasseTribunalOrigem;
    protected Integer codigoClassePrimeiraInstancia;

    /**
     * Obtém o valor da propriedade codigoClasseTribunalOrigem.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoClasseTribunalOrigem() {
        return codigoClasseTribunalOrigem;
    }

    /**
     * Define o valor da propriedade codigoClasseTribunalOrigem.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoClasseTribunalOrigem(Integer value) {
        this.codigoClasseTribunalOrigem = value;
    }

    public boolean isSetCodigoClasseTribunalOrigem() {
        return (this.codigoClasseTribunalOrigem!= null);
    }

    /**
     * Obtém o valor da propriedade codigoClassePrimeiraInstancia.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCodigoClassePrimeiraInstancia() {
        return codigoClassePrimeiraInstancia;
    }

    /**
     * Define o valor da propriedade codigoClassePrimeiraInstancia.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCodigoClassePrimeiraInstancia(Integer value) {
        this.codigoClassePrimeiraInstancia = value;
    }

    public boolean isSetCodigoClassePrimeiraInstancia() {
        return (this.codigoClassePrimeiraInstancia!= null);
    }

}
