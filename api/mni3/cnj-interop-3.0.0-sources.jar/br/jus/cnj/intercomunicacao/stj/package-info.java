@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.stj.jus.br/mni/v100/intercomunicacao", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package br.jus.cnj.intercomunicacao.stj;
