
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoDocumentoStj complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoDocumentoStj">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="numeroVolume" default="1">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="apenso" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoDocumentoStj")
public class TipoDocumentoStj
    implements Serializable
{

    @XmlAttribute(name = "numeroVolume")
    protected Integer numeroVolume;
    @XmlAttribute(name = "apenso")
    protected Boolean apenso;

    /**
     * Obtém o valor da propriedade numeroVolume.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getNumeroVolume() {
        if (numeroVolume == null) {
            return  1;
        } else {
            return numeroVolume;
        }
    }

    /**
     * Define o valor da propriedade numeroVolume.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeroVolume(int value) {
        this.numeroVolume = value;
    }

    public boolean isSetNumeroVolume() {
        return (this.numeroVolume!= null);
    }

    public void unsetNumeroVolume() {
        this.numeroVolume = null;
    }

    /**
     * Obtém o valor da propriedade apenso.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isApenso() {
        return apenso;
    }

    /**
     * Define o valor da propriedade apenso.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApenso(boolean value) {
        this.apenso = value;
    }

    public boolean isSetApenso() {
        return (this.apenso!= null);
    }

    public void unsetApenso() {
        this.apenso = null;
    }

}
