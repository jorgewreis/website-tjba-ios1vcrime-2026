
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoParteStj complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoParteStj">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="numeroPaginaAssistenciaJudiciaria">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoParteStj")
public class TipoParteStj
    implements Serializable
{

    @XmlAttribute(name = "numeroPaginaAssistenciaJudiciaria")
    protected Integer numeroPaginaAssistenciaJudiciaria;

    /**
     * Obtém o valor da propriedade numeroPaginaAssistenciaJudiciaria.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getNumeroPaginaAssistenciaJudiciaria() {
        return numeroPaginaAssistenciaJudiciaria;
    }

    /**
     * Define o valor da propriedade numeroPaginaAssistenciaJudiciaria.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumeroPaginaAssistenciaJudiciaria(int value) {
        this.numeroPaginaAssistenciaJudiciaria = value;
    }

    public boolean isSetNumeroPaginaAssistenciaJudiciaria() {
        return (this.numeroPaginaAssistenciaJudiciaria!= null);
    }

    public void unsetNumeroPaginaAssistenciaJudiciaria() {
        this.numeroPaginaAssistenciaJudiciaria = null;
    }

}
