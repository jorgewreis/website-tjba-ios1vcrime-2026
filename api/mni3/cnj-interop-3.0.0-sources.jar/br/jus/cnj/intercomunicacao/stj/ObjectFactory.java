
package br.jus.cnj.intercomunicacao.stj;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the br.jus.cnj.intercomunicacao.stj package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: br.jus.cnj.intercomunicacao.stj
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TipoRepresentativoControversia }
     * 
     */
    public TipoRepresentativoControversia createTipoRepresentativoControversia() {
        return new TipoRepresentativoControversia();
    }

    /**
     * Create an instance of {@link TipoComunicacaoProcessualStj }
     * 
     */
    public TipoComunicacaoProcessualStj createTipoComunicacaoProcessualStj() {
        return new TipoComunicacaoProcessualStj();
    }

    /**
     * Create an instance of {@link TipoParteStj }
     * 
     */
    public TipoParteStj createTipoParteStj() {
        return new TipoParteStj();
    }

    /**
     * Create an instance of {@link TipoCabecalhoProcessoStj }
     * 
     */
    public TipoCabecalhoProcessoStj createTipoCabecalhoProcessoStj() {
        return new TipoCabecalhoProcessoStj();
    }

    /**
     * Create an instance of {@link TipoClasseProcessual }
     * 
     */
    public TipoClasseProcessual createTipoClasseProcessual() {
        return new TipoClasseProcessual();
    }

    /**
     * Create an instance of {@link TipoDocumentoStj }
     * 
     */
    public TipoDocumentoStj createTipoDocumentoStj() {
        return new TipoDocumentoStj();
    }

    /**
     * Create an instance of {@link TipoNaturezaFisico }
     * 
     */
    public TipoNaturezaFisico createTipoNaturezaFisico() {
        return new TipoNaturezaFisico();
    }

}
