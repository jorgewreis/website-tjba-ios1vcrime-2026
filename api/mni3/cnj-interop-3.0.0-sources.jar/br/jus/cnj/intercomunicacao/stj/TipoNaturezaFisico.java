
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoNaturezaFisico complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoNaturezaFisico">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="paginaPedidoLiminarStj">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="paginaPrioridadeEstatutoIdoso">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="paginaCustas">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="paginaRepresentativoControversia">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="quantidadeVolumes" default="1">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="quantidadeApensos" default="0">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="0"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="ultimaFolha" default="1">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoNaturezaFisico")
public class TipoNaturezaFisico
    implements Serializable
{

    @XmlAttribute(name = "paginaPedidoLiminarStj")
    protected Integer paginaPedidoLiminarStj;
    @XmlAttribute(name = "paginaPrioridadeEstatutoIdoso")
    protected Integer paginaPrioridadeEstatutoIdoso;
    @XmlAttribute(name = "paginaCustas")
    protected Integer paginaCustas;
    @XmlAttribute(name = "paginaRepresentativoControversia")
    protected Integer paginaRepresentativoControversia;
    @XmlAttribute(name = "quantidadeVolumes")
    protected Integer quantidadeVolumes;
    @XmlAttribute(name = "quantidadeApensos")
    protected Integer quantidadeApensos;
    @XmlAttribute(name = "ultimaFolha")
    protected Integer ultimaFolha;

    /**
     * Obtém o valor da propriedade paginaPedidoLiminarStj.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getPaginaPedidoLiminarStj() {
        return paginaPedidoLiminarStj;
    }

    /**
     * Define o valor da propriedade paginaPedidoLiminarStj.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaginaPedidoLiminarStj(int value) {
        this.paginaPedidoLiminarStj = value;
    }

    public boolean isSetPaginaPedidoLiminarStj() {
        return (this.paginaPedidoLiminarStj!= null);
    }

    public void unsetPaginaPedidoLiminarStj() {
        this.paginaPedidoLiminarStj = null;
    }

    /**
     * Obtém o valor da propriedade paginaPrioridadeEstatutoIdoso.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getPaginaPrioridadeEstatutoIdoso() {
        return paginaPrioridadeEstatutoIdoso;
    }

    /**
     * Define o valor da propriedade paginaPrioridadeEstatutoIdoso.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaginaPrioridadeEstatutoIdoso(int value) {
        this.paginaPrioridadeEstatutoIdoso = value;
    }

    public boolean isSetPaginaPrioridadeEstatutoIdoso() {
        return (this.paginaPrioridadeEstatutoIdoso!= null);
    }

    public void unsetPaginaPrioridadeEstatutoIdoso() {
        this.paginaPrioridadeEstatutoIdoso = null;
    }

    /**
     * Obtém o valor da propriedade paginaCustas.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getPaginaCustas() {
        return paginaCustas;
    }

    /**
     * Define o valor da propriedade paginaCustas.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaginaCustas(int value) {
        this.paginaCustas = value;
    }

    public boolean isSetPaginaCustas() {
        return (this.paginaCustas!= null);
    }

    public void unsetPaginaCustas() {
        this.paginaCustas = null;
    }

    /**
     * Obtém o valor da propriedade paginaRepresentativoControversia.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getPaginaRepresentativoControversia() {
        return paginaRepresentativoControversia;
    }

    /**
     * Define o valor da propriedade paginaRepresentativoControversia.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPaginaRepresentativoControversia(int value) {
        this.paginaRepresentativoControversia = value;
    }

    public boolean isSetPaginaRepresentativoControversia() {
        return (this.paginaRepresentativoControversia!= null);
    }

    public void unsetPaginaRepresentativoControversia() {
        this.paginaRepresentativoControversia = null;
    }

    /**
     * Obtém o valor da propriedade quantidadeVolumes.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getQuantidadeVolumes() {
        if (quantidadeVolumes == null) {
            return  1;
        } else {
            return quantidadeVolumes;
        }
    }

    /**
     * Define o valor da propriedade quantidadeVolumes.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuantidadeVolumes(int value) {
        this.quantidadeVolumes = value;
    }

    public boolean isSetQuantidadeVolumes() {
        return (this.quantidadeVolumes!= null);
    }

    public void unsetQuantidadeVolumes() {
        this.quantidadeVolumes = null;
    }

    /**
     * Obtém o valor da propriedade quantidadeApensos.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getQuantidadeApensos() {
        if (quantidadeApensos == null) {
            return  0;
        } else {
            return quantidadeApensos;
        }
    }

    /**
     * Define o valor da propriedade quantidadeApensos.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuantidadeApensos(int value) {
        this.quantidadeApensos = value;
    }

    public boolean isSetQuantidadeApensos() {
        return (this.quantidadeApensos!= null);
    }

    public void unsetQuantidadeApensos() {
        this.quantidadeApensos = null;
    }

    /**
     * Obtém o valor da propriedade ultimaFolha.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getUltimaFolha() {
        if (ultimaFolha == null) {
            return  1;
        } else {
            return ultimaFolha;
        }
    }

    /**
     * Define o valor da propriedade ultimaFolha.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setUltimaFolha(int value) {
        this.ultimaFolha = value;
    }

    public boolean isSetUltimaFolha() {
        return (this.ultimaFolha!= null);
    }

    public void unsetUltimaFolha() {
        this.ultimaFolha = null;
    }

}
