
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import br.jus.cnj.intercomunicacao.beans.ModalidadeUnidadeFederacao;


/**
 * <p>Classe Java de tipoCabecalhoProcessoStj complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoCabecalhoProcessoStj">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="classeProcessual" type="{http://www.stj.jus.br/mni/v100/intercomunicacao}tipoClasseProcessual" minOccurs="0"/>
 *         &lt;element name="detalheNaturezaFisico" type="{http://www.stj.jus.br/mni/v100/intercomunicacao}tipoNaturezaFisico" minOccurs="0"/>
 *         &lt;element name="representativoControversia" type="{http://www.stj.jus.br/mni/v100/intercomunicacao}tipoRepresentativoControversia" minOccurs="0"/>
 *         &lt;element name="unidadeFederacao" type="{http://www.cnj.jus.br/mni/v300/intercomunicacao}modalidadeUnidadeFederacao"/>
 *       &lt;/sequence>
 *       &lt;attribute name="naturezaEnvio" use="required">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;enumeration value="ELETRONICO"/>
 *             &lt;enumeration value="DIGITALIZADO"/>
 *             &lt;enumeration value="FISICO"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *       &lt;attribute name="numeroOrigem" use="required" type="{http://www.stj.jus.br/mni/v100/intercomunicacao}tipoNumeroOrigem" />
 *       &lt;attribute name="nomeLocalidade" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="pedidoLiminarSTJ" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="segredoJustica" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="criminal" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="custas" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="nomeRelatorStj" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="repetitivo" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="resumoIndicativo" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoCabecalhoProcessoStj", propOrder = {
    "classeProcessual",
    "detalheNaturezaFisico",
    "representativoControversia",
    "unidadeFederacao"
})
public class TipoCabecalhoProcessoStj
    implements Serializable
{

    protected TipoClasseProcessual classeProcessual;
    protected TipoNaturezaFisico detalheNaturezaFisico;
    protected TipoRepresentativoControversia representativoControversia;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected ModalidadeUnidadeFederacao unidadeFederacao;
    @XmlAttribute(name = "naturezaEnvio", required = true)
    protected String naturezaEnvio;
    @XmlAttribute(name = "numeroOrigem", required = true)
    protected String numeroOrigem;
    @XmlAttribute(name = "nomeLocalidade")
    protected String nomeLocalidade;
    @XmlAttribute(name = "pedidoLiminarSTJ")
    protected Boolean pedidoLiminarSTJ;
    @XmlAttribute(name = "segredoJustica")
    protected Boolean segredoJustica;
    @XmlAttribute(name = "criminal")
    protected Boolean criminal;
    @XmlAttribute(name = "custas")
    protected Boolean custas;
    @XmlAttribute(name = "nomeRelatorStj")
    protected String nomeRelatorStj;
    @XmlAttribute(name = "repetitivo")
    protected Boolean repetitivo;
    @XmlAttribute(name = "resumoIndicativo")
    protected String resumoIndicativo;

    /**
     * Obtém o valor da propriedade classeProcessual.
     * 
     * @return
     *     possible object is
     *     {@link TipoClasseProcessual }
     *     
     */
    public TipoClasseProcessual getClasseProcessual() {
        return classeProcessual;
    }

    /**
     * Define o valor da propriedade classeProcessual.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoClasseProcessual }
     *     
     */
    public void setClasseProcessual(TipoClasseProcessual value) {
        this.classeProcessual = value;
    }

    public boolean isSetClasseProcessual() {
        return (this.classeProcessual!= null);
    }

    /**
     * Obtém o valor da propriedade detalheNaturezaFisico.
     * 
     * @return
     *     possible object is
     *     {@link TipoNaturezaFisico }
     *     
     */
    public TipoNaturezaFisico getDetalheNaturezaFisico() {
        return detalheNaturezaFisico;
    }

    /**
     * Define o valor da propriedade detalheNaturezaFisico.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoNaturezaFisico }
     *     
     */
    public void setDetalheNaturezaFisico(TipoNaturezaFisico value) {
        this.detalheNaturezaFisico = value;
    }

    public boolean isSetDetalheNaturezaFisico() {
        return (this.detalheNaturezaFisico!= null);
    }

    /**
     * Obtém o valor da propriedade representativoControversia.
     * 
     * @return
     *     possible object is
     *     {@link TipoRepresentativoControversia }
     *     
     */
    public TipoRepresentativoControversia getRepresentativoControversia() {
        return representativoControversia;
    }

    /**
     * Define o valor da propriedade representativoControversia.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoRepresentativoControversia }
     *     
     */
    public void setRepresentativoControversia(TipoRepresentativoControversia value) {
        this.representativoControversia = value;
    }

    public boolean isSetRepresentativoControversia() {
        return (this.representativoControversia!= null);
    }

    /**
     * Obtém o valor da propriedade unidadeFederacao.
     * 
     * @return
     *     possible object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public ModalidadeUnidadeFederacao getUnidadeFederacao() {
        return unidadeFederacao;
    }

    /**
     * Define o valor da propriedade unidadeFederacao.
     * 
     * @param value
     *     allowed object is
     *     {@link ModalidadeUnidadeFederacao }
     *     
     */
    public void setUnidadeFederacao(ModalidadeUnidadeFederacao value) {
        this.unidadeFederacao = value;
    }

    public boolean isSetUnidadeFederacao() {
        return (this.unidadeFederacao!= null);
    }

    /**
     * Obtém o valor da propriedade naturezaEnvio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNaturezaEnvio() {
        return naturezaEnvio;
    }

    /**
     * Define o valor da propriedade naturezaEnvio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNaturezaEnvio(String value) {
        this.naturezaEnvio = value;
    }

    public boolean isSetNaturezaEnvio() {
        return (this.naturezaEnvio!= null);
    }

    /**
     * Obtém o valor da propriedade numeroOrigem.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroOrigem() {
        return numeroOrigem;
    }

    /**
     * Define o valor da propriedade numeroOrigem.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroOrigem(String value) {
        this.numeroOrigem = value;
    }

    public boolean isSetNumeroOrigem() {
        return (this.numeroOrigem!= null);
    }

    /**
     * Obtém o valor da propriedade nomeLocalidade.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeLocalidade() {
        return nomeLocalidade;
    }

    /**
     * Define o valor da propriedade nomeLocalidade.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeLocalidade(String value) {
        this.nomeLocalidade = value;
    }

    public boolean isSetNomeLocalidade() {
        return (this.nomeLocalidade!= null);
    }

    /**
     * Obtém o valor da propriedade pedidoLiminarSTJ.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isPedidoLiminarSTJ() {
        return pedidoLiminarSTJ;
    }

    /**
     * Define o valor da propriedade pedidoLiminarSTJ.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPedidoLiminarSTJ(boolean value) {
        this.pedidoLiminarSTJ = value;
    }

    public boolean isSetPedidoLiminarSTJ() {
        return (this.pedidoLiminarSTJ!= null);
    }

    public void unsetPedidoLiminarSTJ() {
        this.pedidoLiminarSTJ = null;
    }

    /**
     * Obtém o valor da propriedade segredoJustica.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isSegredoJustica() {
        return segredoJustica;
    }

    /**
     * Define o valor da propriedade segredoJustica.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSegredoJustica(boolean value) {
        this.segredoJustica = value;
    }

    public boolean isSetSegredoJustica() {
        return (this.segredoJustica!= null);
    }

    public void unsetSegredoJustica() {
        this.segredoJustica = null;
    }

    /**
     * Obtém o valor da propriedade criminal.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isCriminal() {
        return criminal;
    }

    /**
     * Define o valor da propriedade criminal.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCriminal(boolean value) {
        this.criminal = value;
    }

    public boolean isSetCriminal() {
        return (this.criminal!= null);
    }

    public void unsetCriminal() {
        this.criminal = null;
    }

    /**
     * Obtém o valor da propriedade custas.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isCustas() {
        return custas;
    }

    /**
     * Define o valor da propriedade custas.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCustas(boolean value) {
        this.custas = value;
    }

    public boolean isSetCustas() {
        return (this.custas!= null);
    }

    public void unsetCustas() {
        this.custas = null;
    }

    /**
     * Obtém o valor da propriedade nomeRelatorStj.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeRelatorStj() {
        return nomeRelatorStj;
    }

    /**
     * Define o valor da propriedade nomeRelatorStj.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeRelatorStj(String value) {
        this.nomeRelatorStj = value;
    }

    public boolean isSetNomeRelatorStj() {
        return (this.nomeRelatorStj!= null);
    }

    /**
     * Obtém o valor da propriedade repetitivo.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isRepetitivo() {
        return repetitivo;
    }

    /**
     * Define o valor da propriedade repetitivo.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRepetitivo(boolean value) {
        this.repetitivo = value;
    }

    public boolean isSetRepetitivo() {
        return (this.repetitivo!= null);
    }

    public void unsetRepetitivo() {
        this.repetitivo = null;
    }

    /**
     * Obtém o valor da propriedade resumoIndicativo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResumoIndicativo() {
        return resumoIndicativo;
    }

    /**
     * Define o valor da propriedade resumoIndicativo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResumoIndicativo(String value) {
        this.resumoIndicativo = value;
    }

    public boolean isSetResumoIndicativo() {
        return (this.resumoIndicativo!= null);
    }

}
