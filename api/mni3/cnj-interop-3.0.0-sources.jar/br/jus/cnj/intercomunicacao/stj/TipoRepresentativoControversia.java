
package br.jus.cnj.intercomunicacao.stj;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java de tipoRepresentativoControversia complex type.
 * 
 * <p>O seguinte fragmento do esquema especifica o conteúdo esperado contido dentro desta classe.
 * 
 * <pre>
 * &lt;complexType name="tipoRepresentativoControversia">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="representativoControversia" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="quantidadeProcessosSobrestados">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *             &lt;minInclusive value="1"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tipoRepresentativoControversia")
public class TipoRepresentativoControversia
    implements Serializable
{

    @XmlAttribute(name = "representativoControversia", required = true)
    protected boolean representativoControversia;
    @XmlAttribute(name = "quantidadeProcessosSobrestados")
    protected Integer quantidadeProcessosSobrestados;

    /**
     * Obtém o valor da propriedade representativoControversia.
     * 
     */
    public boolean isRepresentativoControversia() {
        return representativoControversia;
    }

    /**
     * Define o valor da propriedade representativoControversia.
     * 
     */
    public void setRepresentativoControversia(boolean value) {
        this.representativoControversia = value;
    }

    public boolean isSetRepresentativoControversia() {
        return true;
    }

    /**
     * Obtém o valor da propriedade quantidadeProcessosSobrestados.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public int getQuantidadeProcessosSobrestados() {
        return quantidadeProcessosSobrestados;
    }

    /**
     * Define o valor da propriedade quantidadeProcessosSobrestados.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuantidadeProcessosSobrestados(int value) {
        this.quantidadeProcessosSobrestados = value;
    }

    public boolean isSetQuantidadeProcessosSobrestados() {
        return (this.quantidadeProcessosSobrestados!= null);
    }

    public void unsetQuantidadeProcessosSobrestados() {
        this.quantidadeProcessosSobrestados = null;
    }

}
